import axios from 'axios';
import { EtherscanAdapter } from './src/adapters/etherscan-adapter';
import { BlockCypherAdapter } from './src/adapters/blockcypher-adapter';
import { BlockscoutAdapter } from './src/adapters/blockscout-adapter';
import { StellarAdapter } from './src/adapters/stellar-adapter';
import dotenv from 'dotenv';

dotenv.config();

const TEST_ADDRESSES = {
  ethereum: '0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045', // Vitalik's address
  litecoin: 'LM2WMpR1Rp6j3Sa59cMXMs1SPzj9eXpGc1', // Random Litecoin address
  gnosis: '0x4F96Fe3b7A6Cf9725f59d353F723c1bDb64CA6Aa', // Gnosis address
  stellar: 'GBHQ7M4JBWKQMQCGPNMQNZWSQXFVNMXTU4SWOICJWP4QHLH3JNFXSV6R' // Random Stellar address
};

const API_KEYS = {
  etherscan: process.env.ETHERSCAN_API_KEY || '',
  arbiscan: process.env.ARBISCAN_API_KEY || '',
  polyscan: process.env.POLYSCAN_API_KEY || '',
  bscscan: process.env.BSCSCAN_API_KEY || '',
  fantom: process.env.FANTOM_API_KEY || '',
  optimism: process.env.OPTIMISM_API_KEY || '',
  base: process.env.BASE_API_KEY || '',
  cardano: process.env.CARDANO_API_KEY || '',
  stacks: process.env.STACKS_API_KEY || ''
};

async function testEtherscanAdapter() {
  console.log('\n--- Testing Etherscan Adapter ---');
  const adapter = new EtherscanAdapter(
    'Ethereum',
    'https://api.etherscan.io/api',
    API_KEYS.etherscan,
    'ETH'
  );
  
  try {
    console.log('Fetching native ETH balance...');
    const nativeBalance = await adapter.getNativeBalance('1', TEST_ADDRESSES.ethereum);
    console.log('Native ETH Balance:', nativeBalance);
    
    console.log('\nFetching ERC20 token balances...');
    const tokenBalances = await adapter.getERC20Balances('1', TEST_ADDRESSES.ethereum);
    console.log(`Found ${tokenBalances.length} ERC20 tokens`);
    if (tokenBalances.length > 0) {
      console.log('First token:', tokenBalances[0]);
    }
    
    console.log('\nFetching USDT token balance...');
    const usdtAddress = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
    const tokenBalance = await adapter.getERC20Balance('1', TEST_ADDRESSES.ethereum, usdtAddress);
    console.log('USDT Balance:', tokenBalance);
    
    return true;
  } catch (error) {
    console.error('Error testing Etherscan adapter:', error);
    return false;
  }
}

async function testBlockCypherAdapter() {
  console.log('\n--- Testing BlockCypher Adapter ---');
  const adapter = new BlockCypherAdapter();
  
  try {
    console.log('Fetching native LTC balance...');
    const nativeBalance = await adapter.getNativeBalance('2', TEST_ADDRESSES.litecoin);
    console.log('Native LTC Balance:', nativeBalance);
    
    return true;
  } catch (error) {
    console.error('Error testing BlockCypher adapter:', error);
    return false;
  }
}

async function testBlockscoutAdapter() {
  console.log('\n--- Testing Blockscout Adapter ---');
  const adapter = new BlockscoutAdapter();
  
  try {
    console.log('Fetching native xDAI balance...');
    const nativeBalance = await adapter.getNativeBalance('100', TEST_ADDRESSES.gnosis);
    console.log('Native xDAI Balance:', nativeBalance);
    
    console.log('\nFetching ERC20 token balances...');
    const tokenBalances = await adapter.getERC20Balances('100', TEST_ADDRESSES.gnosis);
    console.log(`Found ${tokenBalances.length} ERC20 tokens`);
    if (tokenBalances.length > 0) {
      console.log('First token:', tokenBalances[0]);
    }
    
    return true;
  } catch (error) {
    console.error('Error testing Blockscout adapter:', error);
    return false;
  }
}

async function testStellarAdapter() {
  console.log('\n--- Testing Stellar Adapter ---');
  const adapter = new StellarAdapter();
  
  try {
    console.log('Fetching all Stellar balances...');
    const balances = await adapter.getBalances('stellar', TEST_ADDRESSES.stellar);
    console.log(`Found ${balances.length} balances`);
    if (balances.length > 0) {
      console.log('First balance:', balances[0]);
    }
    
    return true;
  } catch (error) {
    console.error('Error testing Stellar adapter:', error);
    return false;
  }
}

async function runTests() {
  console.log('Starting API tests with real blockchain addresses...');
  
  let results = {
    etherscan: await testEtherscanAdapter(),
    blockcypher: await testBlockCypherAdapter(),
    blockscout: await testBlockscoutAdapter(),
    stellar: await testStellarAdapter()
  };
  
  console.log('\n--- Test Results Summary ---');
  for (const [adapter, success] of Object.entries(results)) {
    console.log(`${adapter}: ${success ? 'SUCCESS' : 'FAILED'}`);
  }
  
  const allSuccess = Object.values(results).every(result => result === true);
  console.log(`\nOverall Test Result: ${allSuccess ? 'SUCCESS' : 'FAILED'}`);
}

runTests().catch(error => {
  console.error('Error running tests:', error);
});
