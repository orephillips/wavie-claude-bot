const axios = require('axios');
require('dotenv').config();

const TEST_ADDRESSES = {
  ethereum: '0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045', // Vitalik's address
  litecoin: 'LM2WMpR1Rp6j3Sa59cMXMs1SPzj9eXpGc1', // Random Litecoin address
  gnosis: '0x4F96Fe3b7A6Cf9725f59d353F723c1bDb64CA6Aa', // Gnosis address
  stellar: 'GBHQ7M4JBWKQMQCGPNMQNZWSQXFVNMXTU4SWOICJWP4QHLH3JNFXSV6R' // Random Stellar address
};

const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY || '';

async function testEtherscanAPI() {
  console.log('\n--- Testing Etherscan API ---');
  
  try {
    console.log('Fetching native ETH balance...');
    const url = `https://api.etherscan.io/api?module=account&action=balance&address=${TEST_ADDRESSES.ethereum}&tag=latest&apikey=${ETHERSCAN_API_KEY}`;
    const response = await axios.get(url);
    
    if (response.data.status !== '1') {
      throw new Error(`API Error: ${response.data.message || 'Unknown error'}`);
    }
    
    const balanceInWei = response.data.result;
    const balanceInEth = (parseInt(balanceInWei) / Math.pow(10, 18)).toString();
    
    console.log('Native ETH Balance:', balanceInEth);
    console.log('Raw API Response:', response.data);
    
    return true;
  } catch (error) {
    console.error('Error testing Etherscan API:', error);
    return false;
  }
}

async function testBlockCypherAPI() {
  console.log('\n--- Testing BlockCypher API ---');
  
  try {
    console.log('Fetching native LTC balance...');
    const url = `https://api.blockcypher.com/v1/ltc/main/addrs/${TEST_ADDRESSES.litecoin}`;
    const response = await axios.get(url);
    
    if (!response.data || !response.data.final_balance) {
      throw new Error('Invalid response from BlockCypher API');
    }
    
    const balanceInSatoshis = response.data.final_balance;
    const balanceInLtc = (balanceInSatoshis / 100000000).toString();
    
    console.log('Native LTC Balance:', balanceInLtc);
    console.log('Raw API Response:', response.data);
    
    return true;
  } catch (error) {
    console.error('Error testing BlockCypher API:', error);
    return false;
  }
}

async function testBlockscoutAPI() {
  console.log('\n--- Testing Blockscout API ---');
  
  try {
    console.log('Fetching native xDAI balance...');
    const url = `https://blockscout.com/xdai/mainnet/api?module=account&action=balance&address=${TEST_ADDRESSES.gnosis}`;
    const response = await axios.get(url);
    
    if (!response.data || response.data.status !== '1') {
      throw new Error(`API Error: ${response.data?.message || 'Unknown error'}`);
    }
    
    const balanceInWei = response.data.result;
    const balanceInXDai = (parseInt(balanceInWei) / Math.pow(10, 18)).toString();
    
    console.log('Native xDAI Balance:', balanceInXDai);
    console.log('Raw API Response:', response.data);
    
    return true;
  } catch (error) {
    console.error('Error testing Blockscout API:', error);
    return false;
  }
}

async function testStellarAPI() {
  console.log('\n--- Testing Stellar API ---');
  
  try {
    console.log('Fetching Stellar account info...');
    const url = `https://horizon.stellar.org/accounts/${TEST_ADDRESSES.stellar}`;
    const response = await axios.get(url);
    
    if (!response.data) {
      throw new Error('No account data returned from Stellar API');
    }
    
    const balances = response.data.balances;
    console.log(`Found ${balances.length} balances`);
    
    if (balances.length > 0) {
      console.log('First balance:', balances[0]);
    }
    
    return true;
  } catch (error) {
    console.error('Error testing Stellar API:', error);
    return false;
  }
}

async function runTests() {
  console.log('Starting API tests with real blockchain addresses...');
  console.log('Using API keys from .env file');
  console.log(`Etherscan API key: ${ETHERSCAN_API_KEY ? 'Available' : 'Missing'}`);
  
  let results = {
    etherscan: await testEtherscanAPI(),
    blockcypher: await testBlockCypherAPI(),
    blockscout: await testBlockscoutAPI(),
    stellar: await testStellarAPI()
  };
  
  console.log('\n--- Test Results Summary ---');
  for (const [adapter, success] of Object.entries(results)) {
    console.log(`${adapter}: ${success ? 'SUCCESS' : 'FAILED'}`);
  }
  
  const allSuccess = Object.values(results).every(result => result === true);
  console.log(`\nOverall Test Result: ${allSuccess ? 'SUCCESS' : 'FAILED'}`);
}

runTests().catch(error => {
  console.error('Error running tests:', error);
});
