const express = require('express');
const cors = require('cors');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY || '';
const POLYSCAN_API_KEY = process.env.POLYSCAN_API_KEY || '';
const BSCSCAN_API_KEY = process.env.BSCSCAN_API_KEY || '';

app.get('/api/test/ethereum/:address', async (req, res) => {
  try {
    const { address } = req.params;
    const url = `https://api.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest&apikey=${ETHERSCAN_API_KEY}`;
    
    const response = await axios.get(url);
    
    if (response.data.status !== '1') {
      throw new Error(`API Error: ${response.data.message || 'Unknown error'}`);
    }
    
    const balanceInWei = response.data.result;
    const balanceInEth = (parseInt(balanceInWei) / Math.pow(10, 18)).toString();
    
    res.status(200).json({
      success: true,
      data: {
        Ticker: 'ETH',
        Amount: balanceInEth,
        WalletId: `bitwave-wallet-id-${address.substring(0, 8)}`,
        RemoteWalletId: address,
        BlockId: '0',
        TimestampSEC: Math.floor(Date.now() / 1000).toString(),
        RawMetadata: {
          source: 'Etherscan API',
          chain: 'Ethereum',
          raw_response: response.data
        }
      }
    });
  } catch (error) {
    console.error('Error fetching Ethereum balance:', error);
    res.status(500).json({
      success: false,
      errors: [error.message]
    });
  }
});

app.get('/api/test/polygon/:address', async (req, res) => {
  try {
    const { address } = req.params;
    const url = `https://api.polygonscan.com/api?module=account&action=balance&address=${address}&tag=latest&apikey=${POLYSCAN_API_KEY}`;
    
    const response = await axios.get(url);
    
    if (response.data.status !== '1') {
      throw new Error(`API Error: ${response.data.message || 'Unknown error'}`);
    }
    
    const balanceInWei = response.data.result;
    const balanceInMatic = (parseInt(balanceInWei) / Math.pow(10, 18)).toString();
    
    res.status(200).json({
      success: true,
      data: {
        Ticker: 'MATIC',
        Amount: balanceInMatic,
        WalletId: `bitwave-wallet-id-${address.substring(0, 8)}`,
        RemoteWalletId: address,
        BlockId: '0',
        TimestampSEC: Math.floor(Date.now() / 1000).toString(),
        RawMetadata: {
          source: 'Polygonscan API',
          chain: 'Polygon',
          raw_response: response.data
        }
      }
    });
  } catch (error) {
    console.error('Error fetching Polygon balance:', error);
    res.status(500).json({
      success: false,
      errors: [error.message]
    });
  }
});

app.get('/api/test/bsc/:address', async (req, res) => {
  try {
    const { address } = req.params;
    const url = `https://api.bscscan.com/api?module=account&action=balance&address=${address}&tag=latest&apikey=${BSCSCAN_API_KEY}`;
    
    const response = await axios.get(url);
    
    if (response.data.status !== '1') {
      throw new Error(`API Error: ${response.data.message || 'Unknown error'}`);
    }
    
    const balanceInWei = response.data.result;
    const balanceInBnb = (parseInt(balanceInWei) / Math.pow(10, 18)).toString();
    
    res.status(200).json({
      success: true,
      data: {
        Ticker: 'BNB',
        Amount: balanceInBnb,
        WalletId: `bitwave-wallet-id-${address.substring(0, 8)}`,
        RemoteWalletId: address,
        BlockId: '0',
        TimestampSEC: Math.floor(Date.now() / 1000).toString(),
        RawMetadata: {
          source: 'BSCscan API',
          chain: 'Binance Smart Chain',
          raw_response: response.data
        }
      }
    });
  } catch (error) {
    console.error('Error fetching BSC balance:', error);
    res.status(500).json({
      success: false,
      errors: [error.message]
    });
  }
});

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Blockchain Wallet Balance Tester</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }
        .form-group {
          margin-bottom: 15px;
        }
        label {
          display: block;
          margin-bottom: 5px;
          font-weight: bold;
        }
        select, input, button {
          padding: 8px;
          width: 100%;
          box-sizing: border-box;
        }
        button {
          background-color: #4CAF50;
          color: white;
          border: none;
          cursor: pointer;
          margin-top: 10px;
        }
        button:hover {
          background-color: #45a049;
        }
        #results {
          margin-top: 20px;
          border: 1px solid #ddd;
          padding: 15px;
          border-radius: 5px;
          background-color: #f9f9f9;
          white-space: pre-wrap;
        }
        .loading {
          display: none;
          margin-top: 20px;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <h1>Blockchain Wallet Balance Tester</h1>
      <p>Test the real API calls to fetch blockchain wallet balances</p>
      
      <div class="form-group">
        <label for="blockchain">Select Blockchain:</label>
        <select id="blockchain">
          <option value="ethereum">Ethereum (Etherscan)</option>
          <option value="polygon">Polygon (Polygonscan)</option>
          <option value="bsc">Binance Smart Chain (BSCscan)</option>
        </select>
      </div>
      
      <div class="form-group">
        <label for="address">Wallet Address:</label>
        <input type="text" id="address" placeholder="Enter blockchain wallet address">
      </div>
      
      <button id="fetch-button">Fetch Balance</button>
      
      <div class="loading" id="loading">
        <p>Loading...</p>
      </div>
      
      <div id="results">
        Results will appear here...
      </div>
      
      <script>
        document.getElementById('fetch-button').addEventListener('click', async () => {
          const blockchain = document.getElementById('blockchain').value;
          const address = document.getElementById('address').value;
          const resultsDiv = document.getElementById('results');
          const loadingDiv = document.getElementById('loading');
          
          if (!address) {
            resultsDiv.textContent = 'Please enter a wallet address';
            return;
          }
          
          loadingDiv.style.display = 'block';
          resultsDiv.textContent = 'Fetching data...';
          
          try {
            const url = \`/api/test/\${blockchain}/\${address}\`;
            
            const response = await fetch(url);
            const data = await response.json();
            
            resultsDiv.textContent = JSON.stringify(data, null, 2);
          } catch (error) {
            resultsDiv.textContent = \`Error: \${error.message}\`;
          } finally {
            loadingDiv.style.display = 'none';
          }
        });
        
        document.getElementById('blockchain').addEventListener('change', (e) => {
          const addressInput = document.getElementById('address');
          const blockchain = e.target.value;
          
          const sampleAddresses = {
            'ethereum': '0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045', // Vitalik's address
            'polygon': '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', // Polygon bridge
            'bsc': '0x8894E0a0c962CB723c1976a4421c95949bE2D4E3' // Binance hot wallet
          };
          
          addressInput.placeholder = \`Enter \${blockchain} address (e.g. \${sampleAddresses[blockchain]})\`;
          addressInput.value = sampleAddresses[blockchain];
        });
        
        document.getElementById('blockchain').dispatchEvent(new Event('change'));
      </script>
    </body>
    </html>
  `);
});

app.listen(PORT, () => {
  console.log(`Test server running on port ${PORT}`);
  console.log(`Test API available at http://localhost:${PORT}/api/test/`);
  console.log(`Test interface available at http://localhost:${PORT}/`);
});
