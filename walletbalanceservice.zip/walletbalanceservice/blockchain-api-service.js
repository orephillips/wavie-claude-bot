const express = require('express');
const cors = require('cors');
const axios = require('axios');
const dotenv = require('dotenv');
const { RateLimiterMemory } = require('rate-limiter-flexible');
const { SecretManagerServiceClient } = require('@google-cloud/secret-manager');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;
const secretManager = new SecretManagerServiceClient();
const PROJECT_ID = process.env.GCP_PROJECT || 'bitwave-customers';

// Per-chain rate limiters (adjust based on API limits)
const rateLimiters = {
  ethereum: new RateLimiterMemory({ points: 5, duration: 1 }),
  arbitrum: new RateLimiterMemory({ points: 5, duration: 1 }),
  polygon: new RateLimiterMemory({ points: 5, duration: 1 }),
  bsc: new RateLimiterMemory({ points: 5, duration: 1 }),
  fantom: new RateLimiterMemory({ points: 5, duration: 1 }),
  optimism: new RateLimiterMemory({ points: 5, duration: 1 }),
  base: new RateLimiterMemory({ points: 5, duration: 1 }),
  litecoin: new RateLimiterMemory({ points: 10, duration: 1 }),
  bitcoin: new RateLimiterMemory({ points: 10, duration: 1 }),
  gnosis: new RateLimiterMemory({ points: 10, duration: 1 }),
  celo: new RateLimiterMemory({ points: 10, duration: 1 }),
  aurora: new RateLimiterMemory({ points: 10, duration: 1 }),
  avalanche_c: new RateLimiterMemory({ points: 10, duration: 1 }),
  stellar: new RateLimiterMemory({ points: 10, duration: 1 }),
  hedera: new RateLimiterMemory({ points: 10, duration: 1 }),
  evmos: new RateLimiterMemory({ points: 10, duration: 1 }),
  umee: new RateLimiterMemory({ points: 10, duration: 1 }),
  kyve: new RateLimiterMemory({ points: 10, duration: 1 }),
  persistence: new RateLimiterMemory({ points: 10, duration: 1 }),
  axelar: new RateLimiterMemory({ points: 10, duration: 1 }),
  celestia: new RateLimiterMemory({ points: 10, duration: 1 }),
  kava: new RateLimiterMemory({ points: 10, duration: 1 }),
  agoric: new RateLimiterMemory({ points: 10, duration: 1 }),
  akash: new RateLimiterMemory({ points: 10, duration: 1 }),
  regen: new RateLimiterMemory({ points: 10, duration: 1 }),
  provenance: new RateLimiterMemory({ points: 10, duration: 1 }),
  osmosis: new RateLimiterMemory({ points: 10, duration: 1 }),
  filecoin: new RateLimiterMemory({ points: 10, duration: 1 }),
  deso: new RateLimiterMemory({ points: 10, duration: 1 }),
  sui: new RateLimiterMemory({ points: 10, duration: 1 }),
  arweave: new RateLimiterMemory({ points: 10, duration: 1 }),
  kusama: new RateLimiterMemory({ points: 10, duration: 1 }),
  polkadot: new RateLimiterMemory({ points: 10, duration: 1 }),
  near: new RateLimiterMemory({ points: 10, duration: 1 }),
  stacks: new RateLimiterMemory({ points: 10, duration: 1 }),
  blast: new RateLimiterMemory({ points: 10, duration: 1 }),
  cardano: new RateLimiterMemory({ points: 10, duration: 1 })
};

// Fetch API keys from Secret Manager
async function fetchApiKey(secretId) {
  const [version] = await secretManager.accessSecretVersion({
    name: `projects/${PROJECT_ID}/secrets/${secretId}/versions/latest`
  });
  return version.payload.data.toString('utf8');
}

const API_KEYS = {
  etherscan: async () => await fetchApiKey('etherscan-api-key'),
  arbiscan: async () => await fetchApiKey('arbiscan-api-key'),
  polyscan: async () => await fetchApiKey('polyscan-api-key'),
  bscscan: async () => await fetchApiKey('bscscan-api-key'),
  fantom: async () => await fetchApiKey('fantom-api-key'),
  optimism: async () => await fetchApiKey('optimism-api-key'),
  base: async () => await fetchApiKey('base-api-key'),
  cardano: async () => await fetchApiKey('cardano-api-key'),
  stacks: async () => await fetchApiKey('stacks-api-key')
};

app.use(cors({ origin: '*', methods: ['GET'], credentials: true }));
app.use(express.json());

// Handlers (add others from your original code)
const handlers = {
  async etherscanHandler(req, res, chain) {
    try {
      const { address } = req.params;
      const { type, contractaddress } = req.query;
      let url, apiKey, baseUrl, ticker;
      switch (chain) {
        case 'ethereum':
          apiKey = await API_KEYS.etherscan(); baseUrl = 'https://api.etherscan.io/api'; ticker = 'ETH'; break;
        case 'arbitrum':
          apiKey = await API_KEYS.arbiscan(); baseUrl = 'https://api.arbiscan.io/api'; ticker = 'ARB'; break;
        default: throw new Error('Unsupported chain');
      }
      url = type === 'token' && contractaddress
        ? `${baseUrl}?module=account&action=tokenbalance&contractaddress=${contractaddress}&address=${address}&tag=latest&apikey=${apiKey}`
        : `${baseUrl}?module=account&action=balance&address=${address}&tag=latest&apikey=${apiKey}`;
      const response = await axios.get(url);
      if (response.data.status !== '1') throw new Error(`API Error: ${response.data.message}`);
      const balanceInWei = response.data.result;
      const balanceInEth = (parseInt(balanceInWei) / 1e18).toString();
      res.status(200).json({
        success: true,
        data: {
          Ticker: ticker,
          Amount: balanceInEth,
          WalletId: `bitwave-wallet-id-${address.substring(0, 8)}`,
          RemoteWalletId: address,
          BlockId: '0',
          TimestampSEC: Math.floor(Date.now() / 1000).toString(),
          RawMetadata: { source: `${chain}scan API`, chain, raw_response: response.data }
        }
      });
    } catch (error) {
      console.error(`Error fetching ${chain} balance:`, error);
      res.status(500).json({ success: false, errors: [error.message] });
    }
  }
};

// API route
app.get('/api/v1/chains/:chain/addresses/:address/balance', async (req, res) => {
  try {
    const { chain, address } = req.params;
    if (!rateLimiters[chain]) {
      return res.status(400).json({ success: false, errors: [`Unsupported blockchain: ${chain}`] });
    }
    await rateLimiters[chain].consume(`${chain}:${address}`);
    switch (chain) {
      case 'ethereum':
      case 'arbitrum':
      case 'polygon':
      case 'bsc':
      case 'fantom':
      case 'optimism':
      case 'base':
        return handlers.etherscanHandler(req, res, chain);
      default:
        return res.status(400).json({ success: false, errors: [`Unsupported blockchain: ${chain}`] });
    }
  } catch (error) {
    if (error.name === 'RateLimiterRes') {
      return res.status(429).json({ success: false, errors: ['Rate limit exceeded'] });
    }
    console.error('Error:', error);
    return res.status(500).json({ success: false, errors: [error.message] });
  }
});

app.listen(PORT, () => {
  console.log(`Wallet Balance Service running on port ${PORT}`);
});