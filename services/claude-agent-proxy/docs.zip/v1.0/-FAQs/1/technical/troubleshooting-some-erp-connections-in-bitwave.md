---
title: "Troubleshooting Some ERP Connections in Bitwave"
slug: "troubleshooting-some-erp-connections-in-bitwave"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:58:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:49 GMT+0000 (Coordinated Universal Time)"
---
1. Navigate to Administration -> Accounting Connection.
2. Click on "Disconnect" to terminate existing  connection.
3. Next, select "Connect New Account."
4. Simply link the same ERP organization(Eg: QBO ,Xero etc..) that was previously connected.
5. Our system should automatically detect that it's the same organization, thereby avoiding any issues with duplication.

Keep in mind that a common reason for connection loss is when there are permission changes on the ERP side.
