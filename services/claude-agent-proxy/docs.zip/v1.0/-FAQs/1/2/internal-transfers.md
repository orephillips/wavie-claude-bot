---
title: "Internal Transfers"
slug: "internal-transfers"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:45:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
Internal transfers, which involve moving assets from one wallet to another within the same entity, are a common occurrence in the world of blockchain management. Understanding how to handle these transfers and integrate them into accounting processes is essential for maintaining accurate records and financial transparency. In this article, we'll explore the steps to effectively manage internal transfers using Bitwave and their impact on accounting.

1. Identifying Internal Transfers:

Internal transfers occur when assets are moved between two wallets belonging to the same entity.

When both wallets are connected to Bitwave, any movement between them should be reflected as both an outflow from the sender wallet (Wallet A) and an inflow to the recipient wallet (Wallet B).

2. Combining Transaction Lines:

Internal transfers are typically represented by two transaction lines: the outflow from the sender wallet and the inflow to the recipient wallet.

Bitwave's platform often automatically combines these transaction lines into a single internal transfer entry. However, in some cases, users may need to manually combine them for clarity and accuracy.

3. Impact on Accounting:

Internal transfers do not affect the cost basis of the assets being transferred. They are akin to moving funds from one pocket to another – there is no disposal event, and the cost basis remains unchanged.

From an accounting perspective, internal transfers reflect no change in the entity's financial position or valuation of assets.

Example Scenario:

Let's consider a scenario where an entity transfers 10 Ethereum tokens from Wallet A to Wallet B, both connected to Bitwave.

Bitwave's platform would record this transaction as an outflow of 10 Ethereum tokens from Wallet A and an inflow of 10 Ethereum tokens to Wallet B.

These transaction lines can be combined into a single internal transfer entry, reflecting the movement of assets within the entity.

  Effectively managing internal transfers is crucial for maintaining accurate records and financial integrity.

By understanding how internal transfers are handled within Bitwave and their impact on accounting, users can streamline their processes and ensure compliance with regulatory requirements.

Internal transfers reflect a simple movement of assets within the entity and do not alter the cost basis or financial position. With Bitwave's intuitive platform, handling internal transfers becomes a seamless aspect of blockchain management.
