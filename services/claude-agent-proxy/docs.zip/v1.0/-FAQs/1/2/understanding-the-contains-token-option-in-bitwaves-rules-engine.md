---
title: "// Understanding the \"Contains Token\" Option in Bitwave's Rules Engine"
slug: "understanding-the-contains-token-option-in-bitwaves-rules-engine"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:59:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
To access the "Contains Token" option within Bitwave:

Navigate to Rules -> Use Identifiers -> Contains Token.

Bitwave's rules engine offers a robust capability known as the "Contains Token" option, aimed at streamlining transaction processing and optimizing efficiency. But how does this feature operate, and when should it be employed?

When users select and populate the "Contains Token" field with a specific token, Bitwave's rules engine springs into action. It meticulously scans transactions to identify any instance where that designated token appears. For instance, if a transaction involves multiple tokens like ETH, BTC, and USDC, and one of them matches the specified token in the "Contains Token" field, the corresponding rule linked with that token will be triggered for that transaction.

To illustrate, let's consider a scenario where a user intends to apply a specific rule exclusively to transactions involving USDC within a diverse portfolio comprising various tokens such as ETH, BTC, and USDC. By setting the "Contains Token" field to "USDC," Bitwave's rules engine diligently searches transactions to pinpoint instances where USDC is present. Consequently, if a transaction encompasses USDC along with other tokens, the associated rule tied to USDC will be enacted.

It's imperative to distinguish this feature from merely entering a token into the "Coin" field. While inputting a token into the "Coin" field restricts rule processing solely to transactions involving that token or those involving the token and a fee, the "Contains Token" option casts a wider net, capturing transactions with any token match.

The versatility of the "Contains Token" option shines, especially in decentralized finance (DeFi) environments, where specific tokens are recurrently involved. By harnessing this feature, users can seamlessly automate rule application based on the presence of particular tokens within transactions.
