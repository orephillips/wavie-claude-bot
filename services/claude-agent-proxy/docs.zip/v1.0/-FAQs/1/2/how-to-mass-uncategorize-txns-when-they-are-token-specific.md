---
title: "How to mass uncategorize txns when they are token specific."
slug: "how-to-mass-uncategorize-txns-when-they-are-token-specific"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:00:53 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
1. Disable rules for that wallet if you have rules running
2. Download the export report
3. Filter for the walletName (column F)
4. Filter for the assetTicket (column I)
5. Copy the parenttransactionIds (column B)
6. Navigate to Administration > System Jobs
7. Create Job
8. Select "CSV Bulk Action" in the action drop down
9. Download the template to create a csv file
10. Paste the parenttransactionIds copied from step 5 in column A in the template
11. Choose the action and apply to all appropriate transactions in column B
12. Upload this file to CSV Bulk Action system job and RUN
