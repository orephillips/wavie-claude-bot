---
title: "Handling Mistaken ETH Transactions"
slug: "handling-mistaken-eth-transactions"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:44:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
When receiving Ethereum (ETH) mistakenly into a corporate wallet, swift action is necessary to rectify the error. Here's the 2 simple steps recommended :

Step 1. Ignore Inflow Transaction

Step 2. Ignore Outflow Transaction
