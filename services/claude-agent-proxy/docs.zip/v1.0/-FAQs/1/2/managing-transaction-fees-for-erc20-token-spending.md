---
title: "Managing Transaction Fees for ERC20 Token Spending"
slug: "managing-transaction-fees-for-erc20-token-spending"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:41:47 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
When tracking transactions involving ERC20 tokens with no monetary value, such as those spent by your community, it's essential to account for transaction fees. 

Here's how to create a rule to auto-categorize these transactions and track associated fees:

1. Create a Rule: Set up a rule specifying the ERC20 token in the "coin" field and designate the account to record transaction fees.

2. Specify Transaction Fee Handling: Define how transaction fees should be handled within the rule, ensuring accurate accounting for gasless transactions
