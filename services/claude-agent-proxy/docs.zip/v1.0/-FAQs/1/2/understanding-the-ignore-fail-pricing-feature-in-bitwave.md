---
title: "// Understanding the \"Ignore Fail Pricing\" Feature in Bitwave"
slug: "understanding-the-ignore-fail-pricing-feature-in-bitwave"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:54:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
Have you ever encountered transactions involving tokens with zero or failed pricing and wondered how to categorize them? Bitwave has a solution for you: the "Ignore Fail Pricing" checkbox.

Here's how it works: 

Normally, Bitwave's rules engine doesn't categorize transactions without pricing information. However, when you select the "Ignore Fail Pricing" checkbox, you're telling Bitwave to forcibly categorize transactions with tokens that have zero or failed pricing.

But why would you need this feature? Imagine you're dealing with transactions containing both priced and unpriced tokens, such as rare NFTs. In such cases, you might want to categorize the entire transaction, even if some tokens lack pricing information.

It's essential to note that when you use the "Ignore Fail Pricing" feature, any tokens without pricing will automatically be assigned a value of zero. This ensures consistency and accuracy in your transaction categorization.

In summary, the "Ignore Fail Pricing" feature in Bitwave provides a simple yet powerful way to handle transactions involving tokens with zero or failed pricing. Whether you're dealing with unpriced NFTs or rare tokens, this feature empowers you to categorize transactions effectively, even in complex scenarios involving a mix of priced and unpriced tokens.
