---
title: "Categorizing NFT Transactions in Bitwave"
slug: "categorizing-nft-transactions-in-bitwave"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:40:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:38 GMT+0000 (Coordinated Universal Time)"
---
Categorizing NFT transactions accurately in Bitwave is essential for maintaining clear and organized financial records. Here's how to handle different scenarios when categorizing NFT transactions:

1. Minted NFTs for Free: If you've minted NFTs for free, 

\-create a dedicated account or category called "Free NFT Mints" to track these transactions. 

\-After categorizing the transaction, mark it as reconciled, considering its zero-dollar value.

2. Acquired NFTs with Ethereum: For NFTs acquired using Ethereum, categorize the transaction accordingly. 

Bitwave automatically handles capital gains or losses associated with selling NFTs acquired with Ethereum.
