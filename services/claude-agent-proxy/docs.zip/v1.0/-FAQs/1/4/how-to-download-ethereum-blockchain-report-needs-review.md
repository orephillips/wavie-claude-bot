---
title: "// How To download Ethereum Blockchain report- needs review"
slug: "how-to-download-ethereum-blockchain-report-needs-review"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:56:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:46 GMT+0000 (Coordinated Universal Time)"
---
To download Blockchain export (Example: Ethereum blockchain):

1. Go to <https://etherscan.io/> and paste the wallet address.
2. Navigate to transactions.
3. Scroll down the page, and below the transaction, you will find "Download: CSV export" on the right-hand side.
4. Repeat this process for all 3 tabs: Transactions, Internal Transfers, and Token Transfers.
5. After downloading all 3 CSVs, combine them into one single tab.
