---
title: "//Why Balance Report and Inventory Views don't match."
slug: "why-balance-report-and-inventory-views-dont-match"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 17:56:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:46 GMT+0000 (Coordinated Universal Time)"
---
1. There are 2 parts to each transactions in Bitwave - first is synced data which appears here  
   ​

This is what the balance report feeds off of 

2. The 2nd part of a transaction in Bitwave is categorization - seen here

The inventory dashboard and actions report are fed from categorization 

3. If there is a variance it means that something is not aligning between the synced data and the categorized data

 Take the example above ^^ transaction ID: 

 There are 3 tokens listed in this transaction

 But there is only 1 token listed under the classification section

This is causing the delta between your balance report and inventory views in 2023
