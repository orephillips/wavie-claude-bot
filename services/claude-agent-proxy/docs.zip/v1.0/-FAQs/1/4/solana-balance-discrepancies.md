---
title: "Solana Balance Discrepancies"
slug: "solana-balance-discrepancies"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:43:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:46 GMT+0000 (Coordinated Universal Time)"
---
Managing cryptocurrency portfolios comes with its share of challenges, including occasional discrepancies in balance reports. If you've encountered a negative balance for USDC while generating a Solana balance report in Bitwave, here's a step-by-step guide to resolving the issue:

1. Identify the Discrepancy: Begin by comparing the reported balance with your expectations. Take note of any discrepancies, such as negative balances, and gather relevant details for further investigation.

2. Understand the Limitations: Be aware that the Solana explorer may not provide data before a specific date. As Bitwave syncs accessible data, this limitation can affect the completeness of records and comparisons with historical data.

3. Review Transactions Manually: Take a closer look at your transactions to identify any potential issues or missing data. Check for any transfers or transactions involving USDC that may not have been recorded accurately.

4. Verify Transaction Details: Double-check the details of each transaction, including dates, amounts, and involved parties. Look for any discrepancies or anomalies that may have contributed to the negative balance.

5. Adjust and Reconcile: Make any necessary adjustments to your records to reconcile the discrepancies in your Solana balance report. Update transaction details or account for missing transactions as needed to align your records with your expectations.
