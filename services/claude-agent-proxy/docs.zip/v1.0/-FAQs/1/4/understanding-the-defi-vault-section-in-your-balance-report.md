---
title: "Understanding the DeFi Vault Section in Your Balance Report"
slug: "understanding-the-defi-vault-section-in-your-balance-report"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:55:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:46 GMT+0000 (Coordinated Universal Time)"
---
In your balance report, you may come across a section titled "DEFI VAULT." But what exactly does this mean?

The "DEFI VAULT" section denotes the presence of different Defi Pool accounts within your organization. These accounts serve as repositories for various tokens utilized in decentralized finance (DeFi) operations.

The balances listed alongside the names of each pool account provide a clear overview of the quantities of tokens held within each specific pool account. This information is crucial for tracking and managing your organization's DeFi assets effectively.

By understanding the significance of the DeFi Vault section in your balance report, you can better monitor your organization's DeFi activities and make informed decisions regarding token allocation and utilization.
