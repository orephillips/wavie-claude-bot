---
title: "General"
slug: "general-1"
excerpt: ""
hidden: true
createdAt: "Tue May 07 2024 18:48:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 15:49:59 GMT+0000 (Coordinated Universal Time)"
---
# General

***

## Q: How do i get certified in Bitwave?

### :a:: If you're interested in getting certified in Bitwave, we've got you covered! 🚀 Check out this link for all the details:

### <https://university.bitwave.io/courses/bitwave-certification>

***

## Q: How to get Organization Name and Organization ID?

### :a::

- ### Navigate to Administration
- ### Then go to Organization.
- ### You'll find the organization name and ID
- ### Double click to Highlight

***

## Q: How to get a trace ID?

### :a:﻿:﻿

1. Log in to Bitwave.
2. Right-click on the screen and select "Inspect" at the bottom of the list.
3. Once the dialog box appears , go to the "Network" tab.
4. Clear the history (on the top left of the dialog box) and refresh the page.
5. After the page reloads, click on the most recent GraphQL entry OR the entry that is showing an error (usually a red entry)
6. Go to "Headers" and copy the value next to "X-Cloud-Trace-Context", here you have the trace ID.

***

## Q: How to enable Auth sign in?

### :a:﻿:

1. If you're already signed into Bitwave, log out.
2. Double-click on the blank space located just below the last option, as shown in the provided picture

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8031134-newest.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "50% ",
      "border": true
    }
  ]
}
[/block]


3. After double-clicking, you'll see the Bitwave Auth login option.
4. Sign into your Bitwave account using the available fields.
5. Once in Bitwave Auth, select your preferred login method and click "Next.

## Q:  How to Download the Actions report from Inventory Views,  if the actions report  cannot be downloaded from the reports tab in Inventory Views ?\*\*

### :a:﻿:

1. Go To inventory views. 
2. Go to Actions Tab.
3. Select the end date and click submit. 
4. Click download actions on right-hand side to download the actions report. 

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]
