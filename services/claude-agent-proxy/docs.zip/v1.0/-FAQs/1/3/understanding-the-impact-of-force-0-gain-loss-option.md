---
title: "Understanding the Impact of \"Force 0 Gain Loss\" Option"
slug: "understanding-the-impact-of-force-0-gain-loss-option"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:38:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
When you utilize the "Force 0 Gain Loss" option on a transaction that you subsequently categorize, it's essential to comprehend how this choice influences the flow of gains and losses. Here's a clear breakdown of what happens:

1. No Impact on Quantities: First and foremost, selecting the "Force 0 Gain Loss" option does not alter the quantities involved in the transaction. The quantities remain unchanged throughout this process.
2. Effect on Dollar Values: However, this option directly affects the dollar values associated with the transaction. Specifically, it ensures that the proceeds (i.e., the fair market value disposed) become equal to the relieved cost basis.
3. Resulting in Zero Gain Loss: By aligning the proceeds with the cost basis relieved, the transaction achieves a state of zero gain or loss. This means that the transaction neither generates a profit nor incurs a loss, resulting in a neutral outcome in terms of gains and losses.
