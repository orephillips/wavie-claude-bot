---
title: "Resolving Rolled Up JE Report Issues(Internal)"
slug: "resolving-rolled-up-je-report-issuesinternal"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:39:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
Follow these  steps to identify and address the problem effectively:

Step 1: Verify the Issue Start by verifying the reported issue ourselves  to confirm its accuracy. Run the rolled-up JE report to check if it indeed fails to populate as expected.

Step 2: Test JE Report As a next step, run the regular JE report (not the rolled-up version) to see if the same issue persists. This report provides a more detailed view of the transactions and can help pinpoint any discrepancies.

Step 3: Run JE Expanded Report Additionally, run the JE Expanded report, which offers even more detailed information compared to the regular JE report. Running this report alongside the others will provide a comprehensive overview of the transactions.

Step 4: Analyze Results Carefully analyze the results of all three reports to understand the nature and extent of the issue. Pay attention to any discrepancies or missing data across the reports.
