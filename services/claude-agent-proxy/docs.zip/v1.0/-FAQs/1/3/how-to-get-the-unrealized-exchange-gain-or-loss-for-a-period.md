---
title: "How to get the unrealized exchange gain or loss for a period"
slug: "how-to-get-the-unrealized-exchange-gain-or-loss-for-a-period"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:39:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
To accurately determine these gains or losses for a specific period, follow these steps:

Step 1: Navigate to Inventory View Dashboard 

Step 2: Filter by Date Once on the Inventory View Dashboard, apply a date filter to specify the period for which you want to calculate unrealized exchange gains or losses. 

Step 3: Verify Inventory View Ensure that the Inventory View Dashboard displays a "green" indicator(NOT RED/ORANGE ), indicating that the data is current and accurate. 

Step 4: Identify FMV and Unrealized Gains On the dashboard, locate the columns labeled "FMV" (Fair Market Value) and "Unrealized Gains." 

Step 5: Download Data Download the data from the Inventory View Dashboard

Step 6: Perform Calculation in Excel Transfer the downloaded data to an Excel spreadsheet and sum up the values in the "Unrealized Gains" column. 

Understanding Unrealized Gains/Losses:

 It's essential to grasp the concept of unrealized gains or losses, which represent the potential profit or loss on investments that have not yet been realized through a sale. 

These gains or losses are calculated based on the difference between the cost basis and the fair market value (FMV) of assets at a specific point in time.

For example, if you're assessing unrealized gains as of December 31, 2023, you would compare the cost basis of your inventory to its FMV on that date. The variance between these values indicates the unrealized gains or losses as of December 31, 2023.

By following these steps and understanding the concept of unrealized gains or losses, you can effectively evaluate your organization's financial performance and make informed decisions regarding your inventory management strategies.
