---
title: "// How to extract Realized Gain/Loss Report from Inventory Views:"
slug: "how-to-extract-realized-gainloss-report-from-inventory-views"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 19:05:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
For realized Gain/Loss:

 Step 1: Navigate to inventory views. 

Step 2: Click on Report (located right next to the lots option). 

Step 3: Select cost basis roll forward.

 Step 4: Choose the date range. 

Step 5: Run the report.
