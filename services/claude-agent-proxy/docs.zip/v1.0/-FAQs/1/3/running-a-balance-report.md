---
title: "Running a Balance Report"
slug: "running-a-balance-report"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:55:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
Following these steps will guide you through the process of running a balance report, including setting the date, choosing how to group the data, and generating the report.  
​

1. Click on the "Reports" tab.
2. Within the Reports section, choose `Balance Report`
3. Fill out the required date for the balance report.
4. Navigate to the `Group by` option and select your preferred choice from the available options: `None` or `Wallets`.
5. Click on the "Run" button to generate the balance report.
