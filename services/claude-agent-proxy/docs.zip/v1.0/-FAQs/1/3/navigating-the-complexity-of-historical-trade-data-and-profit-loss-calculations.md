---
title: "Navigating the Complexity of Historical Trade Data and Profit &Loss Calculations"
slug: "navigating-the-complexity-of-historical-trade-data-and-profit-loss-calculations"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:04:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
When considering making changes to your data connections, especially involving historical trade data and profit and loss (P&L) calculations, it's crucial to tread carefully to avoid unintended consequences. Let's delve into the  potential solutions:

.

Two Potential Paths:

Path 1 - Cleanest Approach: Deleting both connections and reconnecting solely with the Coinbase exchange connection may be the cleanest path forward. This ensures a fresh start and minimizes the risk of data discrepancies

.

Path 2 - Engineering Intervention: Alternatively, we could explore the possibility of deleting only the Coinbase Pro connection. Subsequently, our engineering team could resync the Coinbase exchange connection to restore any inadvertently deleted transactions. However, this approach may require multiple resyncs.
