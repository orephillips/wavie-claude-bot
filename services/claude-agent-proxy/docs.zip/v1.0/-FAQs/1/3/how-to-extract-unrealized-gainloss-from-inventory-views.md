---
title: "//How to extract Unrealized Gain/Loss from Inventory Views"
slug: "how-to-extract-unrealized-gainloss-from-inventory-views"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 19:04:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:42 GMT+0000 (Coordinated Universal Time)"
---
For unrealized Gain/Loss:

 Step 1: Navigate to the inventory view dashboard. 

Step 2: Filter to your specific DATE. 

Step 3: Confirm that the inventory view displays GREEN (not Red or Orange). 

Step 4: On the dashboard, locate the columns for FMV and unrealized gains.

 Step 5: Download the summary. Step

 6: Total the unrealized column in Excel.
