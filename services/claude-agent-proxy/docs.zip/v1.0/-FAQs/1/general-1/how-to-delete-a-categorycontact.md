---
title: "How to delete a category/contact?"
slug: "how-to-delete-a-categorycontact"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:02:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:32 GMT+0000 (Coordinated Universal Time)"
---
1. Contact a Bitwave team member. 
2. Provide your Org ID, Org Name, Accounting Connection Type (QBO, Nesuite, Sage..)
3. Also provide the name of the Category or Contact you want deleted AND the BITWAVE ID for that particular category/contact.
