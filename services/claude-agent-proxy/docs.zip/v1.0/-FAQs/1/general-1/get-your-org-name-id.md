---
title: "Get your Org Name & ID"
slug: "get-your-org-name-id"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 19:01:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:32 GMT+0000 (Coordinated Universal Time)"
---
In the left-hand corner of your Bitwave app, 

1. Navigate to Administration 
2. Then go to Organization. 
3. You'll find the organization name and ID 
4. Double click to Highlight listed there.
