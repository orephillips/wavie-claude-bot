---
title: "Get Your Wallet Name &ID"
slug: "get-your-wallet-name-id"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 19:02:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 15 2024 22:19:32 GMT+0000 (Coordinated Universal Time)"
---
In the left-hand corner of your Bitwave app, go to "Wallets & Connection."

1. Navigate to "Wallets."
2. Click on "Details."
3. You'll find the wallet name and ID listed.
4. Double Click to Highlight
