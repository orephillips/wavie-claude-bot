---
title: "Other"
slug: "other"
excerpt: ""
hidden: true
createdAt: "Mon Mar 04 2024 18:49:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 04 2024 18:49:20 GMT+0000 (Coordinated Universal Time)"
---
Congratulations on passing your exam!

To claim your certification and NFT, simply use this  link and follow the prompt.

Thank you for choosing Bitwave!
