---
title: "get"
slug: "geteffectiverate"
excerpt: "Get the entries from a rate table"
hidden: false
createdAt: "Mon Feb 12 2024 20:12:46 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Feb 12 2024 20:12:46 GMT+0000 (Coordinated Universal Time)"
---
