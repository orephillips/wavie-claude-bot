---
title: "Add Coinbase Retail API"
slug: "add-coinbase-retail-api"
excerpt: ""
hidden: false
createdAt: "Wed Jan 11 2023 15:11:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 17 2025 16:12:30 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Generate Your Keys  
Step 2: Configure the API Keys  
Step 3: Link Your Keys to Bitwave  
Step 4: Success!

## Step 1: Generate Your Keys

1. Sign into your Coinbase Retail account and click on Profile.
2. Navigate to your API settings.
3. Click the Create API key button.
4. In the popup dialog configure:  
   **•** API key nickname  
   **•** Portfolio  
   **•** Permissions (editing this value prompts 2FA)  
   **•** IP allowlist  
   **• **ECDSA key type (Ed25519 is not yet supported)
5. Click Create & Download.
6. Copy and secure your private/public key pair in a safe location.
7. Click I've saved my key.

<br />

![](https://files.readme.io/7e92b01a05cea5015cd18187b288f2f459d3ed804b77bb6cde2cc206abcb5f6d-create-retail-api-key-5b16486a65a47402ff8f883a8019c3df.png)

<br />

## Step 2: Configure the API Keys

Compared to CDP API keys which follow ECDSA format and have the following characteristics:

1. Key name is 64 characters long
2. Key secret is 128 characters long

**Here is what Coinbase will output on the website:**

**Example CDP key name:**

`organizations/8f1ac569-ed29-48ae-b989-6798a975afab/apiKeys/87d98ae9-f31f-42ee-9b69-723d3ff9dd77`

**Example CDP key secret:**

`-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIJsB+NpntMgnAHSo16vS6ies3V6nu/liXhPMd7s7+lZ6oAoGCCqGSM49\nAwEHoUQDQgAEs0MXQHmufOeRPhjeJOkyNPJjaZv.....................Zb5S\nFBoh2Je3Rkj3do3+CU6OVOI7MzXPCX33NQ==\n-----END EC PRIVATE KEY-----\n`

## Step 3: Link Your Keys to Bitwave

1. Sign into your Bitwave account and click on the Wallets & Connections Tab
2. Navigate to Connections within **Wallets & Connections**
3. Click the **Connect New Account** button on top-left
4. Select **Coinbase Retail**
5. Fill in the following to Bitwave:  
   a. **API Key**: This will be your CDP key name as explained above.  
   b. **Private Key**: This will be your CDP key secret and all the **\\n** should be removed while validating/adding the private key.

**Here is how that should be plugged into Bitwave.**

**Bitwave API key name:**

`organizations/8f1ac569-ed29-48ae-b989-6798a975afab/apiKeys/87d98ae9-f31f-42ee-9b69-723d3ff9dd77`

**Bitwave Private key:**

`-----BEGIN EC PRIVATE KEY-----MHcCAQEEIJsB+NpntMgnAHSo16vS6ies3V6nu/liXhPMd7s7+lZ6oAoGCCqGSM49AwEHoUQDQgAEs0MXQHmufOeRPhjeJOkyNPJjaZv.....................Zb5SFBoh2Je3Rkj3do3+CU6OVOI7MzXPCX33NQ==-----END EC PRIVATE KEY-----`

c. **Exchange Contact**  
  i. This is usually a contact from your ERP software  
  ii. If you aren't using an ERP integration, you can create one in Company > Contacts > Create Contact  
  iii. You must use distinct values for Remote ID

## Step 4: Success!

Be sure to click on the Sync button and our system will begin to sync over your transaction history. This can take up-to 24 hours.

Bitwave can hide unused Coinbase wallets after they have been loaded in. If this is something you would be interested in then simply inform your Bitwave representative with a list of the wallets to be hidden.
