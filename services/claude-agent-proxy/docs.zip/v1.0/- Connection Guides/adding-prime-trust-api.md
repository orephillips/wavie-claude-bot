---
title: "Adding Prime Trust API"
slug: "adding-prime-trust-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Nov 15 2022 18:11:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Nov 15 2022 21:35:51 GMT+0000 (Coordinated Universal Time)"
---
To connect Prime Trust to Bitwave:

Request a JWT for the following GET endpoints from Prime Trust.  
Please make sure these are **read only access** and not write access.

`/v2/assets/{id}`  
`/v2/asset-transactions/{id}`  
`/v2/cash-transactions/{id}`  
'/v2/asset-transactions'  
'/v2/cash-transactions'  
'/v2/asset-transfers'  
'/v2/account-cash-transfers'  
'/v2/trades'  
'/v2/assets'  
'/v2/accounts'  
'/v2/contacts'  
'/v2/account-asset-totals'  
'/v2/account-cash-totals'
