---
title: "Add Binance API"
slug: "adding-binance-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 14:29:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:25:04 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Generate Your Keys  
Step 2: Confirm Your Request  
Step 3: Link Your Keys to Bitwave  
Step 4: Success!

## Step 1: Generate Your Keys

1. Sign into your Binance account and click on **Account**

![](https://files.readme.io/9c6ffc0-1.png "1.png")

2. Click on API Settings

![](https://files.readme.io/b047145-2.png "2.png")

3. Type a name for your Key. In this example, we are linking it to the Bitwave App so the name Bitwave is appropriate. Then click on Generate Key

![](https://files.readme.io/a7596f4-3.png "3.png")

## Step 2: Confirm Your Request

1. You should now see a message letting you know that a confirmation email has been sent out.

![](https://files.readme.io/9e3828f-4.png "4.png")

2. Check your email address. Binance sends a confirmation email for security purposes. It will be titled: [Binance] Create New API Key. Open it and click on Confirm Key. Keep in mind that you have 30 minutes to confirm before the link expires. This is a security measure set by Binance.

![](https://files.readme.io/8df9faa-5.png "5.png")

3. The link will take you back to Binance and you will be able to see both the API Key and the Secret Key you just generated.

![](https://files.readme.io/2919693-6.png "6.png")

## Step 3: Link Your Keys to Bitwave

1. Sign into your Bitwave account and click on the **Organization** Tab
2. Navigate to the **Connections** tab within **Organization**
3. Click the **Connect New Account** button on top-left
4. Select **Binance**
5. Fill in the following to Bitwave:  
   a. Connection Name (Optional)  
   b. API Key  
   c. API Secret  
   d. Exchange Contact  
       i. This is usually a contact from your ERP software  
       ii. If you aren't using an ERP integration, you can create one in Company > Contacts > Create Contact  
           1. You must use distinct values for Remote ID

![](https://files.readme.io/09c8efc-7.png "7.png")

## Step 4: Success!

Be sure to click on the Sync button and our system will begin to sync over your transaction history. This can take up-to 24 hours.

**Please note: the above is for Binance - if you are using \[**Binance.us\*\*](<http://Binance.us>) there is a video below showing how to create the API. The secret API key is masked in the video as the email was opened in a different tab.

[https://www.loom.com/share/0305dc58807b4fef82efa547e43a7f67]  
([https://www.loom.com/share/0305dc58807b4fef82efa547e43a7f67])
