---
title: "Importing Transactions Manually"
slug: "importing-transactions"
excerpt: ""
hidden: true
createdAt: "Mon Oct 03 2022 15:21:49 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 22 2024 03:16:43 GMT+0000 (Coordinated Universal Time)"
---
Follow this link for a how-to-guide on how to manually import transactions into Bitwave.

[https://bitwave.stonly.com/kb/guide/en/segment-3d-import-data-from-external-sources-lie2W2rvsl/Steps/1101101  
](https://bitwave.stonly.com/kb/guide/en/segment-3d-import-data-from-external-sources-lie2W2rvsl/Steps/1101101)
