---
title: "Xero Integration and Testing Guide"
slug: "xero-integration-and-testing-guide"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 18:03:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Oct 14 2022 18:03:44 GMT+0000 (Coordinated Universal Time)"
---
This document provides step-by-step instructions on how to set up the connection between Bitwave and Xero.

## Create Connection

1. Login to app.bitwave.io
2. Go to Wallets & Connections → Connections
3. Click CREATE NEW ACCOUNT

![](https://files.readme.io/ffe8554-1.png "1.png")

Click Connect to Xero button

![](https://files.readme.io/cb461b4-2.png "2.png")

5. Login into Xero, select Organization you want to connect, and click Allow access

![](https://files.readme.io/c9263f4-3.png "3.png")

6. Click FINISH SETUP button

![](https://files.readme.io/88af33f-4.png "4.png")

7. Enter Account Code and Fee Account Code, and click Save

![](https://files.readme.io/fa03f4b-5.png "5.png")

8. Click SYNC button

![](https://files.readme.io/315a0d2-6.png "6.png")

## Sync Categories

GL Chart of Accounts are automatically synced to Bitwave as Categories. Users can manually sync Chart of Accounts as well by clicking SYNC button in Connections page.

To review Categories, goto Accounting → Categories

![](https://files.readme.io/7f82945-7.png "7.png")

## Sync Contacts

Customers and Vendors are automatically synced to Bitwave as Contacts. Users can manually sync Customers and Vendors as well by clicking SYNC button in Connections page.

To review Contacts, goto Accounting → Contacts

![](https://files.readme.io/0db363e-8.png "8.png")

## Sync Invoices

Invoices are automatically synced to Bitwave as Customer Invoices. Users can manually sync Invoices as well by clicking SYNC button in Connections page.

To review Customer Invoices, goto AR/AP → Customer Invoices

![](https://files.readme.io/71fd293-9.png "9.png")

## Sync Bills

Bills are automatically synced to Bitwave as Vendor Bills. Users can manually sync Vendor Bills as well by clicking SYNC button in Connections page.

To review Customer Invoices, goto AR/AP → Vendor Bills

![](https://files.readme.io/f097616-10.png "10.png")

## Reconcile Transactions to Xero

Create Wallet

1. Go to Wallets & Connections → Wallets and click CREATE WALLET button

![](https://files.readme.io/a71fded-11.png "11.png")

2. Select Wallet Type = Manual Wallet and enter Name and Description

![](https://files.readme.io/c7b9b1e-12.png "12.png")

Click Save

## Create Transaction

1. Go to Transactions → All Transactions

![](https://files.readme.io/bf93640-13.png "13.png")

2. Click ACTIONS → Create Transaction

![](https://files.readme.io/ba6f41d-14.png "14.png")

3. Enter details as follows  
   a. Type of Transaction = Manual Transaction  
   b. Wallet = Manual  
   c. Transaction Date = <select a past date>  
   d. Transaction Time = <select a time>  
   e. Manual Transaction Type = Deposit  
   f. Amount = 1  
   g. Coin = ETH

![](https://files.readme.io/b5f9ae7-15.png "15.png")

4. Click SAVE

## Categorize Transaction

1. Go to Transactions → All Transactions

![](https://files.readme.io/ef55ebb-16.png "16.png")

2. Click CATEGORIZE
3. Enter details as follows  
   a. Category = Other Revenue  
   b. Contact = Bayside Club

![](https://files.readme.io/ab4399e-17.png "17.png")

4. Click SAVE

## Reconcile Transaction

1. Go to Accounting → Reconcile

![](https://files.readme.io/2860471-18.png "18.png")

2. Select a row and click RECONCILE 1 SELECTED TRANSACTION

![](https://files.readme.io/1d1bf20-19.png "19.png")

## Verify Transaction in Xero

1. Login to Xero account
2. Select the organization you connected to Bitwave

![](https://files.readme.io/c7b7d7c-20.png "20.png")

3. Go to Accounting → Bank Accounts

![](https://files.readme.io/3ca87f8-21.png "21.png")

4. Click on Bitwave - Digital Assets

![](https://files.readme.io/7b43858-22.png "22.png")

5. Verify the transaction. Received amount is same as Bitwave transaction amount

![](https://files.readme.io/adb9be7-23.png "23.png")

6. Make sure reference is same as Id of transaction in Bitwave

![](https://files.readme.io/ba821fd-24.png "24.png")
