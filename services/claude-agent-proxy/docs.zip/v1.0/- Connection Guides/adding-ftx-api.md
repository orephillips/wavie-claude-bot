---
title: "Add FTX API"
slug: "adding-ftx-api"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 15:45:08 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:25:12 GMT+0000 (Coordinated Universal Time)"
---
This is a step-by-step guide on how to create an API key on FTX exchange.

## 1. Create API key on FTX Exchange

1. [Log in](https://ftx.com/) to your FTX account. If you don't have one, you can create an account using our [referral link](https://ftx.com/referrals#a=70034854).

2. Click on your username and choose Settings. On the Settings page, click on the API tab:

![](https://files.readme.io/01c5123-1.png "1.png")

3. Click on the “Create Read-Only API key” button. Safely save the API key and API Secret key displayed on the pop-up. NB: API Secret key is shown only during this step – once you close the pop-up, you won’t be able to see it again. Please save it safely at this step.
