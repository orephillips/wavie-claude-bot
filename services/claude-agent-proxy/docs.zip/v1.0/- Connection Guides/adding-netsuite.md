---
title: "NetSuite Connection"
slug: "adding-netsuite"
excerpt: ""
hidden: false
createdAt: "Fri Oct 14 2022 18:10:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Feb 28 2024 04:42:53 GMT+0000 (Coordinated Universal Time)"
---
Bitwave NetSuite Integration  
v1.2

![](https://files.readme.io/faa1d79-0.png "0.png")

![](https://files.readme.io/5cbe0c4-1.png "1.png")

![](https://files.readme.io/082b6a9-1.1.png "1.1.png")

![](https://files.readme.io/fe71384-2.png "2.png")

![](https://files.readme.io/ef93499-1706245678496-5ca63e35-bd71-4651-87cd-0a2c3d25e1d2_6.jpg)

![](https://files.readme.io/28e80fe-3.png "3.png")

![](https://files.readme.io/cb84362-4.png "4.png")

![](https://files.readme.io/583f838-5.png "5.png")

![](https://files.readme.io/e92b88b-6.png "6.png")

![](https://files.readme.io/cb79afd-7.png "7.png")

![](https://files.readme.io/4e3a365-8.png "8.png")

STEP 28

NETSUITE SETUP FOR AR/AP  
Within Netsuite In order to perform AR and AP from bitwave to netsuite  
Bitwave AR Clearing Account of TYPE BANK is required to be setup  
Bitwave AP Clearing Account of TYPE BANK is required to be setup

BITWAVE SETUP FOR AR/AP  
Proceed to Administration -> Accounting Setup  
Choose the AR clearing Account identified above as your Default  Account Receivable Category  
Choose the AP Clearing Account identified above as your Default Account Payable Category

![](https://files.readme.io/d347026-image_2.png)
