---
title: "Add SCIM connection"
slug: "add-scim-connection"
excerpt: ""
hidden: false
createdAt: "Tue Jan 30 2024 21:14:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jan 30 2024 21:14:23 GMT+0000 (Coordinated Universal Time)"
---
Download PDF [HERE](https://drive.google.com/file/d/1bWk7qs5xfQoamU9KXtcefMfmerFtK_Lr/view?usp=sharing)
