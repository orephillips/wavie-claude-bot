---
title: "Add Anchorage API"
slug: "anchorage-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 18:31:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:24:52 GMT+0000 (Coordinated Universal Time)"
---
## Make sure to generate a V2 Key

[SOURCE](https://anchorage-api.netlify.app/#section/Authentication-and-Security/API-Keys)

All API requests must be made over HTTPS and must include authentication using the following scheme.

## Generating an API Access Key

In order to make a valid API request, you must first create an API key. API keys can be created and managed in the Anchorage Digital Web Dashboard under the [API 2.0 tab](https://anchoragelogin.com/api). When you create an API key, there are 3 pieces of information you will need to remember:

- API access key
- Ed25519 public key (optional for read-only requests)
- Ed25519 private/signing key (optional for read-only requests)

You must generate an Ed25519 signing key pair and save the public portion in the Anchorage Digital Web Dashboard when creating the API access key. The signing key pair is used for added security with sensitive requests.

Please note, Anchorage Digital cannot recover your API access key or private signing key if you forget them. You may generate a new access key and signing key at any time if you lose access.

|                        |                |
| :--------------------- | :------------- |
| Security Scheme Type   | API Key        |
| Header parameter name: | Api-Access-Key |
