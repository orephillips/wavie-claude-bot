---
title: "Setup SSO"
slug: "setup-sso"
excerpt: ""
hidden: false
createdAt: "Fri Jun 07 2024 15:09:53 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Feb 21 2025 13:55:42 GMT+0000 (Coordinated Universal Time)"
---
Okta SETUP:

1. The information provided from bitwave will be the Single sign on URL and the Audience URL. 

- Single sign on URL: <https://api.bitwave.io/saml>
- Audience URI (SP Entity ID): <https://api.bitwave.io/metadata.xml>

2. Your settings should look similar to the image below.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5a87f39-oktasso.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "75% "
    }
  ]
}
[/block]


3. All other fields are inputted by the user.
4. Next go to Bitwave. Go to Security -> SSO. And fill in details.

![](https://files.readme.io/870d8ab-image.png)

5. The user must enter the asserted identity to align with the information received from Okta or their SSO provider.

![](https://files.readme.io/fabc4ea4d7f9bae7df2774148dff1e83e4affa85c1839ad986658935a5e1fb6b-SSO.png)
