---
title: "Add Coinbase Prime/Exchange API"
slug: "connecting-coinbase-proexchange"
excerpt: ""
hidden: false
createdAt: "Fri Sep 30 2022 19:59:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 04 2024 21:07:55 GMT+0000 (Coordinated Universal Time)"
---
## How to setup Coinbase Prime/Exchange API Keys

### Step 1: Generate Your Keys

Sign into your Coinbase Pro account and click on your username, then click on **API**

![](https://files.readme.io/f06ddc0-Coinbase_1.png "Coinbase 1.png")

Make sure you are on the **API Setting** tab, then click on **New API Key**

![](https://files.readme.io/402b7ee-Coinbase_2.png "Coinbase 2.png")

Tick the **View** box under permissions and then save the **Passphrase.** You will need to use that later when linking your Bitwave organization. Click on **Create Key**

![](https://files.readme.io/937b471-Coinbase_3.png "Coinbase 3.png")

### Step 2: Save Your Keys

After clicking on **Create Key**, a new window will appear showing your **API Secret Key**. Save this Key, then click **Done**

![](https://files.readme.io/eeed30f-Coinbase_4.png "Coinbase 4.png")

After hitting **Done**, the API Settings tab will appear once again. This time, however, there will be a new API Key in your list. The Key highlighted in red is your **API Key**

![](https://files.readme.io/0bf6c2a-Coinbase_5.png "Coinbase 5.png")

### Step 3: Link Your Keys to Bitwave

1. Sign into your Bitwave account and click on the **Organization** Tab
2. Navigate to the **Connections** tab within **Organization**
3. Click the **Connect New Account** button on top-left
4. Select **Coinbase Pro/Prime**
5. Fill in the following to Bitwave:
   1. API Key
   2. API Secret
   3. API Passphrase
   4. Exchange Contact
      1. This is usually a contact from your ERP software
      2. If you aren't using an ERP integration, you can create one in Company > Contacts > Create Contact
         1. You must use distinct values for Remote ID

![](https://files.readme.io/2cffbeb-Coinbase_6.png "Coinbase 6.png")

### Step 4: Success!

Be sure to click on the Sync button and our system will begin to sync over your transaction history. This can take up-to 24 hours.

## How to Update Your Coinbase Prime/Exchange Connection Keys

Step 1: Navigate to Wallets & Connections > Connections

Step 2: Select "Update Credentials" 

![](https://files.readme.io/fafd8e5-image.png)

Step 3: Obtain the following fields from your Coinbase Prime or Coinbase Exchange account

- API Key: Follow [Step 1](https://docs.bitwave.io/docs/connecting-coinbase-proexchange#step-1-generate-your-keys) from the previous section
- Passphrase: Follow [Step 1](https://docs.bitwave.io/docs/connecting-coinbase-proexchange#step-1-generate-your-keys) from the previous section
- Signing Key: Follow [Step 2](https://docs.bitwave.io/docs/connecting-coinbase-proexchange#step-2-save-your-keys) from the previous section

![](https://files.readme.io/00f8e10-image.png)

Step 4: Select SAVE. Success!
