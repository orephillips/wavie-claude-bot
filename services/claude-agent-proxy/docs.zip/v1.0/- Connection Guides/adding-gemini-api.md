---
title: "Add Gemini API"
slug: "adding-gemini-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 14:42:49 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:24:56 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Generate Your Keys  
Step 2: Save Your Keys  
Step 3: Link Your Keys to Bitwave  
Step 4: Success!

## Step 1: Generate Your Keys

1. Open the Gemini [API Settings](https://exchange.gemini.com/settings/api) Page
2. Select **Primary** as scope
3. Click the **Create a New API Key** button
4. If applicable, enter your **two-factor authentication code**

## Step 2: Save Your Keys

1. Copy the **API Key** and **API Secret**
2. Under the **API Key Settings**, disable **Trading** and enable **Auditor**

## Step 3: Link Your Keys to Bitwave

1. Sign into your Bitwave account and click on the **Wallets & Connections**
2. Navigate to **Connections** under "Wallets & Connections” or click [here](https://app.bitwave.io/#/connections)
3. Click the **Connect New Account** button on top-left
4. Select **Gemini**
5. Fill in the following to Bitwave:  
   a. API Key  
   b. API Secret  
   c. Exchange Contact  
       i. This is usually a contact from your ERP software  
       ii. If you aren't using an ERP integration, you can create one in Company > Contacts > Create Contact
   1. You must use distinct values for Remote ID

![](https://files.readme.io/09c523d-1.png "1.png")

## Step 4: Success!

Be sure to click on the Sync button and our system will begin to sync over your transaction history. This can take up-to 24 hours.
