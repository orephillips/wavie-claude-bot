---
title: "Add Bitfinex API"
slug: "adding-bitfinex-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 14:48:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:24:49 GMT+0000 (Coordinated Universal Time)"
---
## How to create an API key

1. Firstly, go to your [API Key page](https://setting.bitfinex.com/api).

2. Then, choose the _Create New Key_ tab.

3. Here, choose the required permissions you would like to enable:

- _Account Info:_ lets you receive account fee information and/or edit account information;
- _Account History:_ provides you with the ability to view and download information on the detailed trading activities of your account;
- _Orders:_ view the orders on your account, also providing the option to create and cancel orders;
- _Margin Trading:_ view margin positions and information, you can also turn on the ability to claim your open positions;
- _Margin Funding:_ provides status information and can give you access to offer, cancel and close funding;
- _Wallets:_ allows access to balances and addresses with an option of transferring between your wallets;
- _Withdrawals:_ enables withdrawals through the API.

4. Label your API Key. This is an optional choice that can help you easily identify it after creation.

![](https://files.readme.io/0fe39a8-1.png "1.png")

5. Click **Generate API Key** once you have confirmed all your settings, and we’re almost finished!

6. For security reasons, you will need to confirm the creation via your 2FA code (or U2F device, depending on your security setup).

7. Go to your email where you will receive an email with a confirmation link; click the **Create API Key** button to complete the process:

![](https://files.readme.io/80b5893-2.png "2.png")

**Note:** Make sure to access the email confirmation using the same browser as your Bitfinex page. If clicking the link takes you to another browser, you can copy and paste the link to the browser you are using with your Bitfinex website.

8. Congratulations! You have now created your API key. The page will show both your **API Key** and **API Key Secret** in text and as a QR code. You can either scan the code or copy and paste the text according to your needs.

![](https://files.readme.io/ad4d56f-3.png "3.png")

Important: The API Key information will be displayed to you only once. For security reasons, do not store your API Key online as it could be compromised.
