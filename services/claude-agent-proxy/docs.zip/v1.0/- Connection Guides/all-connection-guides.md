---
title: "All Connection Guides"
slug: "all-connection-guides"
excerpt: ""
hidden: false
createdAt: "Fri May 17 2024 22:19:53 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 17 2024 22:23:51 GMT+0000 (Coordinated Universal Time)"
---
- [Bitfinex](https://docs.bitwave.io/docs/adding-bitfinex-api)
- [Anchorage](https://docs.bitwave.io/docs/anchorage-api)
- [Gemini](https://docs.bitwave.io/docs/adding-gemini-api)
- [Kraken](https://docs.bitwave.io/docs/adding-kraken-api)
- [Binance](https://docs.bitwave.io/docs/adding-binance-api)
- <https://docs.bitwave.io/docs/connecting-coinbase-proexchange>
- <https://docs.bitwave.io/docs/add-coinbase-retail-api>
- [Bittrex](https://docs.bitwave.io/docs/adding-bittrex-api)
- [Bitstamp](https://docs.bitwave.io/docs/adding-bitstamp-api-2)
- [Bitgo](https://docs.bitwave.io/docs/adding-bitgo)
- [Prime Trust](https://docs.bitwave.io/docs/adding-prime-trust-api)
