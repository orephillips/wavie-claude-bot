---
title: "Adding BitGo"
slug: "adding-bitgo"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 18:28:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Oct 14 2022 18:28:56 GMT+0000 (Coordinated Universal Time)"
---
The BitGo Access Token works as an API that once imported into Bitwave will let you track your balances and past transactions, and it will automatically update.

Note: The term **Access Token** refers to an **API Key**.

**To obtain an Access Token / API key from BitGo, follow the steps :**

1. **Login** to the BitGo UI ([app.bitgo.com](http://app.bitgo.com/))
2. Navigate to the **Account Settings** page.
3. Navigate to the **Develop Options** section.
4. Choose the **Access Token** option - Create a long-lived API Access tokens

![](https://files.readme.io/a664fd7-1.png "1.png")

**To create a BitGo Access Token (API Key), follow these steps:**

1. Give the API Access Token a memorable name.
2. Jump all the way down to “IP Addresses Allowed”. Here, you need to type Bitwave’s IP address. **The IP address is**  
   a. 104.196.183.18  
   b. 35.230.22.143
3. Please also make sure that you assign the correct Permission to the API.

   (All **View** permissions should be selected) 
4. Read & Agree to the **Terms of Conditions**
5. Click **Add Access Token!**

**Awesome you have successfully created your Bitgo Access token!**

![](https://files.readme.io/751494a-2.png "2.png")

![](https://files.readme.io/79572fc-3.png "3.png")
