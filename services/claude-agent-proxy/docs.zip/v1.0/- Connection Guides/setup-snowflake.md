---
title: "Setup Snowflake"
slug: "setup-snowflake"
excerpt: ""
hidden: false
createdAt: "Wed Apr 16 2025 13:02:55 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Apr 16 2025 13:09:36 GMT+0000 (Coordinated Universal Time)"
---
To ensure a smooth integration and accurate change tracking, follow these two key steps:

✅ **Step 1: Enable Change Tracking on the Table**

Bitwave requires `CHANGE_TRACKING` to be enabled on the table. This allows Bitwave to create streams and track all updates, inserts, and deletions on your data.

Run the following SQL command:  
`ALTER TABLE your_table_name SET CHANGE_TRACKING = TRUE;`

📘 Reference: [Snowflake CHANGE_TRACKING Documentation](https://docs.snowflake.com/en/sql-reference/sql/alter-table#set-change_tracking)

📤 **Step 2: Share the Table via Snowflake Direct Share**

Use Snowflake Direct Share to securely share your table with Bitwave.

Follow the steps outlined under “To create a direct share to share data with other accounts” in the Snowflake documentation:

🔗 [Snowflake Direct Share Documentation](https://docs.snowflake.com/en/user-guide/data-sharing-direct-creating)

**_🌍 Bitwave Snowflake Account Identifiers_**

Please share the table with the appropriate Bitwave Snowflake account based on your region:

**EU Bitwave Account:** NWFPGPZ.BWEU68547

**North America Bitwave Account:** NWFPGPZ.HCB36210
