---
title: "Add Bittrex API"
slug: "adding-bittrex-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 14:54:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:25:08 GMT+0000 (Coordinated Universal Time)"
---
**How to create an API key?**

Before you can create an API key, you'll need to meet the following basic requirements:

- Your account must be Identity Verified.
- Your account must have two-factor authentication (2FA) enabled which you can do at [Bittrex.com - Two-Factor Authentication](https://bittrex.com/Manage?view=2fa).
- You must be logged in to the site for at least 3 minute before creating an API key.

After meeting the basic requirements, you can create and API key following the steps below:

1. Go to <https://bittrex.com> and log in to your account.

![](https://files.readme.io/74914ee-1.png "1.png")

2. Navigate to the **Account** tab in the upper right corner.

3. Under **Account**, navigate to **API Keys** on the left.

![](https://files.readme.io/78edf0e-2.png "2.png")

4. Click Add new key...

![](https://files.readme.io/d0b79fd-3.png "3.png")

5. Depending on how much functionality you’d like for your API Key, toggle the on/off switch for READ INFO, TRADE, and WITHDRAW.

![](https://files.readme.io/16a1b03-4.png "4.png")

6. When you've selected the functionality you want for your API Key, click Save which will open the Authenticator Code box. Input your 2FA code from your authenticator app and click Confirm.

![](https://files.readme.io/cd5fefc-5.png "5.png")

7. After your API Key has been created, your Key and Secret will be shown on the API Keys page. Your secret key will only be displayed once and will disappear after you refresh the page. Make sure to save your secret key.

![](https://files.readme.io/27a1010-7.png "7.png")

## Deleting your API Key

1. Click the **X** icon on the far right side for the key you want to delete.
2. Click the **Save** button
3. Input your 2FA code from your authenticator app and click on **Confirm**. Your API Key will be deleted.

**Note:** You will receive an email notification of any changes made to your API keys.
