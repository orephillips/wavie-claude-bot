---
title: "Add Bitstamp API"
slug: "adding-bitstamp-api-2"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 17:42:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:25:15 GMT+0000 (Coordinated Universal Time)"
---
Source: <https://help.blockpit.io/hc/en-us/articles/360011790140-How-do-I-get-my-Bitstamp-API-key>

1. Log in to your [Bitstamp account](https://www.bitstamp.net/).
2. Click on the **Profile Icon** in the upper-right corner and select **Settings**.
3. Now select **API access** on the left and press the green button **New API Key**.
4. Create a new key and select only the **Account balance** and **User transactions** permissions and activate the key.(You may need to enter the 2FA code to create the API key).

![](https://files.readme.io/1d6b1d8-Bildschirmfoto_2022-03-21_um_21.39.42.png "Bildschirmfoto_2022-03-21_um_21.39.42.png")

5. To import your data, you must first create a **Depot** in the [Blockpit Web App](https://app.blockpit.io/dashboard).To do so, click the top menu item on **Create New** and select **Add Depot**.
6. Activate the generated key and enter the **Key**, the **Secret** and your **Customer ID** (displayed under account) into your **Blockpit Bitstamp Depot**.

## Which data can be imported via Bitstamp API?

Your complete transaction history always serves as the basis for your tax report. Preferably, automatic API solutions are used to import your transactions. Our team is committed to implementing all API data provided by your exchange for you.

Using the following list, you can identify all products that are implemented:

• **Transactions: Complete import scope** Deposits & Withdrawals Fee Payments Spot Market Trades

```
In case of missing transactions, you can identify them in the history of your exchange and help our support team via **[ticket](https://help.blockpit.io/hc/de-at/requests/new)** to include them in our import spectrum.
```

• **Asset Balance Display:** **Complete import scope**

```
If balances are not or incorrectly displayed, you can help our support team via **[ticket](https://help.blockpit.io/hc/de-at/requests/new)** to include them in our API import scope.
```
