---
title: "Add Kraken API"
slug: "adding-kraken-api"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Oct 14 2022 13:50:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Oct 17 2022 15:25:00 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Generate Your Keys  
Step 2: Configure the API Settings  
Step 3: Link Your Keys to Bitwave  
Step 4: Success!

## Step 1: Generate Your Keys

1. Sign into your Kraken account and click on the **Settings** Tab
2. Click on the **API** function
3. Click on **Generate New Key**

![](https://files.readme.io/0882cb7-1.png "1.png")

## Step 2: Configure the API Settings

1. Tick all the allowable actions below:  
   a. Query Funds  
   b. Query Open Orders & Trades  
   c. Query Closed Orders & Trades  
   d. Query Ledger Entries  
   e. Export Data  
   f. Change “Nonce window” to 10000

![](https://files.readme.io/0f47192-2.png "2.png")

Bitwave needs these permissions to function properly. However, make sure to leave the following actions unchecked:

- Deposit Funds
- Withdraw Funds
- Modify Orders
- Cancel/Close Orders

This is just a precautionary measure. Bitwave cannot and will never be able to withdraw or access your funds on any exchange.

1. Click on **Generate Key**
2. Your **API** and **Private Key** will be displayed

![](https://files.readme.io/72d4449-3.png "3.png")

## Step 3: Link Your Keys to Bitwave

1. Sign into your Bitwave account and click on the **Wallets & Connections** Tab
2. Navigate to [**Connections**](https://app.bitwave.io/#/connections) within **Wallets & Connections**
3. Click the **Connect New Account** button on top-left
4. Select **Kraken**
5. Fill in the following to Bitwave:  
   a. API Key  
   b. Private Key  
   c. Exchange Contact  
       i. This is usually a contact from your ERP software  
       ii. If you aren't using an ERP integration, you can create one in Company > Contacts > Create Contact  
           1. You must use distinct values for Remote ID

![](https://files.readme.io/0b69bb5-4.png "4.png")

## Step 4: Success!

Be sure to click on the Sync button and our system will begin to sync over your transaction history. This can take up-to 24 hours.
