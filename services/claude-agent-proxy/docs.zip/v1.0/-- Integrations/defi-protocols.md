---
title: "DeFi Protocols"
slug: "defi-protocols"
excerpt: ""
hidden: false
createdAt: "Thu Sep 29 2022 15:26:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 23 2024 23:28:54 GMT+0000 (Coordinated Universal Time)"
---
### A list of our supported DeFi protocols:

- 1INCH
- AAVE
- AAVE (Avalanche)
- AAVE (Polygon)
- BALANCER
- BASIS
- BPT
- COMPOUND
- CREAM
- CURVE
- CURVE (Avalanche)
- CURVE (Polygon)
- Dodo
- HARVEST FINANCE
- INTEGRAL
- MAKER
- mSTABLE
- OPYN
- PANGOLIN (Avalanche)
- PICKLE
- RARI
- SUSHI SWAP
- SUSHI SWAP (Avalanche)
- TRADER JOE (Avalanche)
- UNI - V2
- UNI - V3
- VESPER
- WONDERLAND.MONEY (Avalanche)
- YEARN.FINANCE
