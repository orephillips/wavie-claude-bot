---
title: "Capabilities"
slug: "capabilities"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Fri Sep 30 2022 17:02:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Oct 07 2022 19:40:34 GMT+0000 (Coordinated Universal Time)"
---
Below is a list of Bitwave's current capabilities 

## Current Capabilities:

DASHBOARD:

- Portfolio Overview
- DeFi Overview v1.0

CONNECTIONS:

- Manual Wallet
- Blockchain Connections
- Exchange Connections
- GL/ERP Connections

TRANSACTIONS:

- View All Transactions
- Rules-based Transaction Categorization
- Transaction Register
- Rules Based Categorization
- Import Transactions
- Export Transactions
- Manual Categorization

ACCOUNTING:

- Reconcile Transactions
- External Cost Basis

PRICING:

- Asset Pricing History
- Asset Pricing Exceptions

TAX:

- Gain/Loss Scenario Simulation
- Capitalize Fees
- Gain/Loss Reporting
- FIFO/LIFO/Avg Cost/Specific ID
- Impairment

REPORTS:

- Balance Report
- Journal Entry Report
- Rolled-up Journal Entry Report
- Ledger Report
- DeFi ROI Report

ADMINISTRATION:

- Organization
- Accounting Setup
- Accounting Connections
- Wrapping Treatment
- Tax Strategy
- Wallets
- Invoicing
- System Jobs

SECURITY:

- User Management
- Invite Users
- SSO
- Bitwave API

## Capabilities in BETA testing:

- Bitwave Ops
