---
title: "Exchanges & Custodians"
slug: "exchanges"
excerpt: ""
hidden: false
createdAt: "Tue Aug 16 2022 14:27:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Apr 07 2025 13:35:51 GMT+0000 (Coordinated Universal Time)"
---
### A list of our supported exchanges & custodians:

- Anchorage
- BitGo
- Binance
- Bitfinex
- Bitstamp
- Circle Mint
- Coinbase Exchange
- Coinbase Prime
- Coinbase Retail
- Crypto.com
- Dexalot
- Fireblocks
- Foundry
- Gemini
- Kraken
- Paxos
- SFOX
