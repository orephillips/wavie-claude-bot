---
title: "Blockchains"
slug: "blockchain-integrations"
excerpt: "This list shows all the current blockchain integrations that are now available on Bitwave."
hidden: false
metadata: 
  title: "Blockchains Integrated with Bitwave"
  image: 
    - "https://files.readme.io/be476bb-Bitwave_Banner_5.png"
  keywords: "Blockchain Integrations Crypto Tax Bitcoin"
  robots: "index"
createdAt: "Tue Aug 16 2022 14:30:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Apr 07 2025 13:34:26 GMT+0000 (Coordinated Universal Time)"
---
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .image-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            margin: 10px auto;
            max-width: 500px;
        }
        .image-grid img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
        .image-caption {
            text-align: center;
            font-weight: bold;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="image-grid">
        <div>
            <img src="https://files.readme.io/071a6d0-aptos-apt-logo.png" alt="Aptos">
            <div class="image-caption">Aptos</div>
        </div>
        <div>
            <img src="https://files.readme.io/f3aacd6d6b2f5ac9533012d388bc30ae70b4d98fbe89e9cd30e6b0656ef15e30-06f666a31b3b4a42a4ade255e83d68ea.jpg" alt="Aurora">
            <div class="image-caption">Aurora</div>
        </div>
        <div>
            <img src="https://files.readme.io/7102ca5-arbitrum-arb-logo.png" alt="Arbitrum">
            <div class="image-caption">Arbitrum</div>
        </div>
        <div>
            <img src="https://files.readme.io/a607e57-avalanche-avax-logo.png" alt="Avalanche">
            <div class="image-caption">Avalanche</div>
        </div>
        <div>
            <img src="https://files.readme.io/062d8d1-base-logo-in-blue.png" alt="Base">
            <div class="image-caption">Base</div>
        </div>
        <div>
            <img src="https://files.readme.io/d48f74f-binance-smart-chain-bsc-logo-9C34053D61-seeklogo.com.png" alt="Binance Smart Chain">
            <div class="image-caption">BSC</div>
        </div>
        <div>
            <img src="https://files.readme.io/36d5b0e-bitcoin-btc-logo.png" alt="Bitcoin">
            <div class="image-caption">Bitcoin</div>
        </div>
        <div>
            <img src="https://files.readme.io/a98028c0ed361eb04f8e1dd31b24cbcba7d205225c2fd2e0d6c20d962cf5a11f-canton-logo.png" alt="Canton">
            <div class="image-caption">Canton</div>
        </div>
        <div>
            <img src="https://files.readme.io/e92e56e-casper-cspr-logo.png" alt="Casper">
            <div class="image-caption">Casper</div>
        </div>
        <div>
            <img src="https://files.readme.io/ce6fca4-celo-celo-logo.png" alt="Celo">
            <div class="image-caption">Celo</div>
        </div>
        <div>
            <img src="https://files.readme.io/af98c52-cosmos-atom-logo.png" alt="Cosmos">
            <div class="image-caption">Cosmos</div>
        </div>

<div>
            <img src="https://files.readme.io/f6cb433-ethereum-eth-logo.png" alt="Ethereum">
            <div class="image-caption">Ethereum-Beacon</div>
        </div>
<div>
    <img src="https://files.readme.io/f6cb433-ethereum-eth-logo.png" alt="Ethereum">
    <div class="image-caption">Ethereum</div>
</div>
        <div>
            <img src="https://files.readme.io/b3fa824-fantom-ftm-logo.png" alt="Fantom">
            <div class="image-caption">Fantom</div>
        </div>
        <div>
            <img src="https://files.readme.io/da5a08c-flow-flow-logo.png" alt="Flow">
            <div class="image-caption">Flow</div>
        </div>
        <div>
            <img src="https://files.readme.io/51a3433-gnosis-gno-gno-logo.png" alt="Gnosis">
            <div class="image-caption">Gnosis</div>
        </div>
        <div>
            <img src="https://files.readme.io/78aa0ff-hedera-hbar-logo.png" alt="Hedera">
            <div class="image-caption">Hedera</div>
        </div>
        <div>
            <img src="https://files.readme.io/ba21a41-immutable-x-imx-logo.png" alt="Immutable X">
            <div class="image-caption">Immutable X</div>
        </div>
        <div>
            <img src="https://files.readme.io/b4481b8-klaytn-klay-logo.png" alt="Klaytn">
            <div class="image-caption">Klaytn</div>
        </div>
        <div>
            <img src="https://files.readme.io/8891a1e-mina-mina-logo.png" alt="Mina">
            <div class="image-caption">Mina</div>
        </div>
        <div>
            <img src="https://files.readme.io/c1b12c6-near-protocol-near-logo.png" alt="NEAR Protocol">
            <div class="image-caption">Near</div>
        </div>
        <div>
            <img src="https://files.readme.io/fbbee50-oasis-network-rose-logo.png" alt="Oasis Network">
            <div class="image-caption">Oasis</div>
        </div>
        <div>
            <img src="https://files.readme.io/2cdefd0-optimism-ethereum-op-logo.png" alt="Optimism">
            <div class="image-caption">Optimism</div>
        </div>
        <div>
            <img src="https://files.readme.io/5d1c40a-osmosis-osmo-logo.png" alt="Osmosis">
            <div class="image-caption">Osmosis</div>
        </div>
        <div>
            <img src="https://files.readme.io/185320f5116d21554169a39c223c8fc46fffaef77e3a133957030efc38af74d0-polymesh.png" alt="Polymesh">
            <div class="image-caption">Polymesh</div>
        </div>
        <div>
            <img src="https://files.readme.io/c40afef-polygon-matic-logo.png" alt="Polygon">
            <div class="image-caption">Polygon</div>
        </div>
        <div>
            <img src="https://files.readme.io/3134f19-xrp-xrp-logo.png" alt="XRP">
            <div class="image-caption">Ripple</div>
        </div>
        <div>
            <img src="https://files.readme.io/552568d-solana-sol-logo.png" alt="Solana">
            <div class="image-caption">Solana</div>
        </div>
        <div>
            <img src="https://files.readme.io/3626d525222fb0322a2cc872e020c02fab78c73fe718a5203f0fd298c1dad0d8-stacks-stx-logo.png" alt="Stacks">
            <div class="image-caption">Stacks</div>
        </div>
        <div>
            <img src="https://files.readme.io/812a849a145ab248557bcc000c143e6bb284101516a78a81b7bcd8216d2d95e0-stellar1.png" alt="Stellar">
            <div class="image-caption">Stellar</div>
        </div>
        <div>
            <img src="https://files.readme.io/523a28a4686736c9dbfaf137c1e4c73133f8b3cd8416357215b66281a26bec2c-zetachain.png" alt="Zetachain">
            <div class="image-caption">Zetachain</div>
        </div>
    </div>
</body>
</html>
