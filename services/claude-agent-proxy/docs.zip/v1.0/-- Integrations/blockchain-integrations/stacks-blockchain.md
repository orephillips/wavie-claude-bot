---
title: "Stacks"
slug: "stacks-blockchain"
excerpt: ""
hidden: true
createdAt: "Wed Mar 06 2024 13:55:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 18 2024 02:21:53 GMT+0000 (Coordinated Universal Time)"
---
**To add a Stacks blockchain wallet to Bitwave:**

1. Go to the "Wallets" menu
2. Click "Create Wallet"
3. Select "Stacks" from the dropdown
4. Enter a name for your wallet
5. Enter the wallet address

![](https://files.readme.io/8101706-image.png)

**Supported Features:**  
Bitwave supports syncing transactions from standard Stacks blockchain public key wallet addresses.

- Example: SP3398ADV34B9H8RV5JDGK0N7XF6W6Z2QPHNCR51R
- Additional docs: <https://docs.stacks.co/docs/stacks-academy/technical-specs#accounts-and-addresses>

Bitwave supports standard STX transfers, also known as the **stx-transfer** function.

- Example transaction: <https://explorer.hiro.so/txid/0x24c7f529339963644b13069984f7124de1eb8a343b96fe2f654462204b9d3981?utm_source=stacks-wallet&chain=mainnet>
- Additional docs: <https://docs.stacks.co/docs/clarity/language-functions#stx-transfer>

**Future Support:**

In the future Bitwave plans to support additional features, such as:

- Additional functions such as: claim, lock, refund, etc.
- See a full list of functions on Stack's official documentation page: <https://docs.stacks.co/docs/clarity/language-functions>
