---
title: "Change Logs Home"
slug: "change-logs"
excerpt: ""
hidden: false
createdAt: "Wed Aug 07 2024 12:59:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 07 2024 13:02:25 GMT+0000 (Coordinated Universal Time)"
---
Visit our change logs home where you can see various features we have released over time: 

- [Change Logs Home](https://docs.bitwave.io/changelog/change-log-home)
