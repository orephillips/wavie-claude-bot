---
title: "Customer Data APIs"
slug: "customer-data-apis"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Nov 03 2021 12:19:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Nov 03 2021 16:00:02 GMT+0000 (Coordinated Universal Time)"
---
## Overview

Bitwave supports a robust ingestion of customer data from custom applications such as exchanges and more. This capability accomplishes two goals - first, collecting customer data for cost basis and gain / loss reporting, and second, collecting commission information for on the books revenue and tax recognition purposes.

[block:parameters]
{
  "data": {
    "h-0": "Step",
    "h-1": "Name",
    "h-2": "Description",
    "0-0": "0",
    "0-1": "Generate API Key",
    "0-2": "Follow the steps outlined in the API Reference to create an API",
    "1-0": "1",
    "1-1": "Submit Customer Transactions",
    "1-2": "There are two types of transactions you can submit from customer standpoint - a trade or a transfer. A transfer implies the movement of coins or fiat into or out of your exchange, and includes any fee information as part of that transaction.  \n  \nA trade is the exchange of digital assets from one individual to another, or from your exchange to a customer.",
    "2-0": "2",
    "2-1": "Fill in cost basis data",
    "2-2": "In order to generate gain / loss report data, we need to understand the full cost basis history for a customer. In the case where a customer moved assets onto your platform, we need to capture that data",
    "3-0": "3",
    "3-1": "Generate reports",
    "3-2": "The final step on a yearly basis is to generate a customer report. We do this at a particular point in time so that all data is captured."
  },
  "cols": 3,
  "rows": 4,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


## Customer Data APIs

[block:parameters]
{
  "data": {
    "h-0": "Endpoint",
    "h-1": "Schema",
    "0-0": "**TransactionID**  \n  \nRetrieves relevant information regarding transaction based off of a transaction ID",
    "0-1": "[/orgs/{orgId}/customers/-/transactions/{transactionId}](ref:recordcustomeraction)",
    "1-0": "**Transactions**  \n  \nFetches information about the transaction as well as the customer(s) involved",
    "1-1": "[/orgs/{orgId}/customers/{customerId}/transactions](ref:getcustomertransactions)",
    "2-0": "**Gain/Loss Report**  \n  \nExecutes the Gain/Loss Report and returns a copy of the report",
    "2-1": "[/orgs/{orgId}/customers/{customerId}/reports/gainLossReport](ref:generategainlossreport)",
    "3-0": "**Reports**  \n  \nReturns all the reports for that customer",
    "3-1": "[/orgs/{orgId}/customers/{customerId}/reports](ref:getcustomerreports)"
  },
  "cols": 2,
  "rows": 4,
  "align": [
    "left",
    "left"
  ]
}
[/block]
