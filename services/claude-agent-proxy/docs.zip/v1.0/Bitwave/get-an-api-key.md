---
title: "Get an API Key"
slug: "get-an-api-key"
excerpt: ""
hidden: false
metadata: 
  image: 
    - "https://files.readme.io/879de7cb161c06c51aab9e3033fdbee7a1b9e2ad6b870c6f12f5b38132dbfc7d-OPEN-GRAPH---BITWAVE.png"
  robots: "index"
createdAt: "Fri Sep 30 2022 15:31:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Sep 30 2024 02:32:26 GMT+0000 (Coordinated Universal Time)"
---
## Step 1: Get API Keys

1. To gain access to the Bitwave API, create an account on Bitwave
2. Navigate over to the **Organization** tab > **API** section
3. Select **Create API Key**
4. We will generate a _client_id_ and _secret_ for you

![](https://files.readme.io/aee20e6-Screen_Shot_2021-11-28_at_4.39.44_PM.png "Screen_Shot_2021-11-28_at_4.39.44_PM.png")

## Step 2: Save the Keys

1. Please save the _secret_ as it will be inaccessible to you after you close the pop-up

## Step 3: Additional API Documentation

1. Additional API documentation can be found [here](https://bitwave.readme.io/reference/docs)
