---
title: "API Reference"
slug: "docs"
excerpt: "Comprehensive reference for integrating with Bitwave API endpoints"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 26 2021 15:06:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 11 2023 00:21:32 GMT+0000 (Coordinated Universal Time)"
---
## Endpoint and Schema Overview

Core

[block:parameters]
{
  "data": {
    "h-0": "Endpoint",
    "h-1": "Schema",
    "h-2": "",
    "0-0": "**Transactions V1**  \n  \nRetrieve blockchain transaction data. Use V2 endpoints (revised version) when possible.",
    "0-1": "[/txns/categorize/{orgId}/{transactionId}](ref:categorizetransaction)  \n[/txns/{orgId}/{transactionId}/{sourceId}](ref:upserttransaction)  \n[/txns/{orgId}/{transactionId}/{sourceId}](ref:head)  \n[/txns/{orgId}/{transactionId}](ref:getTransaction)  \n[/txns/{orgId}](ref:getTransactionsPaginated)",
    "0-2": "",
    "1-0": "**Transactions V2**  \n  \nRetrieve blockchain transaction data. Revised from V1, use V2 transaction endpoints where possible.",
    "1-1": "[/orgs/{orgId}/transactions](ref:getTransactionsLite)  \n[/orgs/{orgId}/transactions/dirty](ref:checkPriceDirty)  \n[/orgs/{orgId}/transactions/{transactionId}/rules/{ruleId}](ref:checkRuleApplication)  \n[/orgs/{orgId}/transactions/{transactionId}](ref:categorizeTransactionPatch)",
    "1-2": "",
    "2-0": "**Categories**  \n  \nFetch all the categories for an organization. This is typically a chart of accounts from the customer's ERP system if integrated with Bitwave",
    "2-1": "[org/{orgId}/categories/](ref:getcategories)",
    "2-2": "",
    "3-0": "**Connections**  \n  \nRetrieve all the integrations within an organization",
    "3-1": "[/orgs/{orgId}/connections/{connectionId}](ref:getconnection)  \n[/orgs/{orgId}/connections/{connectionId}/token](ref:getconnectiontoken)  \n[/orgs/{orgId}/connections](ref:getconnections)",
    "3-2": "",
    "4-0": "**Contacts**  \n  \nRetrieve all the contacts within an organization. This is typically the contacts from the customer's ERP system if integrated with Bitwave.",
    "4-1": "[/contacts/{orgId}](ref:getcontacts)",
    "4-2": "",
    "5-0": "**Authentication**  \n  \nObtain and manage an authentication token to access the Bitwave API",
    "5-1": "[/oauth/token](ref:gettoken)",
    "5-2": "",
    "6-0": "**Organizations**  \n  \nRetrieve all the organizations associated with a user",
    "6-1": "[/organizations](ref:getuserorganizations)",
    "6-2": "",
    "7-0": "**Users**  \n  \nAccess user account information and see all possible account types and sub-types",
    "7-1": "[/users/me](ref:me)",
    "7-2": "",
    "8-0": "**Wallets**  \n  \nFetch all the wallets within an organization",
    "8-1": "[/orgs/{orgId}/wallets](ref:getwallets)",
    "8-2": ""
  },
  "cols": 3,
  "rows": 9,
  "align": [
    "left",
    "left",
    "left"
  ]
}
[/block]


Address-SVC

[block:parameters]
{
  "data": {
    "h-0": "Endpoint",
    "h-1": "Schema",
    "0-0": "**Addresses**  \n  \nRetrieve all the addresses associated with a particular blockchain network",
    "0-1": "[/networks/{networkId}/addresses/{address}](ref:getaddress)  \n[/networks/{networkId}/addresses/{address}/balance](ref:getaddressbalance)  \n[/networks/{networkId}/addresses/{vaultAddress}/vaultBalance](ref:getvaultbalance)  \n[/networks/{networkId}/addresses/{address}/supply](ref:getaddresssupply)  \n[/networks/{networkId}/addresses/{address}/read/{method}](ref:read)",
    "1-0": "**Blocks**  \n  \nRetrieve all the blocks for a particular blockchain network",
    "1-1": "[/networks/{networkId}/blocks](ref:listblocks)",
    "2-0": "**Coins**  \n  \nView all the coins that we support",
    "2-1": "[coins](ref:list)  \n[/coins/{coinId}](ref:getcoin)",
    "3-0": "**DeFi Platforms**  \n  \nVerify a DeFi balance from the blockchain",
    "3-1": "[/networks/{networkId}/platforms/{platformId}/balance](ref:getplatformbalance)",
    "4-0": "**Symbols**  \n  \nRetrieve all the different cryptocurrency symbols we support",
    "4-1": "[/symbols/{symbol}](ref:getsymbol)"
  },
  "cols": 2,
  "rows": 5,
  "align": [
    "left",
    "left"
  ]
}
[/block]


## API Access

To gain access to the Bitwave API, create an account on Bitwave. Once you've completed the signup process, navigate to the Organization tab > API section. Then, click on 'Create API Key' and we will generate a _client_id_ and _secret_ for you. Please save the _secret_, it will be inaccessible after you close this pop-up.

## API Protocol and Headers

The Bitwave API uses standard HTTP methods (PUT, HEAD, GET, POST) to communicate and HTTP response codes to indicate status and errors. All responses come in standard JSON.

Almost all Bitwave API endpoints require a _client_id_ and _secret_. 

## Successful Callback

The successCallback is called when a user successfully authenticates with the Bitwave API.

```javascript
$http.post('/someUrl', data).success(successCallback);

alert('test');
```
