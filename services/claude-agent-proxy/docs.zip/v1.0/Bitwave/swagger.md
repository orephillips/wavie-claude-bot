---
title: "Swagger"
slug: "swagger"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue May 09 2023 18:18:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 09 2023 18:18:43 GMT+0000 (Coordinated Universal Time)"
---
<https://api.bitwave.io/api-docs/>
