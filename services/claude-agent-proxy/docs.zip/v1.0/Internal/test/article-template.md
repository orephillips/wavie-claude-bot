---
title: "Article Template:"
slug: "article-template"
excerpt: "User guide page template:"
hidden: false
createdAt: "Fri Jun 28 2024 11:53:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 19 2025 13:21:13 GMT+0000 (Coordinated Universal Time)"
---
## TITLE

### SUBTITLE

- What it is/definition
  - Example
- Why you would use it/what is the end result of using it
- Where to find it in Bitwave [screenshot]
- How to use it/configure it
- What module is needed to have access to it (with link to contact sales for an upsell opportunity)
