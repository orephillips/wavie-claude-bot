---
title: "Internal Bitwave Wiki"
slug: "test"
excerpt: ""
hidden: false
createdAt: "Tue Apr 16 2024 15:15:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 19 2025 13:21:12 GMT+0000 (Coordinated Universal Time)"
---
### How to set up inventory groups

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.loom.com%2Fembed%2F1f48a62787b44711b5042aa0393e3f8c&display_name=Loom&url=https%3A%2F%2Fwww.loom.com%2Fshare%2F1f48a62787b44711b5042aa0393e3f8c&image=https%3A%2F%2Fcdn.loom.com%2Fsessions%2Fthumbnails%2F1f48a62787b44711b5042aa0393e3f8c-00001.gif&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=loom\" width=\"1686\" height=\"1264\" scrolling=\"no\" title=\"Loom embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.loom.com/share/1f48a62787b44711b5042aa0393e3f8c",
  "title": "How to Set Up Inventory Groups",
  "image": "https://cdn.loom.com/sessions/thumbnails/1f48a62787b44711b5042aa0393e3f8c-00001.gif",
  "provider": "loom.com",
  "href": "https://www.loom.com/share/1f48a62787b44711b5042aa0393e3f8c",
  "typeOfEmbed": "youtube"
}
[/block]


<br>
