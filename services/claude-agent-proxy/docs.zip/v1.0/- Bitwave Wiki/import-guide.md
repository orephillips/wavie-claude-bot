---
title: "Import Guide"
slug: "import-guide"
excerpt: ""
hidden: true
createdAt: "Thu Apr 25 2024 20:00:07 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 25 2024 20:00:07 GMT+0000 (Coordinated Universal Time)"
---
In Bitwave we are able to import manual transactions for data that may not be able to be imported through our traditonal connections. We are able to import many different types of transactions such as:

- Deposits
- Withdrawals
- Trades
- Internal Transfers
- Staking Rewards
- Fees
- More....

The import file has many different functions as to how to handle your data. The functions include:

- Setting the cost basis
- Categorizing transactions
- Grouping transactions
- Adding memos
- Inputting From/To addresses
- Overriding transactions
- <br>
