---
title: "Common Issues"
slug: "common-issues-11"
excerpt: ""
hidden: true
createdAt: "Mon May 06 2024 05:13:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 06 2024 05:36:56 GMT+0000 (Coordinated Universal Time)"
---
# General

## :anger: Invitation was not received / cancel an invitation

### Solution:

Reach out to us by email ([support@bitwave.io](mailto:support@bitwave.io)) or our In-App chat support to re-invite a colleague or yourself to the Bitwave Platform. This is the same process for cancelling an invitation.

# Wallets, Exchanges, Custodial & Manual Wallets

# Transactions

## :anger: Transactions are not displaying in Bitwave

### Solution:

Have you encountered a situation where a transaction is not visible? It's essential to understand that this issue may stem from a wallet synchronization problem.

The most effective way to address transaction visibility issues is by resyncing your wallet. This process involves refreshing the connection between your wallet and Bitwave, ensuring that all transactions are accurately reflected in your account.

How to Resync Your Wallet:  
Reach out to the In-App chat support to request a resync.

Provide Wallet Details: When reaching out to support, be sure to include relevant wallet details, such as the wallet address, wallet ID and any additional information that may aid in the resync process.

Why Wallet Resync is Necessary:  
Wallet resync is crucial for ensuring the accuracy and completeness of your transaction records in Bitwave. By refreshing the connection between your wallet and the platform, you can rest assured that all transactions, including the elusive ones, will be visible and accounted for.

# Import

# Categorize

# Rules

# Accounting & General Ledger / ERP

# Reports

# Inventory Views

# DeFi

# Pricing
