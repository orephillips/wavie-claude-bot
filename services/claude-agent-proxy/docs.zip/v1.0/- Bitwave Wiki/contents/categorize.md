---
title: "Categorize"
slug: "categorize"
excerpt: "Quick start to categorizing transactions, Handling Common Issues, and answering questions :trophy:"
hidden: false
createdAt: "Wed Apr 10 2024 03:55:16 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 10 2024 22:23:46 GMT+0000 (Coordinated Universal Time)"
---
