---
title: "Bring Your Own Key Setup"
slug: "bring-your-own-key-setup"
excerpt: ""
hidden: true
createdAt: "Thu Mar 06 2025 05:44:49 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Mar 24 2025 18:22:43 GMT+0000 (Coordinated Universal Time)"
---
Bitwave, as a leading enterprise finance platform for digital assets, prioritizes security and data privacy for its customers. In today’s digital landscape, businesses require full confidence that their financial data is protected against unauthorized access while maintaining compliance with industry regulations. To address these concerns, Bitwave implements a Bring Your Own Key (BYOK) encryption model, allowing customers to retain control over their encryption keys while leveraging Bitwave’s robust, enterprise-grade services.

For many organizations, particularly those operating in finance or regulated industries, security and compliance are not just priorities—they are mandatory. Traditional cloud-based encryption methods often rely on providers managing the encryption keys, which, while secure, may not meet all corporate or regulatory requirements. BYOK offers customers the ability to:

_Maintain Ownership and Control_ – Customers retain full authority over their encryption keys, reducing reliance on third parties for data security.

_Enhance Data Sovereignty_ – Many organizations must comply with strict regional data privacy laws, requiring control over how and where encryption keys are stored and used.

_Ensure Regulatory Compliance_ – Meeting industry standards such as GDPR, HIPAA, SOC 2, or PCI-DSS often necessitates control over encryption keys, ensuring sensitive data is not accessible by unauthorized parties.

_Enable Instant Key Revocation_ – In the event of a security incident, policy change, or personnel transition, customers can revoke or rotate keys immediately, preventing potential unauthorized access.

# How Bitwave’s BYOK Works

This document provides a comprehensive overview of Bitwave’s BYOK architecture, detailing the encryption, storage, and management of data in collaboration with Google Cloud’s Key Management Service (KMS). By integrating with Google Cloud, Bitwave ensures that customers benefit from enterprise-grade security infrastructure while maintaining full control over their encryption strategy.

With the implementation of BYOK, Bitwave empowers businesses with greater security, compliance, and operational flexibility, ensuring they can leverage the full power of enterprise accounting software while maintaining strict control over their most sensitive financial data.

## Architecture

![](https://files.readme.io/6cda142cfd09c57c114c452a9401f7933e4cedd5382e0bf09f0601f73c34b4fc-image.png)

<br />

Bitwave’s BYOK architecture is designed to ensure that customer data remains secure and confidential while leveraging the scalability and reliability of Google Cloud services. 

The service follows a two-layer encryption model:

The service generates DEKs (Data Encryption Keys) for encrypting actual data

These DEKs are then encrypted using the customer's KEK (Key Encryption Key) in KMS

The encrypted DEKs are stored in Spanner

This architecture ensures that:

Customers maintain control over their data through their KEK

If a customer revokes access to their KEK, all their encrypted data becomes inaccessible

The service can efficiently encrypt/decrypt data using the DEKs while keeping the master keys (KEKs) secure in KMS

Here’s a detailed explanation of the components:

Google Cloud Integration

Bitwave integrates with Google Cloud services, including BigQuery Datasets and Cloud Storage Buckets, to store and process customer data.

Google handles encryption for normal interactions with its storage services (e.g., Cloud Storage Buckets) using its own encryption mechanisms, ensuring data security at rest and in transit within Google’s infrastructure.

Service accounts, such as the BigQuery-encryption service account and gs-project service account, facilitate secure communication between Bitwave and Google Cloud components.

Customer-Controlled Key Management

The service interacts with Google Cloud KMS for key encryption operations

Customers maintain control over their encryption keys via a Key Management Service (KMS) hosted on their infrastructure or a trusted third-party provider.

The key-svc service account interacts with the customer’s KMS to manage encryption keys securely, ensuring that Bitwave cannot access unencrypted data without customer authorization.

## Data Encryption and Decryption in Bitwave

Bitwave generates a random Data Encryption Key (DEK), which will be rotated at least every 6 months (but can be rotated more frequently). This DEK is used to encrypt and decrypt customer data processed by Bitwave Services.

The DEK itself is encrypted using the customer-provided key from the KMS, creating an additional layer of security. This encrypted DEK is stored in the Encrypted DEK DB, ensuring that only authorized customers can access or decrypt their data.

Bitwave Services encrypt data before storing it in Bitwave DBs or reading encrypted data for processing, ensuring that data remains protected throughout its lifecycle.

### Data Storage and Access

Encrypted data is stored in Bitwave DBs and Google Cloud Storage Buckets, maintaining compliance with industry standards for data security.

When Bitwave Services need to access or process data, they decrypt it using the customer-managed keys, ensuring that sensitive financial and accounting information remains confidential.

### Security and Compliance

By allowing customers to bring their own keys, Bitwave ensures that data encryption is entirely under customer control, aligning with regulatory requirements. The frequent rotation of DEKs  minimizes the risk of key compromise, while the separation of duties between Google, Bitwave, and the customer enhances overall security.

### Service Account Access

The service account needs permissions to:

- Access the customer's KEK (Key Encryption Key)
- Perform encryption/decryption operations using KMS
- The service account is used to authenticate with Cloud Spanner
- Read/write to the DEK (Data Encryption Key) table
- Store encrypted DEKs and their metadata

Key-svc access for encryption/decryptions of events and primary storage - depends on the cluster you’re deployed to, ensure this with your implementation engineer.

[c-1-key-svc@bitwave-prod-a.iam.gserviceaccount.com](mailto:c-1-key-svc@bitwave-prod-a.iam.gserviceaccount.com)  
[us-1-key-svc@bitwave-prod-a.iam.gserviceaccount.com](mailto:us-1-key-svc@bitwave-prod-a.iam.gserviceaccount.com)  
BigQuery dataset encryption. This can be accessed from 1 of 3 projects depending on where the org is deployed (confirm with you implementation engineer).

[bq-336803423896@bigquery-encryption.iam.gserviceaccount.com](mailto:bq-336803423896@bigquery-encryption.iam.gserviceaccount.com)  
[bq-595669547457@bigquery-encryption.iam.gserviceaccount.com](mailto:bq-595669547457@bigquery-encryption.iam.gserviceaccount.com)  
[bq-194703999515@bigquery-encryption.iam.gserviceaccount.com](mailto:bq-194703999515@bigquery-encryption.iam.gserviceaccount.com)  
Google Cloud Storage Bucket Encryption. Access is granted to 3 service accounts from projects. Where various services are deployed (confirm particular service account with implementation engineer).

[service-336803423896@gs-project-accounts.iam.gserviceaccount.com](mailto:service-336803423896@gs-project-accounts.iam.gserviceaccount.com)  
[service-194703999515@gs-project-accounts.iam.gserviceaccount.com](mailto:service-194703999515@gs-project-accounts.iam.gserviceaccount.com)  
[service-595669547457@gs-project-accounts.iam.gserviceaccount.com](mailto:service-595669547457@gs-project-accounts.iam.gserviceaccount.com)

### Security Objectives

**Enhanced Security**: Customers retain full control over their encryption keys, reducing the risk of unauthorized access.

**Regulatory Compliance**: The BYOK model supports compliance with global data protection regulations.

**Scalability**: Leveraging Google Cloud’s infrastructure ensures scalability and reliability for enterprise-level accounting needs.

**Transparency**: The architecture provides clear visibility into how data is encrypted, stored, and managed.

### Appendix A: Flow Diagram

[Start] → [Customer KMS]  
    ↓  
[Key-svc Service Account] → [Generate Random DEK (every 90 days per org)]  
    ↓  
[Encrypt DEK with Customer Key] → [Store in Encrypted DEK DB]  
    ↓  
[Bitwave Services]  
    ↓  
[Encrypt Data] → [Store/Read Encrypted Data]  
    |                     ↓  
    \|                 [Bitwave DBs]  
    ↓  
[Google Cloud]  
    ↓  
[BigQuery Dataset] ← [BigQuery-encryption Service Account]  
    \|  
[Cloud Storage Buckets] ← [gs-project Service Account]  
    ↓  
[End: Secure Data Storage & Access]

#### Appendix A1: Narrative

**Initiation with Customer KMS**  
The process begins with the customer’s Key Management Service (KMS), where encryption keys are stored and managed. Customers retain full control over these keys, ensuring data privacy and compliance with regulatory standards.

**Key Generation and Encryption**  
Bitwave’s key-svc service account interacts with the customer’s KMS to generate a random Data Encryption Key (DEK) every 90 days per organization. This DEK is then encrypted using the customer-provided key from the KMS. The encrypted DEK is stored securely in the Encrypted DEK DB.

**Data Processing in Bitwave Services**  
Bitwave Services use the DEK to encrypt customer data before storage. This ensures that sensitive financial and accounting information remains confidential. The encrypted data is then stored in or read from Bitwave DBs, maintaining security throughout its lifecycle.

**Integration with Google Cloud**  
Bitwave leverages Google Cloud for scalable storage and analytics. Data is stored in Google Cloud Storage Buckets and BigQuery Datasets. Google handles its own encryption for interactions with these services, while service accounts (BigQuery-encryption service account and gs-project service account) are used to encrypt/decrypt the data.

**Secure Data Access and Storage**  
The process concludes with secure data storage and access, where encrypted data is maintained in Bitwave DBs and Google Cloud, accessible only through customer-authorized decryption using their KMS keys.

### Appendix B:  Logical View

Open image-20250306-053746.png  
image-20250306-053746.png  
Appendix C: KEK rotation

The KEK is managed by Google Cloud KMS, which can be controlled by the customer

Customers can rotate their KEK directly in Google Cloud KMS

When encrypting new data, the service uses the kekResourceName parameter to use the latest KEK version

The kekResourceName is stored alongside each encrypted DEK in Spanner (as seen in the DEKRecord structure)

This allows different versions of KEKs to be active for different pieces of data

For KEK Rotation:

Customer creates a new version of their KEK in Google Cloud KMS

All new encryption operations will use the new KEK version

Existing encrypted data remains encrypted with the old KEK version
