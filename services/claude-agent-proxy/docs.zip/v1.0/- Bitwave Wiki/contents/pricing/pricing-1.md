---
title: "Pricing Engine"
slug: "pricing-1"
excerpt: "How does pricing work?"
hidden: false
createdAt: "Fri Jun 28 2024 17:04:37 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 20:32:49 GMT+0000 (Coordinated Universal Time)"
---
Bitwave has an intelligent pricing engine that allows you to configure how to price your digital assets. 

Customized pricing engine allows you to select individual pricing sources based on your principal market analysis, and it allows you to set special pricing when token derive their values from contracts.

 **Default Pricing Rule**

Default pricing rule means default pricing actions Bitwave will take to price any digital asset. 

![](https://files.readme.io/07720a7-Screenshot_2024-06-28_at_1.11.57_PM.png)

**Glossary**

Resolution 

- The pricing window the pricing engine will grab. 
- Example: 1HOUR Resolution for a transaction happens on 2024-06-30 at 3:01:34PM EST, we will use pricing from 2024-06-30 03:00PM EST to 2024-06-30 03:59:59PM EST

Methodology

- Some pricing sources return candlesticks, and some only provide one price.
- For candlesticks, we could choose from OPEN, CLOSE, HIGH, or LOW to price the asset. 
- Example: 1HOUR Resolution with CLOSE Methodology for a transaction happens on 2024-06-30 at 3:01:34PM EST, we will use pricing from 2024-06-30 03:00PM EST to 2024-06-30 03:59:59PM EST, and we will use the CLOSING price of the hour

Action Type

- Ordered Source Search - we will go down the list of pricing sources until either go through all the sources and cannot find a price or the first pricing source that returns a price.
  - Example: Crypto Compare, then Coin Gecko will mean we will price from Crypto Compare, and if that fails, we will price from Coin Gecko
  - Ordered Source Search is beneficial when you want to have a fall back.
- Price Override - that will be the price we will use, this is different from using the pencil icon on the Transactions page, because that pencil icon is a one time price override, whereas Price Override action will be applied across the board. This is useful when you treat certain digital assets as pegged, for example, USDC fluctuates, but you can treat it as 1 USD. 
- Rate Table Lookup - we will use a special rate table to price the assets.

**Coin Pricing Rule**

![](https://files.readme.io/4d093c9-Screenshot_2024-06-28_at_3.28.59_PM.png)

**Glossary**

Ticker - the ticker symbol of this specific pricing rule. They should match the current symbol from address service.

Start Date - when the rule begins to apply.

End Date - when the rule stops to apply.

Priority - ranking of the rule

Application 

- Before Default - this rule will run before the default rule
- After Default - this rule will run after the default rule
- Suppress Default - this rule will run and the default rule will not run

Action Type 

- Price Through Asset 
  - There are some assets that may not have the pricing you want, and they need to price through an intermediary asset.
  - For example, you are looking for LINK to SGD pricing but the pricing sources do not have it, you can choose an intermediary asset, such as LINK to USD and then USD to SGD to get the price.

For customers who do not have the pricing rule feature, the default rule is

Methodology: CLOSE

Resolution: 1 HR

Action: Ordered Source Search -> Crypto Compare -> Coin Gecko
