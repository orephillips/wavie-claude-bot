---
title: "Pricing Guide"
slug: "pricing-guide"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:53:48 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 23:30:09 GMT+0000 (Coordinated Universal Time)"
---
[block:embed]
{
  "url": "https://drive.google.com/file/d/16hoERl9rY9qBfKeiaJiZBZ5_wiuLE7G2/view",
  "title": "Bitwave-Digital-Asset-Pricing-Methodology-Whitepaper.pdf",
  "favicon": "https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_32dp.png",
  "image": "https://lh3.googleusercontent.com/drive-viewer/AKGpihZGPGxt9VRcNcGc9OY9JCA6SFY3m0CgJcMJprf4E9Ewt-SttPGalbl1KDjfcA92c8BgZxbgK_TwIHbYqR4XR2RzkXJ25gukaU8=s1600-rw-v1",
  "provider": "drive.google.com",
  "href": "https://drive.google.com/file/d/16hoERl9rY9qBfKeiaJiZBZ5_wiuLE7G2/view",
  "typeOfEmbed": "pdf"
}
[/block]


### BITWAVE PRICING ENGINE

The default pricing in the Bitwave app is CryptoCompare’s real-time aggregate index methodology (CCCAGG). They calculate the market price of cryptocurrency pairs traded across exchanges. Aggregating transaction data from more than 250 exchanges, they use a 24-hour volume-weighted average for every currency pair. As a result, Bitwave shows the end of hour pricing (eg. price at 3 AM UTC for a transaction that occurs at 2:58:00 AM UTC).

### EXCHANGE PRICING

Bitwave can show pricing for tokens trading on an exchange via the CryptoCompare API. We pull token pricing from the following exchanges: Binance, Binance.US, Bitfinex, Coinbase, Gemini, and Kraken.

### COINGECKO

Bitwave can pull pricing for tokens listed on CoinGecko.

### MANUAL PRICING

Users are able to give us an excel file with their tokens’ dates and prices, so that they can be imported into Bitwave. This is especially attractive for companies that issue their own tokens or receive tokens via SAFT before they’re publicly traded.

### CHECK PRICING DATA

Bitwave's Pricing screen allows you to see historical pricing for your tokens by selecting assets from a dropdown and also a starting and ending date. The screen will provide details about when the asset was priced, open, close, low and high pricing as well as the methodology used to price the asset in Bitwave. Tokens without a pricing source or tokens that fail pricing will show a $0 transaction rate in reports. Drilling down into the Pricing screen records will show the user additional detail such as the pricing source, the specific Rule used to price and if pricing failed. Failed pricing and missing pricing sources can be communicated to Bitwave support for updating and troubleshooting.

![](https://files.readme.io/3c74cd6-Screenshot_2024-03-26_at_8.10.11AM.png)

### ADVANCED PRICING MODULE

We find the default hourly pricing strikes an appropriate balance between granularity and optionality to support high-volume transaction roll-ups. Still, the advanced pricing module can ultimately support whichever method an organization chooses. The advanced pricing module allow you to create different pricing sources for different tokens and rules around pricing for different periods of time. All of this is recorded within the app and creates an audit trail.

![](https://files.readme.io/04c7e94-141.png)

### ADD PRICING IN THE ADVANCED MODULE

Advanced pricing rules should be created BEFORE adding any wallets or txns (if using EOD or exchange specific pricing)

### Q. Is there any way to fix price of stable coins ?

🅰️: Price of a stable coin can be fixed by using Bitwave's paid feature called advance pricing rule
