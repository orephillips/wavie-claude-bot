---
title: "❓FAQs"
slug: "frequently-asked-questions-5"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:54:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 15:04:23 GMT+0000 (Coordinated Universal Time)"
---
# Pricing

***

## Q: What is the difference between using and suggested rate?

:a:Suggested rate means the rate which is coming through the Bitwave pricing source (i.e cryptocompare and coingecko by default) and Using rate means the rate which is used to price the token and you can also edit the using rate by clicking on the pencil icon in the UI.

## Q: How do I request that a new token be priced in Bitwave?

### :a:: In order to request pricing for a new token, obtain the following information and reach out to us in our in-app chat to action your request:

- Bitwave Token Ticker (required field):
- Blockchain (required field):
- Token Contract address (optional):
- Coingecko Link or API ID (optional if you would like automated pricing):

**Where to locate the Org ID and Org Name:**

**Step 1: **Navigate to Administration > Organization

**Step 2: **Copy the Org Name and double click the greyed out box for the OrgID.

![](https://files.readme.io/3c9c9cb-image.png)

**Where to locate the Bitwave Token Ticker:**

**Step 3: **Navigate to Transactions > All Transactions

**Step 4: **Copy the appropriate Ticker.

![](https://files.readme.io/b31ba5d-image.png)

**Where to locate the Blockchain, Token Contract address, and Coingecko Link or API ID:**

Step 5: Navigate to <https://www.coingecko.com/>

**Step 6: **Search for the token using the search bar. Ensure you are selecting the correct token as there could be multiple options with the same ticker.

![](https://files.readme.io/30e47d8-image.png)

Step 7: Scroll to the middle of the web page and locate the section titled "Info."

**Step 8: **Copy the fields noted in the screenshot below.

![](https://files.readme.io/cbd1358-image.png)

***

## Q : How to get historical pricing report for token?

### :a:: Follow the steps below to get a pricing report of a specific token :-

1. Go to pricing
2. Select the coin
3. Select start date and end date

You can can also get the report in CSV format  by clicking " Download to CSV "

![](https://files.readme.io/ae8747f-Pricing.png)NOTE: If you click on any of the line items, then this will prompt to show where the pricing is coming from. And It will show if it successfully pricing or if there is an error that is preventing pricing from coming through to Bitwave![](https://files.readme.io/4501334-image.png)

## Q: For specific tokens (USDT and USDC), I need to price them at 1 dollar. How can I do that?

### :a: In the left-hand corner of your Bitwave app,

1. Navigate to Pricing.
2. Go to the Pricing Rules.
3. Click on Create Rule.
4. Click on Coin.
5. Fill theTticker Name
6. Select the Start Date
7. Select “Suppress Default” in Application.
8. Select “Price Override” in Action Type.
9. Fill the price to “1”.
10. Click on Save.

## Q. What is the Ignore fail pricing checkbox in rules ?

### A:

Ignore Fail Pricing Checkbox should be used when a user would like the rules to forcibly categorize a transaction that has a token with 0 or failed pricing. In a normal situation rules will NOT categorize a transaction which does not have pricing. This feature allows the user to force the bitwave rules engine to categorize the transaction. Note that the pricing associated with unpriced token will automatically be 0. This feature is commonly used when there are unpriced NFTs, or rare tokens involved in a transaction that also has priced tokens.

***

***

## Q**: How to download a pricing report?**

### :a:  To download pricing report , follow the steps given below,

1. Go to Pricing menu on left hand side.
2. Fill the coin or the assest ticker and start and end date for which you want to see pricing for.
3. Click on download as CSV on right hand side.

***

## Q: How to edit the pricing of a token in the UI?

:a:

Here are the steps to edit the pricing of a token in the UI

1. Go to All transactions under Transactions tab on the left hand side menu
2. Click on the transaction on which you want to edit the pricing of a token.
3. Click on the Pencil Button
4. Edit the Using rate with the updated pricing.
5. Click on the ""Tick"".
6. Hit ""SAVE"" button."

***

## Q: What should I do if my transactions do not have any pricing??

### :a:: In case the transactions in bitwave do not show any pricing, in that case there are two possibilities:

### 1. If token was pulling pricing before but it is not anymore, in this case we may need to do a pricing recache for that particular token in the transaction that is not showing any price. Once the pricing recache is done you can expect the pricing to appear in some time.

### 2. If token doesn't have pricing in bitwave , in that case we may need to add pricing for that token. We would require the token's contract address or the token pricing link and once we get that we can get the pricing added.

***

### Q: How to check pricing source of a particular token?

## :a:

To check pricing source of particluar token, follow the steps below:

1. Go to Pricing tab on left side menu.
2. Add the specific token for which you want toc heck pricing for. 
3. You can also add start and end date. 
4. after loading click on any date, and that will open that dropdown.
5. There you will see different columns and you can check your pricing source from the column source.

***

## Q: Does Bitwave show Fair Market Value (FMV) as of the transaction date or today’s date?

:a::

The FMV shown in Bitwave is based on today’s date, not the transaction date.

***

## Q: What if the token I minted isn't listed on CoinGecko or other pricing platforms?

:a::

If the token doesn’t have a price listed on CoinGecko, CoinMarketCap, or similar sources, You can use Bitwave’s Advanced Pricing module to create a custom pricing rule—such as pegging the token to another asset like SOL—to ensure it appears in your records with a meaningful value.

***

## Q: I used the correct ticker (e.g., UST), but pricing still doesn’t appear. What could be the issue?

:a::

The issue may be caused by a mismatch between the ticker used and how it's listed in Bitwave (e.g., “UST” vs “Terra-USD”). Contact support with a transaction ID so we can investigate and correct any discrepancies.

***

<br />

***

<br />
## Q: Why does the price for a token in Bitwave differ from what's shown on CoinGecko or CoinMarketCap?
:a::
Bitwave may pull token pricing from different sources depending on availability and client configuration. If you notice a price discrepancy like seeing ETH listed at $2000 in Bitwave but $2500–$2550 elsewhere—please reach out to our support team with the token details. We’ll verify the correct pricing source and can update it accordingly.
***
<br />
## Q: What should I do if I can't find the correct contract address or pricing for a token in Bitwave?
:a::
Please provide the transaction ID, token symbol, and any supporting links (such as from CoinGecko or CoinMarketCap) when reaching out to our team. This helps us quickly verify the token and ensure accurate pricing is reflected in your account.
***
<br />
## Q: Why is the token price showing as zero for a transaction in Bitwave?
:a::
A price of zero usually means Bitwave couldn’t automatically retrieve a valid price for that token at the time of the transaction. This can happen with newer or less widely listed tokens. If this occurs, you can manually update the price using the pencil icon, or reach out to our team with transaction details so we can investigate.
***
## Q: Can I manually enter a token price if Bitwave doesn't show the correct one?
:a::
Yes, Bitwave allows you to manually update token prices using the pencil icon next to the transaction. This is especially helpful for airdrop rewards or tokens with unavailable pricing at the time. Be sure to enter the accurate value—many clients use reliable sources like CoinGecko for reference.
***
## Q: What should I do if Bitwave doesn't show a recent or accurate token price for an airdrop?
:a::
If the token price isn’t available or is inaccurate, you can manually input the correct rate using the pencil icon. Many users refer to the CoinGecko closing price to ensure accuracy. If needed, contact our support team with the transaction details and token info so we can help.
***
<br />
## Q: Why does the balance report doesn't show the current price of the token whose price is manually added? Does it need to be done manually everytime?
:a::
Yes, that's right pricing should be added manually everytime. As manually updating the price of a particular transaction does not affect the balance report. This is because the balance report will always look to grab pricing for the end of the day that the report was run. So if our system isnt showing pricing for a particular token, we would want to add pricing for it on the backend so that it automatically populates at both the transaction level and the org level (balance report+dashboard report).
***
<br />

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

***
