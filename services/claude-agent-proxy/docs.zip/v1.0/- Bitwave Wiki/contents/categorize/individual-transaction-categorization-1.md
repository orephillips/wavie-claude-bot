---
title: "Individual Transaction Categorization"
slug: "individual-transaction-categorization-1"
excerpt: ""
hidden: false
createdAt: "Wed Apr 10 2024 05:50:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:17:38 GMT+0000 (Coordinated Universal Time)"
---
<p><span style="font-size: 16px;">1.<strong>&nbsp;Individually Categorizing a Transaction</strong></span></p>
<p><span style="font-size: 16px;">&nbsp; &nbsp;&quot;Categorization&quot; is the process of coding your transactions in Bitwave or applying the general ledger account to the transaction. The following categorization types are available when individually categorizing a transaction: &nbsp;</span></p>
<p><span style="font-size: 16px;"><strong>&nbsp; &nbsp;&bull;Standard &nbsp;</strong></span></p>
<p><span style="font-size: 16px;"><strong>&nbsp; &nbsp;&bull; Trade &nbsp;</strong></span></p>
<p><span style="font-size: 16px;"><strong>&nbsp; &nbsp;&bull; Internal Transfer &nbsp;</strong></span></p>
<p><span style="font-size: 16px;"><strong>&nbsp; &nbsp;&bull; Account Transfer &nbsp;</strong></span></p>
<p><strong><span style="font-size: 16px;">&nbsp; &nbsp;&bull; Invoice/Bill Payment</span></strong></p>

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/97edf2e-Individual_Transaction_Categorization_-_Step_1.1.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/053869f-Individual_Transaction_Categorization_-_Step_1.2.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


<div style="text-align: center;"><br></div>
<p style="text-align: center;"><span style="text-align: start; font-size: 16px;">2. <strong>Standard:</strong> Most frequently used option. This transaction type is used for most simple inflow and outflow transactions where the current wallet is interacting with another wallet that does not belong to the client.</span></p>

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/db7c162-Individual_Transaction_Categorization_-_Step_2.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/93a2fa9-Individual_Transaction_Categorization_-_Step_2.2.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


<p style="text-align: center;"><span style="font-size: 20px;"><strong>Example: Deposit Transaction</strong></span></p>

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7cb28cd-Individual_Transaction_Categorization_-_Step_2.3.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d492c98-Individual_Transaction_Categorization_-_Step_2.4.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


<p style="text-align: center;"><span style="font-size: 20px;"><strong>Example: Withdrawal Transaction</strong></span></p>

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3c25ddc-Individual_Transaction_Categorization_-_Step_2.5.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/03468ba-Individual_Transaction_Categorization_-_Step_2.6.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


3. In order to SAVE a transaction, you must select the "Contact" and "Category"as they are required fields.  
   **Contact:**  
   • Select your customer or vendor. If you have synced Bitwave to your ERP, this contact list will  
   be populated for your selection. If you have not connected your ERP, these contacts will need to  
   be manually created under Accounting > Contacts.  
   **Category:**  
   • Select the general ledger account that applies to the transaction line. This list will be synced  
   in from your chart of accounts if you have connected your ERP. If you have not connected your  
   ERP, these categories will need to be manually created under Accounting > Categories.
4. **Categorization Actions**  
   There are additional categorization functions that a user may find helpful, including:  
   • Add/Delete Line  
   • Add/Delete Split  
   • Collapse  
   • Update Pricing  
   • Descriptions and Memo
5. **Add/Delete Line:** This action spreads the total value of the transaction across multiple categories for the SAME contact.

   [block:image]{"images":[{"image":["https://files.readme.io/c1659c1-Individual_Transaction_Categorization_-_Step_5.png",null,""],"align":"center","sizing":"70% "}]}[/block]
6. **Add/Delete Split:** This action spreads the total value of the transaction across MULTIPLE contacts and categories (if desired).

   [block:image]{"images":[{"image":["https://files.readme.io/699df88-Individual_Transaction_Categorization_-_Step_6.png",null,""],"align":"center","sizing":"70% "}]}[/block]
7. **Collapse:** This actions sums the movements of the same token together and feeds only the NET amount to the categorization lines.

   [block:image]{"images":[{"image":["https://files.readme.io/f11cc24-Individual_Transaction_Categorization_-_Step_7.png",null,""],"align":"center","sizing":"70% "}]}[/block]
8. For example, a deposit of 3.339 ETH and a deposit of 4.5 ETH would net to a single inflow of 7.839 ETH for categorization purposes.

   [block:image]{"images":[{"image":["https://files.readme.io/7217250-Individual_Transaction_Categorization_-_Step_8.png",null,""],"align":"center","sizing":"70% "}]}[/block]
9. **Update Pricing**  
   • The "Suggested Rate" displays the exchange rate Bitwave identified based on the transaction time. The default pricing source that Bitwave uses is CryptoCompare.  
   • The "Using Rate" shows the rate actually being used to calculate the fiat value which can be overridden by using the pencil icon to edit the rate.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/279d091-Individual_Transaction_Categorization_-_Step_9.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


10. In order to edit the rate, select the pencil icon, update the value in the "Using Rate" field.

    [block:image]{"images":[{"image":["https://files.readme.io/178db24-Individual_Transaction_Categorization_-_Step_10.png",null,""],"align":"center","sizing":"70% "}]}[/block]
11. Use the checkmark icon to save the rate adjustment.

    [block:image]{"images":[{"image":["https://files.readme.io/aadd5ef-Individual_Transaction_Categorization_-_Step_11.png",null,""],"align":"center","sizing":"70% "}]}[/block]
12. **Descriptions and Memo**  
    The "Description" and "Memo" fields allow the user to add notes or other transaction details that will pass through to the ERP when the transaction is reconciled.

    [block:image]{"images":[{"image":["https://files.readme.io/b746944-Individual_Transaction_Categorization_-_Step_12.png",null,""],"align":"center","sizing":"70% "}]}[/block]
13. The "Memo" line can be added to the transaction without requiring that the transaction be saved.

    [block:image]{"images":[{"image":["https://files.readme.io/50cdd4d-Individual_Transaction_Categorization_-_Step_13.png",null,""],"align":"center","sizing":"70% "}]}[/block]
14. **Trade:** Used when the transaction activity involves an exchange of one asset for another. For example, buying BTC using USD, or trading BTC for ETH.  
    Use the transaction type dropdown to select "Trade"

    [block:image]{"images":[{"image":["https://files.readme.io/7402d7e-Individual_Transaction_Categorization_-_Step_14.png",null,""],"align":"center","sizing":"70% "}]}[/block]
15. When categorizing a trade transaction, you must enter a "Fee Contact" in order to SAVE your categorization.

    [block:image]{"images":[{"image":["https://files.readme.io/81c0805-Individual_Transaction_Categorization_-_Step_15.png",null,""],"align":"center","sizing":"70% "}]}[/block]
16. Click "SAVE"

    [block:image]{"images":[{"image":["https://files.readme.io/43aa040-Individual_Transaction_Categorization_-_Step_16.png",null,""],"align":"center","sizing":"70% "}]}[/block]
17. **Internal Transfer:** Used when the transaction activity involves the movement of an asset from one wallet to another wallet that are both in the same Bitwave org (i.e. owned by the same client).

    [block:image]{"images":[{"image":["https://files.readme.io/25aa898-Individual_Transaction_Categorization_-_Step_17.png",null,""],"align":"center","sizing":"70% "}]}[/block]
18. When categorizing an internal transfer transaction, you must enter a "Fee Contact" in order to SAVE your categorization.

    [block:image]{"images":[{"image":["https://files.readme.io/4988133-Individual_Transaction_Categorization_-_Step_18.png",null,""],"align":"center","sizing":"70% "}]}[/block]
19. Click "SAVE"

    [block:image]{"images":[{"image":["https://files.readme.io/51a7607-Individual_Transaction_Categorization_-_Step_19.png",null,""],"align":"center","sizing":"70% "}]}[/block]
20. **Account Transfer**  
    Used when the transaction activity involves:  
    • Moving a digital asset from a client owned source NOT connected to Bitwave into a Bitwave so you can set a cost basis.  
    • Moving a digital asset from Bitwave to a client owned source NOT connected to Bitwave.  
    • Requires that the "External Cost Basis" be set up for assets disposed under Accounting > External Cost Basis.

    [block:image]{"images":[{"image":["https://files.readme.io/110fc81-Individual_Transaction_Categorization_-_Step_20.png",null,""],"align":"center","sizing":"70% "}]}[/block]
21. When categorizing an account transfer transaction, you must select a "Transfer To" (i.e. a bank account) and "Fee Contact" in order to SAVE your categorization.

    [block:image]{"images":[{"image":["https://files.readme.io/bc62ded-Individual_Transaction_Categorization_-_Step_21.png",null,""],"align":"center","sizing":"70% "}]}[/block]
22. When using the Account Transfer transaction type, you must ensure that you set the "External Cost Basis" by going to Accounting > External Cost Basis.

    [block:image]{"images":[{"image":["https://files.readme.io/8573206-Individual_Transaction_Categorization_-_Step_22.png",null,""],"align":"center","sizing":"70% "}]}[/block]
23. **Invoice/Bill Payment**  
    This type is used when the transaction involves:  
    • An outflow of digital assets as a bill payment(A/P)  
    • An inflow of digital assets as an invoice payment (A/R)  
    By connecting to your ERP, Bitwave will sync in all of your outstanding invoices and bills from your ERP system. Each invoice/bill that is synced in is associated with a customer or vendor.

    [block:image]{"images":[{"image":["https://files.readme.io/d216cdf-Individual_Transaction_Categorization_-_Step_23.png",null,""],"align":"center","sizing":"70% "}]}[/block]
24. To begin categorizing an Invoice/Bill Payment transaction, select the "Contact."

    [block:image]{"images":[{"image":["https://files.readme.io/f878c26-Individual_Transaction_Categorization_-_Step_24.png",null,""],"align":"center","sizing":"70% "}]}[/block]
25. Next, select the "Invoice" which will populate all outstanding invoices/bills for that customer/vendor from your ERP.

    [block:image]{"images":[{"image":["https://files.readme.io/3b2dd12-Individual_Transaction_Categorization_-_Step_25.png",null,""],"align":"center","sizing":"70% "}]}[/block]
26. A row will be created for each digital asset movement and the user will need to indicate how much of the invoice/bill is being satisfied by the digital asset movement in or out under the "Payment Amount."  
    If the value of the digital assets sent/received (price at time of transaction x # of tokens moved) is different than the "Payment Amount" then the user will be presented with an option to categorize the forex gain/loss.  
    In this example, 50 USDC was received to satisfy a $25 invoice. The USDC received is worth $50 so there is a difference of $25 between the "Payment Amount" and the value of the digital assets received, which is accounted for as a foreign exchange gain in the "Forex Gain/Loss" category.

    [block:image]{"images":[{"image":["https://files.readme.io/516b47a-Individual_Transaction_Categorization_-_Step_26.png",null,""],"align":"center","sizing":"70% "}]}[/block]
27. Use the the drop down to search for the Forex Category.  
    (Note: If you do not see an appropriate category, set up a "Forex Gain/Loss" account in your ERP and sync in your chart of accounts prior to categorizing the transaction).

    [block:image]{"images":[{"image":["https://files.readme.io/e6aa348-Individual_Transaction_Categorization_-_Step_27.png",null,""],"align":"center","sizing":"70% "}]}[/block]
28. Click "SAVE"

    [block:image]{"images":[{"image":["https://files.readme.io/6ac1c70-Individual_Transaction_Categorization_-_Step_28.png",null,""],"align":"center","sizing":"7px"}]}[/block]
