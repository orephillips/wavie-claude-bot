---
title: "Create Manual Contacts"
slug: "manual-contacts"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:44:51 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:17:06 GMT+0000 (Coordinated Universal Time)"
---
**Manual Contact :**

Contacts refer to the vendors and customers involved in transactions, providing essential details about who each transaction is made to or received from. These contacts can be created either manually in Bitwave or synced from your ERP system. Assigning a contact to every transaction during categorization helps track financial interactions and  
maintain accurate records.

1. Go to “**Accounting **“ tab on the top left corner

![](https://files.readme.io/60be224-Screenshot_2024-03-04_at_4.16.57_PM.png)

2. Click on **Contacts**

   ![](https://files.readme.io/6be324b-Screenshot_2024-03-04_at_4.57.01_PM.png)

3. Click on **Create Contact**

   ![](https://files.readme.io/28ca0aa-Screenshot_2024-03-04_at_5.04.16_PM.png)

4. Fill out the Contact form with relevant details and select Contact  
   Type from the drop down

![](https://files.readme.io/90d78fd-Screenshot_2024-03-04_at_5.14.14_PM.png)

5. Click “**save**”

   ![](https://files.readme.io/e634dd9-Create_Categories_and_Manage_Expenses_in_Bitwave_Accounting_-_Step_34.png)
