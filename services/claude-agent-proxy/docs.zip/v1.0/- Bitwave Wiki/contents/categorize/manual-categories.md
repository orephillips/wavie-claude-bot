---
title: "Create Manual Categories"
slug: "manual-categories"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:44:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:17:19 GMT+0000 (Coordinated Universal Time)"
---
**Manual Category:**

Categories represent the types of transactions and are equivalent to GL (General Ledger) accounts such as expense, revenue, asset, etc. These categories can be manually created or synced from your ERP system. Properly defining categories helps classify transactions and facilitates financial reporting and analysis.

1. Go to “**Accounting**“ tab on the top left corner

![](https://files.readme.io/3fae3d9-Screenshot_2024-03-04_at_4.16.57_PM.png)

2. Click on **Categories**

   ![](https://files.readme.io/a5297c2-Screenshot_2024-03-04_at_4.57.01_PM.png)
3. .Click on **Create Category**

![](https://files.readme.io/6cfe8e7-Screenshot_2024-03-05_at_11.45.07_AM.png)

4. Fill out the Category form with relevant details and SELECT Category Type from the drop down

![](https://files.readme.io/6d887b7-Screenshot_2024-03-05_at_11.45.55_AM.png)

5. Click “**Save**”

![](https://files.readme.io/64efa10-Screenshot_2024-03-05_at_11.48.07_AM.png)
