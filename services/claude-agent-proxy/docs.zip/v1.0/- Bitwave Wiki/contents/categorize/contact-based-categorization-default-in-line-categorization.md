---
title: "Contact-based Categorization Default & In-line Categorization"
slug: "contact-based-categorization-default-in-line-categorization"
excerpt: ""
hidden: false
createdAt: "Wed Apr 10 2024 23:54:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 12 2024 19:12:35 GMT+0000 (Coordinated Universal Time)"
---
Set Up Contact-based Categorization Defaults (including "in-line" categorization)

## Contact-based Categorization Defaults

To set up Contact-based Categorization Defaults:

1. Select Accounting → Contacts from the left menu:

   ![](https://files.readme.io/7480136-Picture1.png)
2. Locate the Contact you wish to set up defaults for → click Manage:

   ![](https://files.readme.io/c73032c-Picture2.png)
3. Select a Revenue and Expense category from the drop down:

   ![](https://files.readme.io/b7c5554-Picture3.png)

OPTIONAL: If you have an address you would like to assign to the contact, you can add it by selecting the network from the drop-down, adding the wallet address, and clicking the plus sign to confirm:

![](https://files.readme.io/c605cbf-Picture4.png)

You can view addresses and categories assigned on the main Contqacts page:

![](https://files.readme.io/bb82d4e-Picture5.png)

Once an address is assigned to a specific contact and category, any un-categorized transaction with that wallet address on the assigned network will now show the contact and category in the transactions ui - simply click Confirm and the transaction is categorized.

![](https://files.readme.io/c37e79b-Picture6.png)

## In-line Contact-based Categorization Defaults

You can also assign wallet addresses to contacts directly from the transactions ui by clicking on the walletaddress in transaction, selecting a contact from the drop-down, then click Assign to Contact, then click Done.

![](https://files.readme.io/2ed4217-Picture7.png)

You will now see the contact and default category in the transaction.

![](https://files.readme.io/209d583-Picture8.png)

If the transaction is not fully categorized the confirm button will not be active - in the example below the  
fee category is missing:

![](https://files.readme.io/74fc515-Picture9.png)

Categorize the fee by selecting the fee contact then the category here:  
Open the in-line contact selection by clicking in the transactions where shows, selecting the fee contact  
from the drop-down, and clicking Done:

![](https://files.readme.io/7fdec99-Picture10.png)

The open the in-line fee category by clicking the fee, selecting the fee category from the drop-down, and  
clicking Done:

![](https://files.readme.io/abf285b-Picture11.png)

The fee is now in-line categorized and Confirm is now blue:

![](https://files.readme.io/7bb1b0c-Picture12.png)

Click Confirm - the transaction is now categorized!

![](https://files.readme.io/ccde1d1-Picture13.png)
