---
title: "Create Contacts & Categories"
slug: "create-manual-contacts-categories"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:43:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:16:36 GMT+0000 (Coordinated Universal Time)"
---
In Bitwave, managing contacts and categories plays a crucial role in accurately categorizing transactions and organizing financial data. Whether you're dealing with vendors, customers, or different types of transactions, having the right contacts and categories set up ensures effective accounting practices.

If a category or contact is manually created within Bitwave, the “source” will be identified as Bitwave, indicating that it was manually generated within the platform and not synchronized from an ERP. Here's a step-by-step guide on how to manually create contacts and categories in Bitwave:

<br />

[Create Manual Contacts](https://docs.bitwave.io/docs/manual-contacts)

[Create Manual Categories](https://docs.bitwave.io/docs/manual-categories)
