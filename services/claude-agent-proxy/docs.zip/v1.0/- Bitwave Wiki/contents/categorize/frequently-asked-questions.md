---
title: "❓FAQs"
slug: "frequently-asked-questions"
excerpt: ""
hidden: false
createdAt: "Wed Apr 10 2024 05:31:34 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 16:06:13 GMT+0000 (Coordinated Universal Time)"
---
# Categorize

***

## Q : How do I categorize transactions?

### :a:: To categorize your transactions, you can follow there documentations step by step:

1. <https://docs.bitwave.io/docs/individual-transaction-categorization-1>
2. <https://docs.bitwave.io/docs/contact-based-categorization-default-in-line-categorization>
3. <https://docs.bitwave.io/docs/bulk-categorization-2>

***

## Q: What does 'ERROR: More than One Imputed Fee Found' mean?

### :a:: This error in Bitwave involves an issue where an internal transfer transaction imbalance exists across two or more assets.

When an internal transfer has in/out balances that do not align, the difference between the assets is assigned to Fees. Note that the Bitwave application does not allow more than one fee asset per transaction, so the system notifies the user of the two fee asset error.

To solve this error, the user should review the error-causing transaction for accuracy, and, if necessary, modify or split the transaction to remediate this error.

***

## Q: How to verify a transaction has been categorized?

### :a::

***

## Q: Get a report of all transactions that are categorized.

### :a::

***

## Q: How do I delete the manual contacts and categories?

### :a::

You cannot delete the contacts and categories from Bitwave directly by yourself. You need to inform the Support Analyst with all the information in order to remove that from Bitwave. You can override any contact or category by creating the new contact or category with the same Remote ID.

***

## Q: Difference between Add Line and Add Split while doing the Individual categorization?

:a: While doing the Individual categorization Add Line means you can add/split the amount into two or more lines and categorize them individually for respective categories but the contact will remain the same but when you Add split that will also allow adding another contact while categorizing the transactions for their respective category.

***

## Q: What is an Add Line in Individual categorization?

### :a::

 While performing Individual categorization Add Line means you can add/split the amount into two or more lines and categorize them individually for respective categories but the contact will remain the same.

***

## Q: Difference between Add Line and Add Split while doing the Individual categorization?

### :a::

 While doing the Individual categorization Add Line means you can add/split the amount into two or more lines and categorize them individually for respective categories but the contact will remain the same but when you Add split that will also allow adding another contact while categorizing the transactions for their respective category.

***

## Q: How do I delete a category / contact?

### A:

Deleting a category or contact within your Bitwave instance will require the following steps:

1. Contact a Bitwave team member. 
2. Provide your Org ID, Org Name, Accounting Connection Type (QBO, Nesuite, Sage..)
3. Also provide the name of the Category or Contact you want deleted AND the BITWAVE ID for that particular category/contact.

## Q: How to uncategorize transaction in bulk ?

### 🅰️: Here are the steps to uncategorize transaction in bulk

1. Go to systems jobs under administration tab on the left hand side menu
2. Click on create job
3. Select the action ' uncategorize'
4. Select the wallet and choose the time period then hit run

***

## Q: What is an Add Line in Individual categorization?

:a: While doing the Individual categorization Add Line means you can add/split the amount into two or more lines and categorize them individually for respective categories but the contact will remain the same.

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q: How to do bulk categorization for trade transactions?

### 🅰️:

Ok so for trade transactions you can create a **trade rule**  
Here are the details for the same - <https://docs.bitwave.io/docs/set-up-categorization-rules#3-trade-transactions-rule>  
​Refer to the third point in this documentation  
​Also, here is a [video](https://www.loom.com/share/ce1d6833af1447388e3166b58cebf91b?sid=1765f5c7-cfeb-41a5-8d16-634140018d32) to assist you in the process of creating a trade rule

​You can even use our **system jobs** feature to categorize transactions (You will be needing transaction id's of the transfer / trade transaction you are trying to categorize)

![](https://files.readme.io/b0b802006703673b7c321cf1cee1502e60ade25e7f1d991f1fe0a676f3d1fe05-image.png)

***

<br />

## Q: Is there an easy way to record a loan in Bitwave or want to recognize loan revenue on the transaction?

### 🅰️:

Yes you can record that. So whenever you receive the Token back (loan repaid), you can Add Line to the transaction(by opening the transaction) in the transactions UI and split the transaction into two categories : Loan repayment and Loan revenue

***

<br />

## Q: How to Combine and Categorize Transactions as an Internal Transfer?

### 🅰️:

To combine transactions and categorize them as an internal transfer, follow these steps:

1. Navigate to the Transactions section and select All Transactions.
2. Check the boxes next to the transactions (from different wallets) that you want to combine.
3. Click Combine to combine the selected transactions.
4. Categorize them as an Internal Transfer.
   ***
   <br />
   ## Q: Why does the platform periodically prevent me from saving categorized transactions?
   :a::
   This may be caused by a temporary error (like a GraphQL issue) that can occur if certain Chart of Accounts are merged in your connected accounting software. Try refreshing the page or logging out and back in. If the issue persists, please report it with a screenshot so our team can investigate further.
   ***
   <br />

***

<br />

## Q: What should I do after categorizing incomplete transactions?

### 🅰️:

After categorizing the incomplete transactions, revisit your Inventory view and update it. This should resolve the issue of uncategorized transactions. If errors still appear, please notify our support team for further investigation.

***

<br />

## Q: The “Needs Categorization” screen won’t load when I select all wallets. What can I do?

### 🅰️:

If the screen spins or fails to load, try narrowing your wallet selection, refreshing the browser, or clearing your cache. This issue is often related to browser performance or internet connectivity. If the problem continues, please contact support and we can help you categorize transactions manually if needed.

***

<br />

## Q: It takes several minutes to categorize a single transaction. Is this normal?

### 🅰️:

No, categorizing transactions should not take that long. This delay could be due to browser issues or high data volume. As a temporary workaround, try categorizing transactions in the “To Be Reconciled” screen, which may perform better. We're working on performance improvements to address this.

***

<br />

## Q: How do I handle an internal transfer that’s not being processed correctly?

### 🅰️:

For transfers not reflected correctly, you can manually upload them with proper categorization. This might involve creating one transaction for the internal transfer (including both deposit and withdrawal) and a second transaction for any separate fee. Our team can guide you through the correct structure if needed.

***

<br />

## Q: I received a strange error message when trying to categorize a transaction. What should I do?

### 🅰️:

If you encounter an unusual error while categorizing a transaction, try waiting and attempting the action again later, as the issue may be temporary. If the error persists, please share the transaction ID with our support team along with a screenshot of the error for further assistance.

***

<br />

## Q: After importing opening balances, do I need to categorize those transactions? How?

### 🅰️:

Yes, to categorize opening balance imports, include the category and contact ID fields in your import template. Alternatively, you can categorize them manually in the Bitwave UI after import. Categories and contacts must exist in your Bitwave or QuickBooks instance before importing.

***

<br />

## Q: Is there a way to uncategorize and recategorize transactions in bulk instead of one-by-one?

### 🅰️:

Yes! You can use Bitwave’s System Jobs feature to uncategorize transactions in bulk using transaction IDs. Then, simply re-run your categorization rules to recategorize them. Here’s a guide: System Jobs Guide

***

<br />

## Q: Where can I find the template needed for bulk uncategorizing transactions?

### 🅰️:

You can use the CSV Bulk Actions Template. Just enter the transaction hashes under the txnID column and mark the action as “uncategorize.” Upload the completed CSV via the System Jobs tool.

***

<br />

## Q: I’m getting an error when uploading my CSV categorization file what should I do?

### 🅰️:

First, double-check that your file matches the required format. If the issue persists, please share a screenshot of the error with our support team so we can help troubleshoot.

***

<br />

## Q: How do I upload a CSV to categorize transactions?

### 🅰️:

Go to System Jobs and create a new job for transaction categorization. Download the correct CSV template from this section and upload your file accordingly. Make sure the format matches the template exactly.

***

<br />

## Q: Why is categorizing a transaction so slow or causing errors?

### 🅰️:

Slowness or loading issues when categorizing transactions can be due to browser performance or internet connectivity. If you frequently see timeout or error messages, try switching browsers or reducing the number of wallets selected. We're actively working on improving performance in this area.

***

<br />

## Q: Why am I getting an error when trying to run a system job for categorization?

### 🅰️:

This could be due to a formatting issue in your import file used in the categorization system jobs.

***

## Q: How do I import transaction categorizations using a CSV file?

:a::

You can upload your CSV file via the System Jobs section by creating a job for categorizing transactions. Be sure to use the correct template provided in that section. If you encounter errors, contact support and share the template and error message.

***

<br />

## Q: What happens after I report a Fireblocks syncing issue to Bitwave?

:a::

Once you report a syncing issue, our team will check the status of your Fireblocks API connection. If needed, we’ll request a new API key and escalate the issue to our engineering team for further investigation. We’ll keep you updated throughout the process.

***

## Q: How do I disable a wallet completely in Bitwave?

:a::

To fully disable a wallet, you must first delete all transactions associated with that wallet through Administration > System Jobs, then delete the wallet itself. This ensures no transactions remain linked to the disabled wallet.

***

## Q: I’m getting validation errors when trying to delete wallet transactions. What should I do?

:a::

Validation errors can occur if the wallet is linked to exchange wallets or if transactions are still reconciled or categorized. Make sure all transactions are unreconciled and uncategorized before requesting deletion, and if the issue persists, contact support for assistance.

***

## Q: How long does it usually take to disable wallets and delete their transactions?

:a::

The process may take some time depending on the number of transactions and system load. If delays occur, you can escalate the issue with our team for faster resolution.

***

## Q: How do I refresh the Coinbase sync in Bitwave?

:a::

If your Coinbase sync is missing older transactions, our team can manually trigger a resync for you. Please contact support and share the details of any missing data.

***
