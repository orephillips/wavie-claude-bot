---
title: "Multiple Inventories"
slug: "setup-inventory-groups"
excerpt: ""
hidden: false
createdAt: "Fri Jun 07 2024 17:54:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 18:59:51 GMT+0000 (Coordinated Universal Time)"
---
# Multiple Inventories

Multiple Inventories is a feature that allows Bitwave users significant flexibility in managing their digital asset inventory.  In a Bitwave environment with standard configuration, all digital asset holdings are held in a single “inventory.”   An Inventory can be thought of as a “bucket” in which digital assets are tracked for accounting purposes. With a standard single Inventory configuration, Bitwave treats all digital assets (at the lot-level), to be available in the same bucket for asset balance, valuation, and disposal purposes, regardless of which wallet received the original asset lot or which wallet is disposing of the asset.

> 📘 Example - Single Inventory Accounting
> 
> For example, suppose a Bitwave environment with the following configuration and following transaction history:
> 
> - Standard single Inventory configuration
> - There are two wallets connected to Bitwave:
>   - Wallet A and Wallet B.
> - Wallet A acquires 2 BTC on Day 1 (creating Lot #1)
> - Wallet B acquires 2 BTC on Day 2 (creating Lot #2)
> - Wallet B disposes of 1 BTC on Day 3
> - FIFO is being used as the disposal lot picking strategy
> 
> In this example, when Wallet B disposes of 1 BTC on Day 3, Bitwave will dispose of the 1 BTC from Lot #1 because it is the earliest lot acquired across all wallets, and FIFO is the picking strategy being used.  The cost basis of Lot #1 will be used to calculate the realized gain/loss on disposal.  Note that Bitwave will use Lot #1 as the lot being disposed by Wallet B regardless of the fact that Lot #1 was actually acquired by Wallet A.  This is due to the use of a single Inventory, which treats all assets as being available in the same bucket for disposal purposes.

# Why Use Multiple Inventories?

Instead of treating all assets as belonging in a single bucket of disposal relief purposes, Inventory Groups allow the Bitwave user to create customized Inventories (i.e. “buckets) to segregate asset balance tracking, valuation, and disposal purposes.  There are many different use cases for leveraging Bitwave’s Multiple Inventories feature, including:

- **Corporate vs. Customer asset tracking:** Corporate and Customer assets can be tracked separately for cost basis, valuation, and gain/loss purposes within the same Bitwave environment
- **Parent & Subsidiary Entity asset tracking: **A single Bitwave environment can be used to separately track the assets and transaction activity results for multiple-entity structures within the same Bitwave environment
- **Segregating zero and/or low cost basis tokens: **Many of our customers acquire zero or low cost basis tokens in the course of their business and use our Multiple Inventories to segregate those assets so that they can separately manage and track the disposal of those tokens, which can have a significant impact on realized gain/loss results.
- **Strategic disposal decision making: ** Bitwave customers can fund wallets with assets that fall within specific cost basis tranches and set up those wallets as separate Inventories in Bitwave, and then use the Multiple Inventories in Bitwave to make strategic disposal decisions (i.e. which wallet should be used for disposal) to achieve desired realized gain/loss results.

# How to Use Multiple Inventories

There are two ways to structure segregated Inventories in Bitwave: 

1. WLI (Wallet-Level Inventories)
2. Inventory Groups

## Method #1: WLI (Wallet-Level Inventories)

A Bitwave environment configured with WLI treats all wallets as their own, stand-alone Inventory.  This means that assets, cost basis, valuation, and realized gain/loss are tracked at the individual wallet level.  For disposal purposes, Bitwave will only dispose of lots that were acquired by the same wallet.

> 📘 Example - WLI
> 
> For example, suppose a Bitwave environment with the following configuration and following transaction history:
> 
> - WLI configuration
> - There are two wallets connected to Bitwave; Wallet A and Wallet B.
> - Wallet A acquires 2 BTC on Day 1 (creating Lot #1)
> - Wallet B acquires 2 BTC on Day 2 (creating Lot #2)
> - Wallet B disposes of 1 BTC on Day 3
> - FIFO is being used as the disposal lot picking strategy
> 
> In this example, when Wallet B disposes of 1 BTC on Day 3, Bitwave will dispose of the 1 BTC from Lot #2 because it is the earliest lot acquired within the same wallet that is disposing.  The cost basis of Lot #2 will be used to calculate the realized gain/loss on disposal.  In a WLI configuration, a wallet can only dispose of asset lots that were acquired and maintained within the disposing wallet.

## Method #2: Inventory Groups

Bitwave allows users to create customized Inventory Groups for asset tracking and accounting purposes.  With this type of configuration, the Bitwave user can create an unlimited number of Inventories (i.e. “buckets”) and allocate data sources (e.g. wallet addresses and exchange accounts) to those Inventories as desired. 

![](https://files.readme.io/f8f2a61-image.png)

For example, if a Bitwave environment has 10 Ethereum wallet addresses connected and two exchange accounts, the user can create the desired number of inventories and allocate those 12 data sources to the different Inventories accordingly.   The following diagram illustrates two potential Inventory Group setups.  It should be noted that the user can create any number of inventories (up to 12 in this case because there are 12 total data sources) and split up the data sources across them.

![](https://files.readme.io/74a93dd-image.png)

![](https://files.readme.io/dee7f24-image.png)

<br />

> 📘 Example - Inventory Groups
> 
> For example, suppose a Bitwave environment with the following configuration and following transaction history:
> 
> - Inventory Groups aligned with the ‘Sample Inventory Group Setup” above that includes three total Inventories
> - There are ten wallets + two exchange accounts connected to Bitwave
> - Wallet A acquires 2 BTC on Day 1 (creating Lot #1)
> - Wallet B acquires 2 BTC on Day 2 (creating Lot #2)
> - Wallet H acquires 1 BTC on Day 3 (creating Lot #3)
> - Wallet J acquires 1 BTC on Day 4 (creating Lot #4)
> - Wallet J Disposes of 1 BTC on Day 5
> - FIFO is being used as the disposal lot picking strategy
> 
> In this example, when Wallet J disposes of 1 BTC on Day 5, Bitwave will dispose of the 1 BTC from Lot #3 because it is the earliest lot acquired within the same Inventory (Inventory #2).  The cost basis of Lot #3 will be used to calculate the realized gain/loss on disposal.

# Multiple Inventory Reporting

When a Bitwave environment is configured to use Multiple Inventories, the rest of Bitwave’s reporting will track the results of that report according to the Inventory structure selected for that set of books.  For example, our Inventory Views Rollforward Report tracks asset holdings and activity based on the custom grouping configuration for that View:

![](https://files.readme.io/132af68-image.png)

Additionally, our granular lot-by-lot Actions report includes which inventory each asset lot is in, as well as to/from Inventory data for movements between wallets/inventories:

![](https://files.readme.io/f0a0913-image.png)

# How to Set-Up Multiple Inventories

Inventories can be configured in the Inventory Management section of Bitwave: 

![](https://files.readme.io/b3f4215-image.png)

<br />

In this page, users can create Inventory Groups (a collection of segregated inventories) and assign data sources (e.g. wallets and exchange accounts) to each Inventory within the group. 

**For a detailed walkthrough of how to configure the Inventories, watch this video: **

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.loom.com%2Fembed%2F1f48a62787b44711b5042aa0393e3f8c&display_name=Loom&url=https%3A%2F%2Fwww.loom.com%2Fshare%2F1f48a62787b44711b5042aa0393e3f8c%3Fsid%3D9800938f-8d12-446f-a319-090af7c1056c&image=https%3A%2F%2Fcdn.loom.com%2Fsessions%2Fthumbnails%2F1f48a62787b44711b5042aa0393e3f8c-00001.gif&key=02466f963b9b4bb8845a05b53d3235d7&type=text%2Fhtml&schema=loom\" width=\"1686\" height=\"500\" scrolling=\"no\" title=\"Loom embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.loom.com/share/1f48a62787b44711b5042aa0393e3f8c?sid=9800938f-8d12-446f-a319-090af7c1056c",
  "title": "How to Set Up Inventory Groups",
  "image": "https://cdn.loom.com/sessions/thumbnails/1f48a62787b44711b5042aa0393e3f8c-00001.gif",
  "provider": "loom.com",
  "href": "https://www.loom.com/share/1f48a62787b44711b5042aa0393e3f8c?sid=9800938f-8d12-446f-a319-090af7c1056c",
  "typeOfEmbed": "youtube"
}
[/block]


Once the Inventories have been configured, the user can select the Inventory Group they want to use for each set of books when a new Inventory View is created:

![](https://files.readme.io/c7e2431-image.png)

Once the desired Inventory Group has been selected, the Inventory View will use that configuration to track asset balances, valuations, and gain/loss calculation at the inventory-level.
