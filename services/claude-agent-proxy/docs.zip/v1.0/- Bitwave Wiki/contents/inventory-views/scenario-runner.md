---
title: "Scenario Runner"
slug: "scenario-runner"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:39:21 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:13:15 GMT+0000 (Coordinated Universal Time)"
---
1. Once you have reconciled and synced your activity to your ERP system, you are ready to move onto running your reports. In this section we will explore the Gain/Loss report. On the left menu navigate to gain/loss → scenario runner. The initial setup with require that you select an accounting method for your cost basis:  
   a. _FIFO (first-in-first-out)_ - The first assets into the lot/inventory would be used first. Note that we also enable wallet tranched FIFO where the FIFO activity is performed on a per wallet basis as opposed to on the entire inventory.  
   b. _LIFO (last-in-first-out)_ - The last assets into the lot/inventory would be used first.  
   c. _Cost Average_ - The average cost of the assets in the lot/inventory would be the cost basis applied.  
   d. _Specific identification or HIFO (highest-in-first-out)_ - A pre-configured specific identification strategy.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2462676-Gain-Loss_1.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. **FIFO or LIFO tax method**

   Selecting FIFO or LIFO prompts you to the next screen

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a59dcc1-Gain-Loss_2a.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


![](https://files.readme.io/943999f-Gain-Loss_2b.png)

3. **Cost Average Tax Method**

a. Selecting the Cost Average method will prompt you to set a starting date for your taxes.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/bf925e4-Gain-Loss_3a.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


b. This gives you the option to override the cost average data, which will IGNORE all prior historical data in order to match your previously reported tax filing balances.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/05d296d-Gain-Loss_3b.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


c. Check the box to set your beginning balance date and setup overrides to the cost average data.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/85ebe70-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


d. Selecting the Tax Starting Date will IGNORE all historical transactions up to this date.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ede9b2c-Gain-Loss_3d.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


e. Input the ticker(s) and your predetermined cost average rate per token.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b2e9f99-Gain-Loss_3f.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


f. Select SAVE AND FINISH and this step is complete.

![](https://files.readme.io/097f15f-Gain-Loss_3g.png)

4. **SpecID or HIFO**

a. Selecting the Specific ID method will prompt you to set up overrides by token or allow you to default to a zero cost basis for all tokens.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ea0bba1-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


b. Input the ticker(s) and your predetermined cost average rate per token.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/39707af-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


c. You may choose to force all tokens to default to a zero cost basis for the starting balances.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cb7d7b2-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


d. You have the option to exclude specific tokens from being overridden or defaulted to the zero cost basis and to use the Bitwave calculated cost basis by inputting the excluded coins.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/681a38c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


e. Selecting the Tax Starting Date will IGNORE all historical transactions up to this date.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b3272ce-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


f. Select SAVE AND FINISH and move to the next step to set up the Tax Strategy.

g. Navigate to administration → tax strategy to configure your SpecID strategy. You can choose a spending strategy to maximize or minimize short-term or long-term gain and loss. Whatever you select here will be reflected in the outcome of the gain/loss report under the specID tax strategy.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fce7ed3-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


h. In order to set up a HIFO (highest-in-first-out) strategy, select the following fields for the spending strategy and preference and select SAVE.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e185197-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Once you have selected your accounting method, you will be brought to this scenario runner: 

   - Gain Loss Start Date: Select the start date for the gain/loss period
   - Gain Loss End Date: Select the end date for the gain/loss period
   - Tax Strategy: Select FIFO, LIFO, Avg Cost, or SpecID
   - Capitalize Fees: A checkbox to capitalize or expense fees. If expensing fees, please reach out via our in-app support for additional configuration.
   - Ignore NFTs: A checkbox to run the reports excluding NFT tokens.

   Start running the tax scenario by selecting the start and end date for your tax period. Choose the tax strategy from the prior step. You can choose to Capitalize Fees or not. Capitalizing fees will include acquisition fees in the calculation of cost basis. You may choose to ignore NFT tokens or include them in reporting. Once all fields are selected, select the RUN SCENARIO button which will produce a series of results and reports.

   [block:image]{"images":[{"image":["https://files.readme.io/85aa6db-image.png",null,""],"align":"center","border":true}]}[/block]

This runner provides the following summaries and reports: (SKIP FOR ONBOARDING)

a. **Gain Loss **-  a summary of unrealized and realized gains and losses, wrapping related adjustments, and impairment expense

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8963996-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


b. **Exchange Rates** - the fair market price per token at the time of the “Gain Loss End Date”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a18cebd-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


c. **Summary Lines** - a summary of ending token balances, total cumulative cost basis, and ending realized gain or loss, and ending unrealized gain or loss on a token-by-token basis

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cb37579-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


d. **Scenario Results** - a transaction level summary of cost basis, proceeds, dispositions, cost, exchange rate, unrealized gains, gain/loss, ending token balance, and acquisition details

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/18af55b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


e. Reports available for download:  
i. _Actions CSV report_ - lot-by-lot level details for the acquisition (cost basis), disposal, gain or loss recognition, and impairment of assets  
ii. _Large CSV report_ - transaction level details of cost basis, disposals, gain or loss recognition, and ending token balances  
iii. _Summary report _- token ending balances and summary of cost basis and ending realized and unrealized gains and losses

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2f3a4c6-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


**Gain & Loss Explained**

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.loom.com%2Fembed%2F30612a4eb19d4a6883a9ff867f0dbb3a&display_name=Loom&url=https%3A%2F%2Fwww.loom.com%2Fshare%2F30612a4eb19d4a6883a9ff867f0dbb3a&image=https%3A%2F%2Fcdn.loom.com%2Fsessions%2Fthumbnails%2F30612a4eb19d4a6883a9ff867f0dbb3a-1674712367769.gif&key=02466f963b9b4bb8845a05b53d3235d7&type=text%2Fhtml&schema=loom\" width=\"1920\" height=\"1440\" scrolling=\"no\" title=\"Loom embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.loom.com/share/30612a4eb19d4a6883a9ff867f0dbb3a",
  "title": "Videos Everywhere - Gain Loss Runner",
  "image": "https://cdn.loom.com/sessions/thumbnails/30612a4eb19d4a6883a9ff867f0dbb3a-1674712367769.gif",
  "provider": "loom.com",
  "href": "https://www.loom.com/share/30612a4eb19d4a6883a9ff867f0dbb3a",
  "typeOfEmbed": "youtube"
}
[/block]


**Accounting Connection**

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F5KZyPoSKPbk%3Ffeature%3Doembed&display_name=YouTube&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D5KZyPoSKPbk&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F5KZyPoSKPbk%2Fhqdefault.jpg&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" title=\"YouTube embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=5KZyPoSKPbk",
  "title": "Segment 2c: Connect your General Ledger (ERP) Software",
  "favicon": "https://www.google.com/favicon.ico",
  "image": "https://i.ytimg.com/vi/5KZyPoSKPbk/hqdefault.jpg",
  "provider": "youtube.com",
  "href": "https://www.youtube.com/watch?v=5KZyPoSKPbk",
  "typeOfEmbed": "youtube"
}
[/block]
