---
title: "Setup Inventory Views"
slug: "setup-inventory-views"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:03:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 14:43:29 GMT+0000 (Coordinated Universal Time)"
---
### How To Set Up an Inventory View

1. Create your first inventory view, by going to the “Inventory” menu, click “View”, and click “Create View”. Select your picking strategy, whether to capitalize fees, and whether enable impairment. Lastly, give your view a name, hit SAVE, and you’re off to the races!

![](https://files.readme.io/7665afe-image.png)

> 🚧 Note: All Bitwave licenses include the ability to create one view, additional views require the purchase of an upgraded license, contact [solutions@bitwave.io](mailto:solutions@bitwave.io) for more information on creating additional views.

2. Configure Settings According to Preferred Accounting Treatments

   ![](https://files.readme.io/d4f3f88-image.png)

   <br />

### Available Configuration Settings

- Picking strategy: FIFO, LIFO, SPEC ID (note that SPEC ID is based on predefined disposal preferences in the Tax Strategy section of the Administration menu)
- Valuation Methodology: Historical Cost Basis, GAAP Impairment, GAAP Fair Value, IFRS Impairment, IFRS Impairment with Revaluation, Mark to Market
- Capitalize fees (determines if fees on trades should be capitalized as part of the acquired asset cost basis vs. being expensed)
- Ignore NFTs: when checked, NFTs will be ignored when calculating realized gain/loss, cost basis, etc.
- Ignore Org Wrapping Treatments: When checked, disposals and realized gain/loss calculations will ignore wrapping treatments set up in Wrapping Treatments section of the administration menu. When unchecked, all calculations will reflect the wrapping treatments.
- Multiple Inventories: This setting allows for the use of segregated inventories. Note that the relevant inventory groups and wallet assignments must be created before selecting  
  this option within the Inventory Management Section of the Administration menu.

### Advanced Settings - Engine Version

Version 2.2 or later must be selected when using multiple inventories, GAAP Fair Value, or any IFRS valuation methodologies.

**Click Expand in the Advanced Setting to view/edit the Engine Version**

![](https://files.readme.io/4ee2fe2-image.png)

**Choose the desired Engine Version in the dropdown menu and click collapse when finished.**

![](https://files.readme.io/b934c2a-image.png)

### Running Updates

Once an inventory view has been created, you can use the “as of” option to view the inventory information as of a particular date, or bring the view to today’s date by clicking the “Update Now” button.

To run an update, go to the Updates tab within Inventory Views (Left Menu -> Inventory Views -> Update Tab) and click the Update Now button.

![](https://files.readme.io/307556f-image.png)

> 🚧 Note that an update must be run for Inventory Views reporting to reflect any changes to transactions or categorization since the last update.
