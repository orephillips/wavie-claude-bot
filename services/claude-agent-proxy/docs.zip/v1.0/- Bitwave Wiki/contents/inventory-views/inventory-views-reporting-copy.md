---
title: "Inventory Groups"
slug: "inventory-views-reporting-copy"
excerpt: "This is a paid Feature Flag, so it needs to be turned on."
hidden: false
createdAt: "Tue Mar 25 2025 14:33:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Mar 25 2025 14:39:03 GMT+0000 (Coordinated Universal Time)"
---
## STEP 1: Creating an Inventory Group

 Here are the steps to create Inventory Groups :

1. Go to Inventory tab.

2. Go to inventory Groups.

3. On top of that, there is a dropdown for Groups.

4. When you open the dropdown, it says Create Groups.

5. Click on that and name the Group.

6. Hit save and click save changes on the right side twice.

7. Refresh the page and you can see Inventory Groups in the dropdown.

![](https://files.readme.io/f25bb60838c2f52ccd0b111ca7a5c440333282c4d3fb614a2767f417fdf1bdda-image_23.png)

***

## STEP 2: Creating Inventory

Here are the steps to create Inventories after creating Inventory Groups :

1. Navigate to the Inventory tab.

2. Select the option to Create Inventory on the right side of the screen.

3. Provide a name for the inventory and click the Save button.

4. Remember to click Save Changes in the top right corner to save all the changes.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b9dff0762be3ab96685a86ee070d829faa1e42f4f8cdd1cf4cab3070e8f9a69f-image_24.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "-1px"
    }
  ]
}
[/block]


***

## STEP 3: Assigning wallets to inventories

Here are the steps for assigning Wallets to Inventories :

1. Navigate to the Inventory tab.

2. To move wallets, simply check the box next to each wallet on the left side.

3. Once you have selected the desired wallets, click on the "Move To" button.

4. From the drop-down menu, select the inventory where you want to move the wallets.

5. Click on "Move" to complete the transfer.

6. Make sure to save your changes by clicking on "Save Changes" in the top right corner.

7. To confirm if the wallets have been successfully moved, check if the inventory name appears in front of each wallet. If "Default" is still displayed, it means the wallet has not been assigned or moved to an inventory yet.

![](https://files.readme.io/99f5be88da04d991af6d39892e72cf62f0897518e80ba8b0fae52be08f2923a0-image_25.png)

***

## STEP 4: Assigning Inventories to GL accounts

Here are the steps to assign Gain/Loss Accounts to Inventories.

1. Navigate to the Inventory section.

2. Select the inventories you want to assign to a Gain/Loss Account by checking the corresponding box.

3. Click on the "Assign To" button and and assign the Inventories to whichever Gain/Loss Accoun you want to assign them.

4. Click "Assign" and a Gain/Loss Account will be assigned to that Inventory.

5. Remember to click "Save Changes" in the top right corner to save all the changes.

6. To verify if the Gain/Loss Account has been successfully assigned, check if the Account Name appears in front of the inventory. If it says "Unassigned," the Gain/Loss Account has not been assigned to that inventory.

![](https://files.readme.io/34ec78625f1c9547c8bce45123776a8c5b075726cf755fced595a851e930f517-image_26.png)

***
