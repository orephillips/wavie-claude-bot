---
title: "Cost Basis Rollforward"
slug: "cost-basis-rollforward"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 02:49:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 14:53:59 GMT+0000 (Coordinated Universal Time)"
---
Cost Basis Rollforward report or Cost Basis Rollforward (Expanded) is used to see the results of your transaction activity between any two selected dates.

![](https://files.readme.io/6ac269e-image.png)

 This report shows the realized gain/loss and impairment expense for any  
selected date range, as well as:

● Starting date cost basis and token quantity  
● Acquisitions (token quantity and functional currency value)  
● Disposals (token quantity and functional currency value)  
● Impairment Expense during date range  
● Realized Gain/Loss during date range  
● Ending cost basis and token quantity

To get your data for any given date, select a date and click submit. The information can be viewed directly on-screen or downloaded as a CSV 

![](https://files.readme.io/0633568-image.png)
