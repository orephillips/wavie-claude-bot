---
title: "NEW! Reallocation Setup for Inventory View"
slug: "new-reallocation-setup-for-inventory-view"
excerpt: ""
hidden: false
createdAt: "Fri Dec 20 2024 14:52:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Feb 12 2025 16:31:51 GMT+0000 (Coordinated Universal Time)"
---
# **Overview**

## **Creating** “ _Reallocation Inventory View _”

1. **The first step is to create a Standard Inventory View.** The standard view should be your currently used inventory view.  Note that it is likely you have already completed Step 1, as this is the view that you currently use to close your books pre-allocation
2. **The next step is to create the Balance Only Inventory view.** The balance only view is an inventory view you create. Its purpose is to obtain the balances of all your wallets on a wallet by wallet basis to establish the foundation for reallocation. It is important that this inventory view has NO negative balances otherwise it cannot be used.
3. After creating both the views, Make sure to update those views before creating the **Reallocation Inventory View” .**
4. For reallocation of the view, Please make sure all the **Pre-Requisites** (_mentioned below_) are fulfilled.

> ❗️ ## **Pre-requisites** _before creating Reallocation inventory views_ :
> 
> 1. All transactions must be categorized and books closed up till the date you decide to reallocate.
> 2. Your **Standard** and **Balance Only** views should both be updated after all transactions have been categorized.
> 3. There should be no errors or negative balances in your standard inventory view.
> 4. Ensure you have had a consultation with your tax or accounting lead / expert regarding your desired reallocation approach.

## **Steps to create Standard Inventory View :**

### **_Steps to create Standard Inventory View:_**

1. Click **“ create view ”**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/714906a7ac041dc18b7469b9f5df2f4196a703b4d9bce1c6f4d51215292f7e8b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. Name the view and select the desired **“Picking Strategy”**  and **“Valuation Strategy”** and hit **“Create Inventory View”.**  
   _See additional information [here](https://docs.bitwave.io/docs/set-up-inventory-views) regarding inventory views setup._

### **NOTE : While creating new inventory views, the options below in the red box should be checked.**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0325fbadfb4422196f8a234442eab9692e27ab15a9dcbef398b6f85fa969482f-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## **Steps to create Balance Only Inventory :**

### **_Repeat the same process with some different instructions _**:

1. Click on **“Picking Strategy”** and select **“Balance Only”**.
2. Click on **“ Expand ”** and change the engine version to the latest version (v2.0 or higher).
3. After you change the engine to a version that is v2.0 or higher, you will now be able to select multiple inventories, so click on **“Multiple Inventories.”** 
4. After selecting Multiple Inventories, click on **“Inventory Mapping Strategy”** and you must select the **“Per Wallet”** option.

**_Note that a user may also use our custom Inventory Groups feature for inventory management.  For more information on how to subscribe to this feature, please reach out to your Bitwave representative._**

### **NOTE that Valuation Strategy and all other options that are not mentioned above should match with the standard view.**

5. Confirm all the settings and hit **“Create Inventory View”**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f14ae152879282bd51bfa687b6f55bf50eb1c7023591d034369fa9b5e890182c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


**After creating the Standard View and Balance-only View, please update both the views and  let them update completely before creating the reallocation view.**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3636f25de3321b34db889d3d33b13260e4a145d447e2ba271bc679672cdfa74e-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/98ea4631f283bb153349041b506aa5342d2a05c32b390ecaa5ce53c1feda295a-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## **Steps to create Reallocation Inventory :**

### **_After the Standard and Balance Only views are updated successfully, create the Reallocation Inventory View with the same process described above, but with the following modifications in selecting the options_ :**

1. Picking strategy and validation strategy should be same as your **Standard** inventory view
2. Please select the same engine version as the **Balance Only** inventory view. 
3. Choose Multiple Inventories and select the same inventory mapping as **Balance Only** inventory view
4. Also for the inventory mapping strategy, you can select either of the options (Per Wallet or Inventory Groups) depending on your preference. 
5. Select “ **USE VIEW FOR REALLOCATION** ”.

### _**Please confirm all the selected options as shown in the screenshot below**_.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/070b040237c10e9cce34563595ac624c2151efc99d3c690bd9a24a0fb5c5120e-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


## **Running Reallocation Inventory View**

1. After creating all three views successfully, Click on your **Reallocation Inventory View** and go to the “**Reallocation**” menu at the top of the Inventory Views screen.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/931247d85ce280f82c1e265e1768f2081e6d531eba58db177ee46182592480c9-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/530a3487ab6b46150124f9cfde70f67793ab62bf165d54c87f94d9d4a8425892-image.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "550px",
      "border": true
    }
  ]
}
[/block]


2. Please select the following options as suggested below : 

For **“Lots Report View”**, select **“Standard View.”**

For **“Wallet Balance View”**, select **“Balance Only View.”**

The End Date selected should be the last day before you want the Reallocation to occur. In most cases this date will be 12/31/2024. For example, if you are reallocating your inventory lots as of January, 1 2025, then the End Date that should be entered here is 12/31/2024. 

For **“Lot Application Order”**, you can select the desired option **“Earliest to Latest Acquired”** or **“Latest to Earliest Acquired ” **

For **“ Wallet Application Order ”**, you can select the desired option **“ Highest to Lowest Qty Balance”** or **“Lowest to Highest Qty Balance ”**

<br />

3. Go to the Updates Tab

<br />

![](https://files.readme.io/b8bc5ec9d3e0acc82f051724cb59611d7d8e2e71842363feb4dc4491a98f6b3c-Screenshot_at_Feb_12_21-59-26.png)

<br />

4. Fill out these boxes in Red (in screenshot)

<br />

The Reference Run ID is the run ID from the view you are using for your PRE-reallocation results.  If your reallocation date was 12/31/24, you will put in the Reference Run ID from your pre-reallocation Inventory View and you will put 12/31/24 in the Reference Run End Date box. This will bring in the results from your old (pre reallocation) view through your cutoff date

Put whatever date you desire in Current Run End Date (I usually just use todays date so it updates everything)

5. Click Update Now
