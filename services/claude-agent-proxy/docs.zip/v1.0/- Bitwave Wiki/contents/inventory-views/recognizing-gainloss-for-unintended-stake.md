---
title: "Wallet Level Inventory groups for staked units and rewards"
slug: "recognizing-gainloss-for-unintended-stake"
excerpt: ""
hidden: true
createdAt: "Fri Jun 28 2024 15:35:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 30 2024 19:48:03 GMT+0000 (Coordinated Universal Time)"
---
Navigate to Inventory Management under Administration in the left task pane and select Create Inventory Group to open the Finish Creating Inventory Group window and name the Inventory Group.

![](https://files.readme.io/c000c08-image.png)

Select the newly created Inventory Group from the Select Inventory Group dropdown and click the bottom right button to Create Inventory. The Finish Creating Inventory window will open name the Inventory and save.  

![](https://files.readme.io/5a4afa3-image.png)

Create an Inventory that is for all wallets that are staked unit and a separate Inventory for all wallets that are reward units. Select the Inventory from the Select Inventory drop down and select the corresponding wallets using the Move To Inventory button. Any wallets that are not moved to an Inventory will automatically be part of the default Inventory.

![](https://files.readme.io/3e0a2bd-image.png)

![](https://files.readme.io/5f7bc1b-image.png)

Create an Inventory View that is configured to use Engine Version 2.2 or above, check the box for Multiple Inventories, select Inventory Groups from the Inventory Mapping Strategy dropdown and select the newly created Inventory Group from the Select Inventory Group dropdown.

![](https://files.readme.io/2373301-image.png)
