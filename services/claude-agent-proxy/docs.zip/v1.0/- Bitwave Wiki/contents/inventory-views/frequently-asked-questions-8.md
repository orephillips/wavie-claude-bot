---
title: "❓FAQs"
slug: "frequently-asked-questions-8"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:06:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed May 28 2025 19:36:25 GMT+0000 (Coordinated Universal Time)"
---
# Inventory Views

***

## Q. How to delete transactions in bulk ?

### :a:﻿:

Steps to delete transactions in bulk:

1. Go to Administration tab on the left hand side menu 

   ![](https://files.readme.io/e477451-image.png)
2. Click on system jobs, then create job. 

   ![](https://files.readme.io/ad68282-image.png)
3. In actions dropdown click delete transaction. 
4. Then select the wallet and time period and hit run. 

   ![](https://files.readme.io/7be8fd7-image.png)

## Q. How to get pricing link of any token

  🅰️ Bitwave takes pricing mainly from two sources that are:

- Coingecko 
- CryptoCompare

Steps:

- Go to <https://www.cryptocompare.com/> or  <https://www.coingecko.com/> 
- Search the name of that token

### Q. Ways to ignore Transaction

 🅰️

1. How to ignore transaction from transactions UI

(Suitable for ignoring few random transactions) 

```
-> Go to the Transactions tab on the left hand side menu.
-> Click on the box on the left side of the transaction you want to ignore. ( You can select multiple as well)
```

   \-> On the above tab click ignore

![](https://files.readme.io/7730196-image.png)\*\*\*

## Q: How to get monthly unrealized gain/loss from inventory?

### :a::

Ensure Inventory View is Updated:  
Before downloading the report, ensure your inventory view is current by navigating to Inventory and clicking on "Update Now" in the top-left corner. Please note that the last update in your org was in March, so updating will provide you with the latest data.

Download Actions Report:  
1.Go to Inventory.  
2.Click on Actions.  
3.Add the preferred date range or submit date filters.  
4.Once filtered, click on "Download Actions" to export the report as a CSV file.

Perform Pivot Table Analysis:  
1.Open the downloaded CSV file in a spreadsheet application such as Excel or Google Sheets.  
2.Create a pivot table to summarize the data by month or any other desired criteria.  
3.Utilize the pivot table to analyze gain/loss data specifically for each month.

***

## Q: What does this error mean on the update inventory tab: Errored: More than one imputed fee found. This is not supported.

### :a: It means you are trying to do an internal transfer and the in/out amounts don’t align— the difference goes to Fees…but the error you have is telling you that in/out imbalance exists on two different assets, and the system only allows one.

***

### Q: How to update the Inventory views?

### :a::

- Go to "Inventory"
- Go to updates
- Click on "Update Now"
- Click on the blue rounded arrows to update the status.
- The status will be "Complete" once the Inventory views got updated.

![](https://files.readme.io/8353cc4-Screenshot_368.jpg)

***

## Q: What is the difference between IFRS and IFRS Revalued (both are options when setting up inventory views)?

### :a::

"**IFRS**:  
1.acquisition recorded at cost basis

2. if price drops below cost basis-> impairment expense  
   3. if price goes back up ->reverse impairment expense BUT NEVER ABOVE original cost basis

\*\*IFRS Revalued:

1. \*\*acquisition recorded at cost basis

2. if price drops below cost basis-> impairment expense

3. if price goes back up ->reverse impairment expense BUT NEVER ABOVE original cost basis

4. - Additional adjustment upward if market price rises above original cost basis"

5. How to ignore transactions using rules

 ( Suitable when ignoring multiple transaction from particular wallet for a specific period )

![](https://files.readme.io/e95ef82-image.png)

```
 -> Go to the Transactions tab on the left hand side menu.
-> Click on rules, then create rule
-> Fill the details, hit save
-> Select the rule created
-> Click on actions, then click run
```

3. How to ignore transactions Via system Jobs

( Suitable when ignoring multiple transaction from particular wallet for a specific period )

\-> Go to Administration tab on the left hand side menu  
-> Click on system Jobs  
-> Then create job  
-> In actions dropdown click ignore transaction  
-> Then select the wallet and time period and hit run.

![](https://files.readme.io/9ab9bf1-image.png)

***

1. ![](https://files.readme.io/da88390-image.png)

2. Click on Actions then delete 

   ![](https://files.readme.io/60fd00c-image.png)

***

## Q:  How to find inventory view run ID?

### 🅰️ :

To get Inventory view run ID:  
​

1. Go to Inventory

   <br />

   [block:image]{"images":[{"image":["https://files.readme.io/fc4b8b4-Run_id_1.png",null,""],"align":"center"}]}[/block]
2. Go to updates

   <br />

   [block:image]{"images":[{"image":["https://files.readme.io/82ebfb9-run_id_2.png",null,""],"align":"center"}]}[/block]
3. There you can find a column as Run Id, copy that ID.

   <br />

   ![](https://files.readme.io/7730196-image.png)

***

## Q: How do I Identify Errors in Inventory Views?

### :a:﻿:

 To find a list of errors in Inventory Views, follow the steps below:

1. Navigate to Inventory > Views
2. Click on the Actions tab
3. Click the Three Box logo on the right side of the Inventory Views Actions table
4. Check "Line Error" to add the Line Error column to the table
5. View the error for the specific Inventory View run

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3405daf-image.png",
        null,
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]


***

## Q.: What is inventory view?

### 🅰️ :

Inventory View” was born out of Bitwave’s engagement with clients involved in some of the most complex and high-volume digital asset use cases with transactions ranging from hundreds of thousands to millions of transactions a year. The data tables in inventory views  are highly responsive and performant.

Users can at a glance, access important balance, lot, and roll-forward information for their digital asset inventory (e.g. cost basis acquired, cost basis disposed, impairment, carrying value, FMV, unrealized G/L, and more…) through an “Inventory View”.

Users can now easily maintain separated tax and accounting books by creating multiple views of their inventory (Note: creating 2 or more inventory views requires the purchase of an upgrade).

***

## Q : How to delete current inventory view?

### :a:: To delete the current view, please follow the steps below :-

1. Go to inventory views
2. Select Settings.
3. Click on expand
4. Click on " Delete View " 
5. Enter the name of the view in the name box
6. Click " Yes, Delete " .

![](https://files.readme.io/77cde2e-steps.png)

![](https://files.readme.io/206d2fe-STEPS2.png)

***

## Q: How to get single token transactions?

### 🅰️ :

To get single token transactions, we have two options :   

```
A. Using register report ( Limited to specific wallet )
```

```
B. Using Export Report
```

Using Register Report :   

1. Go to Bitwave.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3cda81a-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. Go to Transactions.

![](https://files.readme.io/872c527-Screenshot4.png)

2. Click Register.

![](https://files.readme.io/3d5ed45-Screenshot5.png)

3. Enter wallet name, Dates and Token Ticker.

![](https://files.readme.io/3fb2af4-Screenshot_2024-05-18_021612.png)

4. Hit load Register.

***

### Q. Are trade transactions shown in the Journal Entry Report

## 🅰️:

Trade transactions are not reflected in the journal entry report because trades reflect the exchange of one digital asset for another. In other words your Digital asset account has an “inflow” and an immediate “outflow” of the same amount. This in and out is often referred to as moving assets from your left pocket to your right pocket. The net impact of a JE would be 0 and so no journal entry is created.

***

## Q: How can I check which inventory view  versions I am currently using in Bitwave?

### :a::

To check Inventory view versions, follow the steps below:

1. Go to inventory views.
2. Click on settings.
3. Here you can see all the details of inventory view that is created with the version

***

## Q : Where can I find the option to add a new view on the Inventory Views page?

### :a:: To add a new view, simple click on create view and follow the steps accordingly.

![](https://files.readme.io/f028798-inventory_views.png)

***

## Q : How do I determine which view I am currently using in the Inventory section?

### :a:: The black box on the name of the view represents the currently used inventory view.

![](https://files.readme.io/1846817-image.png)

***

## Q : How to Filter by Month in the Gain/Loss Inventory View

### :a::

1. Ensure Inventory View is Updated:

- Navigate to the Inventory section.
  - Click on "Update Now" located in the top-left corner to ensure your inventory view reflects the latest data.

2. Download Actions Report:

- Go to the Inventory section.
  - Click on "Actions".
    - Add your preferred date range or submit date filters to specify the time period you want to analyze.  
      Once filtered, click on "Download Actions" to export the report as a CSV file.  
      Perform Pivot Table Analysis:
      - Open the downloaded CSV file using a spreadsheet application such as Excel or Google Sheets.  
        Create a pivot table to summarize the data by month or any other desired criteria.
        - Utilize the pivot table to analyze gain/loss data specifically for each month or the selected time period.

## Q: What timestamp will be used when combining multiple transactions that occur at different times?

### :a::

When you combine a series of transactions in Bitwave, the resulting combined transaction will use the earliest timestamp of any of the original transactions that were combined.

## Q: I am getting negative coin balance errors in inventory views, what should i do?

### :a: :

Here are the steps to follow when you encounter a negative coin balance error in your inventory views dashboard:

1. Ensure that your Bitwave token balances match your on-chain balances.
2. Verify that no important transactions are ignored in your Bitwave instance. ( Set the transactions filter to "Ignored" to check all ignored transactions )
3. Try uncategorizing and re-categorizing the specific transaction showing a negative coin balance.  
   Note: Please update your inventory views after performing any actions (categorizing, resyncing) related to transactions in Inventory Views.
4. If the negative amounts are less than $0.01 (likely due to rounding errors), you can resolve this by downloading the actions report and sorting the asset balance column from smallest to largest. Then, create a reversal transaction for the same amount 1-2 minutes before the original transaction. This will effectively eliminate the negative balance caused by rounding errors.

**Note:** Please update your inventory views after performing any actions (categorizing, resyncing) related to transactions in Inventory Views.

## Q: Does BW associate lots with wallet ID's (prior to 1/1/25)?

### :a: :

Yes bitwave consider lots as wallet id's if the Wallet Level Inventory (WLI)is turned on for your org. The transfer from wallet A to wallet B is also transferring the original lots if WLI is turned on. If you don't have WLI turned on and this is more about moving from universal inventory to WLI then that is a little more nuanced. However, engineering is currently working for a solution to be ready by end of November for this situation  
​  
Here is a documentation on wallet level inventories - <https://docs.bitwave.io/docs/setup-inventory-groups#method-1-wli-wallet-level-inventories>

<br />

<br />

## Q: I have completed all the necessary steps for creating reallocation views, but I am still getting error while running reallocation for my organization. What course of action should I take?

### :a: :

If you are getting errors while running reallocation, please make sure that

1. The date you are running reallocation for, all transactions should be categorized till that date.
2. Your Standard and Balance only views should be updated.
3. Your Standard and Balance only view should have **NO ERRORS**.

If you are still getting errors while confirming all the steps are performed thoroughly, please reach out to us via in app chat support with following details

**Org Name  
Org ID  
Reallocation Running date**

***

<br />

## Q: Actions report is not showing all the transactions which are in the organization ?

### :a: :

You can update the Inventory view to get all the transactions in the report and check that the transactions are not ignored because the Inventory views does not include the Ignored transactions.

***

<br />

## Q: How many Inventory views can be created as a default?

### :a: :

As a default you can create up to 3 inventory views in the organisation. If you want to create more than 3 inventory views then you can reach out to us via in app chat support with following details

1. Org Name
2. Org ID

***

<br />

## Q: Is there an option for multiple tax lots while importing transactions via the import template, as it currently only has one tax lot option?

### :a: :

Yes, you can split the deposits into individual tax lots and import them manually. You can also assign a cost basis to each lot and import them categorized.

***

<br />

## Q: How does the Spec ID Inventory view handle or treat wallets in Bitwave?

### :a: :

<br />

If you configure the priority list as shown in the screenshot below, Bitwave will operate as follows:

1. It first searches for lots that would result in a short-term loss. If there are any, it selects the one with the largest loss.
2. If no short-term losses are found, Bitwave will search for lots that would trigger a long-term loss and pick the one with the largest loss.
3. If there are no short-term or long-term losses, Bitwave looks for a lot that would result in a short-term gain and selects the one with the smallest gain.
4. If there are no losses or short-term gains, Bitwave will choose the lot that generates the smallest long-term gain.

This is how the Spec ID prioritization works in Bitwave.

![](https://files.readme.io/2d4832b265fe03f5d972d364d3df19ad5b047a05b6ae719057d730e69826f221-Screenshot_at_Feb_20_00-16-46.png)

<br />

***

<br />

## Q: Does my Cost Basis in the Inventory Views include USD?

### :a: :

The Inventory Views and Actions Report do not track USD transactions. However, we will push USD transaction journal entries into the ERP.

***

<br />

## Q: What should I do about a negative coin balance alert that doesn’t appear to be real?

:a::

If the alert is showing a negative balance that doesn’t reflect actual holdings, it could be due to data discrepancies or sync issues. Support may need access to your organization to investigate and Always ensure your Inventory View is updated.

***

<br />

## Q: Why do I have negative coin balances?

:a::

Negative balances usually appear when not all transactions have been categorized. Finish categorizing all transactions, update your Inventory Views, and then check if the negative balances persist.

***

<br />

## Q: How do I update Inventory Views in Bitwave?

:a::

Click the "Update" button in your Inventory View. Then check the “Updates” tab after your reports to confirm the refresh has processed.

***

<br />

## Q: Why am I seeing negative balances in the Reallocation inventory view?

:a::

Negative balances may appear if transfers between wallets aren't properly registered in your inventory. To resolve this, ensure both inventory views are updated. If the issue persists, our team can investigate further just provide your organization details and grant temporary admin access if needed.

***

<br />

## Q: I have changed my standard view's picking strategy and now I have to do reallocation. What should be my next steps here?

:a::

First, we may need to create a new view with the new picking strategy. After it is done, we may need to use the last updated run ID of our previously ran update of the old view and use it as a reference run ID and the reference run end date to update the new view. After it is done, we can then proceed for the realllcoation by creating the balance only view and using the new universal view as our lots report view.

***

<br />

## Q:  Why won’t my inventory update after fixing a transaction or changing settings?

:a::

Inventory updates can sometimes be delayed due to backend syncing issues or pending categorization. If your engine version is outdated or a transaction is blocking processing, this could be the cause. We recommend reaching out to support—our team may need to escalate the issue internally to ensure your inventory reflects the most current data.

***

## Q: What should I do if I see errors when I load inventory views?

:a::

"If you are getting errors when you run any date, this may have happened due to some calculation errors. You can download the actions report to check with the errors and rectify them manually in the UI.  
NOTE : Make sure to update the view before and after rectifying the issue"

***

## Q: Why does my Inventory Actions Report show uncategorized transactions when the Categorize screen shows zero?

:a::

This mismatch can occur if your inventory view is not up to date. Please update your inventory view to the latest date. If that doesn't resolve the issue, identify and recategorize any specific transactions that may be causing the sync problem.

***

## Q: Why is my Inventory Report showing as blank?

:a::

" If you're seeing blank results when running an Inventory Report, please double-check the date parameters and view settings. If the issue continues, contact us and consider adding a Bitwave support team member as an admin temporarily so we can investigate directly. Instructions to add a user are available here.

***

## Q: How can I find transactions that are marked as "Incomplete" in the Actions Report?

:a::

 You can identify incomplete transactions by reviewing the Actions Report. Look for entries marked as "Incomplete Transaction." Once identified, categorize them accordingly, then refresh your Inventory view to reflect the changes.

***

## Q:  What should I do if I can't download a report from the Dashboard view?

:a::

If clicking the download button doesn't work, please try refreshing the page or accessing the report from a different browser. You can also contact our support team with the view and date range details, and we’ll assist in retrieving the report for you.

***

## Q: Why is there a discrepancy in the Unrealized Gain/Loss amount between the Dashboard Inventory view and the Cost Basis Roll Forward report?

:a::

Discrepancies in Unrealized Gain/Loss figures can occur due to differences in engine versions or pricing inputs used in various reports. In one case, an older Inventory view used an outdated engine, while the newer engine (applied in a recreated view) reflected updated calculations. Specific token pricing discrepancies—like AAVE-USDT using $0.9991 instead of $1—can also affect the reported values. We recommend checking if your inventory view is using the latest engine version. If needed, our team can assist in creating a new view for accurate comparisons.

***

## Q:  I’m having issues with period-end reconciliations and the Inventory G/L view including ignored transactions. How can I fix this?

:a::

Suppose you're good till 11/30/2024 and you have no variances in novermber month. Right after you move to december, you have variances in your period end reconciliati0on. You may need to divide the dates ( 1-15 december and 16-31st december ). Lets suppose, there is variance in 16-31st, you may then divide the dates again and do the same.Once you find the date ( lets say 19th december) , you can go to the transactions UI Page and check if the transactions are properly categorised, check if any important txn is ignored or no. If still the issue persists, you can reach out to our team via in app chat.

***

## Q:  Why is my Inventory G/L view showing transactions that I’ve marked as ignored?

:a::

"This can happen due to a syncing or filter issue. Please share the list of ignored transactions that are still appearing in the Inventory G/L view so our team can investigate and resolve the discrepancy.  
NOTE : Please make sure your inventory views are updated right after you ignore any transaction or perform any action in transactions UI Page.

***

## Q: Why does my Actions Report differ from my Inventory Results Report?

:a::

 Discrepancies between reports can happen due to syncing issues or underlying transaction data conflicts. We recommend refreshing both reports first. If the discrepancy persists, reach out to support—we’ll investigate and reconcile the inconsistencies.

***

## Q: What should I do if I see negative coin balances in my inventory view?

:a::

Negative balances often indicate missing or incorrect transaction data (such as a missing deposit). Please double-check your transactions, especially in wallets showing negative values, and contact support so we can help identify and correct the issue.

***

## Q: Can I close out the year with negative balances, and will they be corrected in the next year?

:a::

While it is technically possible to close the year with negative balances, it’s best to correct those discrepancies before year-end. If you must proceed, we can help you reconcile and adjust those entries in the following year.

***

## Q: After changing from FIFO to LIFO, Can I still get a Gain/Loss report in the same format we used in previous years using LIFO?

:a::

Yes, you can generate a similar report using the Actions Report within the Inventory Views. If you've previously used the FIFO method, ensure that the Inventory View is updated to use LIFO before running the report. This will give you realized/unrealized gains/losses and balances consistent with prior years.

***

## Q: What report should I use to get cost basis and gain/loss information?

:a::

You should use the Cost Basis Roll Forward Report in the Inventory Views to access cost basis and gain/loss numbers. This report provides the detailed tracking you need.

***

## Q:  I’m seeing discrepancies between past reports and the new Inventory Views report. How can I fix this?

:a::

If the Inventory Views report doesn’t match your older records, please ensure you're selecting the correct Inventory View and also the view should be recently updated. For accuracy, compare your previous Actions Files with the Actions Report in Inventory Views. Our team can help review and align these reports if needed.

***

## Q: Why is the Actions report not loading? It just shows a spinning wheel.

:a::

 This issue may be caused by a temporary bug. If you're seeing the loading spinner indefinitely, please reach out to our support team with your Organization Name, Organization ID, Inventory view ID, and a brief description of the problem. Our engineering team actively monitors and addresses such issues, and we'll notify you as soon as it’s resolved.

***

## Q: Does the engine version (e.g., v1.2) affect inventory updates?

:a::

Generally, the engine version shouldn't impact your ability to update inventory. However, if issues arise, we recommend contacting support so we can verify the setup and escalate if needed.

***

## Q: Does marking a transaction as ignored affect the inventory value report?

:a::

Yes, if you ignore an important transaction and update the view, it will affect the reporting in terms of balances and calculating gains and losses as ignored transactions are not included in the inventory views calculations

***

## Q: I’m seeing an error when running a wallet-by-wallet inventory report: “Unable to map transaction… too many or too few wallets.” What does this mean?

:a::

This error typically occurs when Bitwave cannot clearly associate a transaction with a specific wallet. Try unreconciling, uncategorizing, and then recategorizing the transaction. After that, rerun the inventory view. If the issue persists, please contact support with the transaction ID so we can assist.

***
