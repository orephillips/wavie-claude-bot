---
title: "❓FAQs"
slug: "frequently-asked-questions-9"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:12:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 30 2025 18:39:36 GMT+0000 (Coordinated Universal Time)"
---
# General

***

## Q: How to calculate impairment?

### 🅰️

See Record Impairment and Mark-to-Market Adjustments here --> <https://docs.bitwave.io/docs/record-impairment-and-mark-to-market-adjustments>

***

## Q: How do I get certified in Bitwave?

### :a::

If you're interested in getting certified in Bitwave, we've got you covered! 🚀 Check out this link for all the details:

<https://university.bitwave.io/courses/bitwave-certification>

***

## Q: How to get Organization Name and Organization ID?

### :a::

- Navigate to Administration
- Then go to Organization.
- You'll find the organization name and ID
- Double click to Highlight

***

## Q: How to get a trace ID?

### :a:﻿:﻿

1. Log in to Bitwave.
2. Right-click on the screen and select "Inspect" at the bottom of the list.
3. Once the dialog box appears , go to the "Network" tab.
4. Clear the history (on the top left of the dialog box) and refresh the page.
5. After the page reloads, click on the most recent GraphQL entry OR the entry that is showing an error (usually a red entry)
6. Go to "Headers" and copy the value next to "X-Cloud-Trace-Context", here you have the trace ID.

***

## Q: How to enable Auth sign in?

### :a:﻿:

1. If you're already signed into Bitwave, log out.
2. Double-click on the blank space located just below the last option, as shown in the provided picture

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8031134-newest.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "50% ",
      "border": true
    }
  ]
}
[/block]


3. After double-clicking, you'll see the Bitwave Auth login option.
4. Sign into your Bitwave account using the available fields.
5. Once in Bitwave Auth, select your preferred login method and click "Next.

***

## Q: How does my organization get added to the Bitwave Marketplace?

### :a:﻿:

Please view our [Bitwave Partner Listing Process Guide](https://docs.bitwave.io/docs/join-marketplace)to join our Marketplace.

## Q: How to get the network of any token?

### :a:﻿:

1. Every token on a different network has a unique contract address.

2. Once you the search the token on Cryptocompare and Coingecko scroll down a little below and on the left side you will see a row of all the contracts where there are contract addresses mentioned of all supported networks.

## Q: How to enable SSO on Bitwave Web App for local dev (Okta)?

### 🅰️

Create a free account on JumpCloud (cloud based active directory)

1. Follow their docs on Setting up SAML-based SSO with an Application to create your organization/application
2. Select Slack from the list of applications
3. Once the application is activate, click on it to open the details
4. go to the SSO tab and locate the following values

a. IDP URL

b. IDP Certificate (download it)

5. go to the User Groups tab and check the All Users box, then click save
6. create a new user manually

 a. In the user’s details page, click on the User Groups tab 

b. check the All Users box, then click save user

**On the Bitwave Web App:**

1. First login with any other method (gmail, or email)
2. Go to Organization from the left navigation menu
3. Select Security tab from the top navigation menu
4. Check the Use SSO box 
5. Fill in the remaining field as follows:

a. IDP Issuer: Jumpcloud

b. IDP Sign On Url: its the IDP URL value from the JumpCloud SSO tab 

c. IDP Certificate: the contents of the downloaded certificate.pem

6. In Security → Users tab, for each user provide asserted identity. It should exactly match with the SSO provider.

**Okta Setup**

Single sign on URL: <https://api.bitwave.io/saml>

Audience URI (SP Entity ID): <https://api.bitwave.io/metadata.xml>

SSO for onelogin:

Audience: <https://api.bitwave.io/metadata.xml>

ACS (Consumer) URL Validator\*: ^https\:\/\/api\.bitwave\.io\/saml\$

ACS (Consumer) URL\*: <https://api.bitwave.io/saml>

\*Note: the response onelogin sends is not as par SAML2.0 standard

New Auth:  
SSO: <https://auth.bitwave.io/api/saml>

Audience URL: <https://auth.bitwave.io/api/saml/metadata.xml>

***

## Q: How to reconcile trades if the capitalize fees option is turned on ?

### :a:﻿:

Trades show up in the Trading screen when the org configuration is capitalize fees.These trades won't show up in Reconcile tab. You need to accept these trades to move them from categorized to reconciled status.

***

## Q: How to check whether a token is spam or not?

### :a:

1. Go to <https://address-svc-utyjy373hq-uc.a.run.app/api-docs/#/Symbols/GetSymbol>
2. This will open the symbols column where you can search for the token.
3. Click on Try it Out.
4. Enter the token ticker, and hit Execute.
5. A dialogue box will appear will all the information of the token you searched.
6. If that token has spam score, this means that that token is spam.

***

## Q: How do I revoke or change the role of a user access in the organization?

### :a:

- Navigate to the Administration section in the left menu of your Bitwave dashboard
- Go to users.
- First, find the user you wish to revoke access for, click on the circular icon and then click 'revoke' to remove the user from the organization
- Click on the pencil icon, which will open up the user roles configuration for that user. Select the role that applies to the user and click save."

***

## Q: How do I revoke access or change the role of a user in the organization?

### 🅰️

In order to revoke the user access in the organization you can follow the given steps

1. Login to bitwave
2. Go to security and select 'Users' from there 
3. Now click on the clock icon in front of the user you want to revoke the access for.  

In order to change the user role in the organization you can follow the given steps

1. Login to bitwave
2. Go to security and select 'Users' from there 
3. Now click on the pencil icon in front of the user you want to change the role for.

***

## Q: How do I change my timezone in Bitwave?

### :a:﻿:

To change the timezone in your Bitwave instance, please reach out to Bitwave support in our in-app chat.

> NOTE: Changing the timezone of your Bitwave instance will impact values in certain Bitwave reports, given that a change in timezone can change the date on which a transaction occurs.
>
> NOTE: Under Administration > Organizations, there is a checkbox labeled "Use Timezone For Display". By default, Bitwave shows transactions in your computer's local timezone, while it uses your Bitwave instance timezone for reporting purposes. Checking this box will ensure all transactions in Bitwave are displayed in your Bitwave instance timezone. This option does not affect Bitwave reports.

***

## Q: How do I update my payment method?

### 🅰️

In order to update your payment method, you can reach out to our support team via the in-app chat support system by clicking on the message icon located at the bottom right of your bitwave app. You can also mail us on [support@bitwave.io](mailto:support@bitwave.io)

***

## Q: How do I request a new feature or request improvements to an existing feature?

### 🅰️

You can connect with us regarding that via our in app chat support which you can find on lower right corner or you can get in touch with you allocated CSO.

***

## Q : How to whitelist the NFT contract address in the organization?

### 🅰️

To whitelist a contract address in your Bitwave instance, follow the steps below :- 

1. Click on administration
2. Click on token filtering 
3. Add contract address in the box
4. Select network ID
5. Click check details
6. Hit whitelist address

![](https://files.readme.io/582833b-image.png)

***

## Q: Does Bitwave have the capability to flag tokens as spam tokens so that they auto ignore?

### :a::

Unfortunately we don't have the capability to flag tokens as spam tokens.

## Q: How to change the currency for org in Bitwave?

### 🅰️:

Client cannot change the currency of the org in Bitwave by themselves, To change the currency client has to contact Bitwave's in-app chat support.

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q: Can we tag certain withdrawals to be non taxable?

### 🅰️:

You have the option to Force a Zero Gain Loss on outflows in Bitwave. Select this box in the outflow (as shown in screenshot) and this will remove the asset at its original cost basis without creating any gain or loss on the actions report.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a1a19c76e6c088b4041f69ecadc318e381168af51b8816afde0463104a882aff-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


If a transaction has already been reconciled, you just need to unreconcile , uncategorize , check the box, recategorize and then update the inventory view

***

## Q: What would be the impacted if we do a full pricing cache clearing in an org, if  there is no impairement in inventory views?

:a:: 

If impairment is not turned on, then full pricing cache in an org will change following things:

1.Uncategorized transactions pricing  
2 Balance report FMV  
3.Inventory views report FMV and unrealized gain.

***

***

## Q: What is the impact if we do a full pricing cache clearing in an org?

:a::

The most current pricing we have in our system will be applied to **ALL reports and ALL UNCATEGORIZED transactions.**This should not be an issue for the uncategorized transactions

but if they you will run balance reports or inventory view reports in the past that rely on FMV pricing (such as inventory views dashboard download, Impairment on actions report, and unrealized gain/loss values on cost basis rollforward), those OLD reports you ran had the OLD pricing….and when you will re-run those reports for the same days, you will get different results because the NEW reports will reflect the NEW pricing

Transactions that are already categorized will not be impacted.

In other words,  
Uncategorized txns will get the new price, and when you will run balance reports or inventory view report on old historical dates…the new reports may have different FMV and unrealized gain/loss vs the old reports you ran for those days

***

<br />

## Q: How do I give Bitwave support temporary admin access to my organization?

:a::

You can add a Bitwave team member as an admin using our User Roles feature. Follow the steps in the Bitwave User Roles Guide. Once added, you can revoke access anytime after the issue is resolved.

***

<br />

## Q: I’m trying to assign an admin role to a support team member, but the role dropdown is blank. What can I do?

:a::

 If the role dropdown is blank when adding a new user, try refreshing your browser or logging out and back in. If the problem continues, reach out to our support team for assistance.

***

<br />

## Q: How can I reactivate my organization’s Bitwave account?

:a::

If your account has been deactivated, it may be due to a finance hold, such as an outstanding inquiry or unpaid invoice. To resolve this, our billing team will reach out to assist you. If you'd like to expedite the process, please share the preferred email address for contact. We're committed to resolving these issues quickly so your team can resume using Bitwave without delay.

***

<br />

## Q: Why does Bitwave keep redirecting me to the home page while I'm typing?

:a::

This is a known issue our team is investigating. If this happens frequently, try clearing your browser cache or using an alternate browser, and let our support team know for further troubleshooting.

***

<br />

## Q: Where can I find how much we’re paying for this tool and our payment method?

:a::

To access details about your billing and payment method, please contact our support team with your billing email. We’ll connect you with our accounting team, who can provide your invoicing and payment information directly.

***

<br />

## Q: How can I update or verify the payment method for our account?

:a::

If you need to confirm or update your payment method, simply contact our support team. We’ll coordinate with our accounting department to provide the necessary details or help make any changes.

***

## Q: Can I receive billing updates or invoices by email?

:a::

Yes! Just provide your preferred contact email, and we’ll ensure all billing-related updates and invoices are sent directly to your inbox.

***

## Q: How can I confirm if a client is up to date on their Bitwave invoice?

:a::

Please provide the organization name and billing email. Our accounting team will reach out with the invoice status directly.

***

## Q: What should I do if I'm trying to add a user but see an “Org Access is Restricted” message?

:a::

This message typically appears when your access to the organization has been restricted. Please check if any other members with admin privileges are available to restore access. If you're the only member or unsure who restricted access, contact our support team with your organization name and ID so we can help resolve the issue.

***

## Q: How can I regain access to my organization if I’m the only member and I’ve been locked out?

:a::

If you’re the only member and can’t access your organization, please reach out to us directly. We’ll need your organization name, organization ID, and your email address. Once we verify your details, we can help reinstate your access.

***

## Q: What happens if no one else has admin access to the organization?

:a::

If there are no other admins or users with access to the organization, contact our support team immediately. We’ll verify your identity and help restore administrative access so you can manage your team and organization settings again.

***

## Q: Why does my paid organization account still show as a trial?

:a::

If your organization has paid but is still displaying as a trial account, it could be a billing or provisioning issue. Please contact our support team with your organization ID so we can verify your subscription status and resolve the issue.
