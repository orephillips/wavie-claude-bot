---
title: "In-App Support"
slug: "in-app-support"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:49:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:04:02 GMT+0000 (Coordinated Universal Time)"
---
<ul>
<li>Go to <a href="https://app.bitwave.io">https://app.bitwave.io</a></li>
<li>Log in to your account</li>
<li>Go to the bottom right of the screen and click on the in-app support function</li>
</ul>

![](https://files.readme.io/7391a98-Screenshot_2024-03-07_at_3.07.45_PM.png)

***

***

***

***
