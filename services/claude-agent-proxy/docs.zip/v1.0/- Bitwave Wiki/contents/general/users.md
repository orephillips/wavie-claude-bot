---
title: "Users"
slug: "users"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:12:23 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:16:10 GMT+0000 (Coordinated Universal Time)"
---
Here's a guide on adding users, setting up roles, and revoking  
access in Bitwave.

<br>

### Defining the User Roles:

1. Admin:
   1. Menu Detail: All menus, including admin and security

2. Advanced User:
   1. Menu Detail: Home, Wallets, DeFi, Transactions,. Trading, Accounting, Customers, Vendors, Taxes, Reports, Company, Tools, Admin

3. Standard User:
   1. Menu Detail: Home, Wallets, DeFi, Transactions, Trading, Accounting, Customers, Vendors, Company, Tools.

4. Read-Only:
   1. Menu Detail: Home, Wallets, Taxes, Reports, Pricing
   2. Note: This role does not have ability to modify transactions.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/89b39a2-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


1. **Click "Security".**

   [block:image]{"images":[{"image":["https://files.readme.io/3fe2837-image.png",null,""],"align":"center","border":true}]}[/block]
2. **Click ADD USER.**

   [block:image]{"images":[{"image":["https://files.readme.io/541715a-image.png",null,""],"align":"center","border":true}]}[/block]
3. **Add user name.**

   [block:image]{"images":[{"image":["https://files.readme.io/1210a29-image.png",null,""],"align":"center","border":true}]}[/block]
4. **Add user Email.**

   [block:image]{"images":[{"image":["https://files.readme.io/69613f6-image.png",null,""],"align":"center","border":true}]}[/block]
5. **Click to assign the required role.**

   [block:image]{"images":[{"image":["https://files.readme.io/9bc6dbd-image.png",null,""],"align":"center","border":true}]}[/block]
6. **Select the role that you find appropriate.**

   ![](https://files.readme.io/071ac41-image.png)
7. **Click "Save".**

   [block:image]{"images":[{"image":["https://files.readme.io/acc02a2-image.png",null,""],"align":"center","border":true}]}[/block]

![](https://files.readme.io/59e1856-image.png)

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/889b5f4-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


9. **To revoke a user's access, click here.**

   [block:image]{"images":[{"image":["https://files.readme.io/561121b-image.png",null,""],"align":"center","border":true}]}[/block]
10. **Click "REVOKE".**

<br>

<br>

<br>

## Advanced RBAC (Roles Based Access Controls):

- Under the Bitwave Enterprise Edition users also have the capability to create and provision custom roles with bespoke permissions (read, write) and access to different menu items.

***

***

***

***
