---
title: "Bitwave Partner Listing Process Guide"
slug: "join-marketplace"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 16:46:01 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 22:28:48 GMT+0000 (Coordinated Universal Time)"
---
## Introduction

Welcome to the Bitwave Partner Marketplace Listing Process Guide. This document outlines the steps and requirements for partners seeking to be listed on our client-facing marketplace. The goal is to streamline the listing process and ensure all necessary information is provided to facilitate a successful partnership.

### Step-by-Step Process

1. **Initial Contact**
   - **Reach Out to the Bitwave Team**
     - Clients can contact their Bitwave Account Executive for Partnership inquiries.
   - **Complete the Partner Listing Form**
     - Interested partners can complete this **[Partner Listing Form](https://docs.google.com/forms/d/e/1FAIpQLScWoNB9GUVMvjOYxZoAHGavZnMkKunVwph4s8BKfWlCPQl60Q/viewform)**.
     - Ensure all required fields are accurately filled out to avoid delays.
     - Link: <https://forms.gle/8u1NjG8LLNnFfhwdA>
2. **Information Submission**
   - The business development manager will review the provided information upon form submission.
   - Required Information:
     - Company Name
     - Contact Information (Name, Email, Phone)
     - Brief Description of Services/Products
     - Additional Business Development Inquiries
3. **Initial Review and Outreach**
   - The business development and/or sales manager will contact you within 5 business days to confirm receipt of the form and schedule a follow-up meeting if Bitwave is interested in a collaboration.
4. **Partner Strategy Roadmap Meeting**
   - In this meeting, we will discuss:
     - **Account Mapping Tool:**
       - Align partnership priorities and verticals of interest.
       - Institutions and enterprises of mutual interest.
     - **Use Cases:**
       - Identify real use cases that can showcase the partnership's value.
5. **Development of Co-Marketing and Case Study Materials**
   - **Prerequisite:**
     - We must have existing clients or have identified one or two proven use cases.
   - **Activities:**
     - Co-marketing initiatives.
     - Development of case study materials to highlight successful collaborations.

<br />

### Contact Information

Please complete the [form](https://forms.gle/8u1NjG8LLNnFfhwdA) or contact your account manager with any questions or need assistance.

### Conclusion

We look forward to collaborating and showcasing your solutions on the Bitwave Partner Marketplace. We aim to create a smooth and efficient pathway to a successful partnership by following this process.
