---
title: "Accepting Bitwave Invite!"
slug: "accepting-bitwave-invite"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:08:52 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:09:41 GMT+0000 (Coordinated Universal Time)"
---
1. You will receive an invitation to join Bitwave from [info@bitwave.io](mailto:info@bitwave.io).
2. Click "Go to Bitwave".

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e8ffba7-Screenshot_2024-02-22_231315.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. Click Sign in with either Email, Google ,Xero, or SSO.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/524d8db-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Once signed in, you will receive a notification to join your organization.  
   Click the green check mark to accept.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3bb6447-Screenshot_2024-02-22_231501.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. To access and navigate through all the organizations you have been invited to, click here.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/074084c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Welcome to your Organization !!!

***

***

***

***
