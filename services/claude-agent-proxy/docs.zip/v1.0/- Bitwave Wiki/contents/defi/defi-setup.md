---
title: "DeFi Setup"
slug: "defi-setup"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:56:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Apr 04 2025 13:43:01 GMT+0000 (Coordinated Universal Time)"
---
## How Do I create a DeFi Wallet in Bitwave?

<br />

Follow these steps to set up your DeFi wallet:

1. Go to Wallets & Connections – Navigate to the "Wallets" section. (Screenshot 1)
2. Click on "Create Wallet" – Start the wallet creation process.
3. Select Wallet Type – Choose the appropriate wallet type.  (Screenshot 2)
4. Choose the "Other" Category – This option is for manually adding a wallet.
5. Select the DeFi Protocol – Under the DeFi dropdown, choose the relevant option based on the blockchain protocol you are using.
6. Enter Wallet Details:   (Screenshot 3)  
   A. Name – Assign a unique name to your wallet (e.g., "Sample Wallet").  
   B. Blockchain Network – Select the blockchain network (e.g., Bitcoin, Ethereum).  
   C. Wallet Address – Provide the wallet address used for DeFi interactions.  
   D. DeFi Contract Address – Enter the contract address for the DeFi protocol.  
   E. (Optional) Token ID – If applicable, enter the token ID for the wallet.  
   F. (Optional) Group ID – Search and select a group ID if needed.
7. Finalize & Add Wallet – Review all details and click "Add Wallet(s)" to complete the setup.

![](https://files.readme.io/bb5b8d0cff035d9abdec157d9d7226f88a0d788af15c8c18adc49e72056eb968-Screenshot_1.png)

![](https://files.readme.io/77d4cb24256d78fbd4de251ec73f4711eb24974e9e91dfa65aec3649ac0563bb-Screenshot_2.png)

![](https://files.readme.io/7fc3cbd0773acc092a8e24d6c2805fade8fcde5a86124368bac5711fe1c47453-Screenshot_3.png)
