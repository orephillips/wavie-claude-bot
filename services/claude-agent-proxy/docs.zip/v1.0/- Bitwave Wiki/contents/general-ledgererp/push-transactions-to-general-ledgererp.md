---
title: "Push Transactions to General Ledger/ERP"
slug: "push-transactions-to-general-ledgererp"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:43:31 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 01:50:17 GMT+0000 (Coordinated Universal Time)"
---
1. Once your categorizations have been completed, in order to reconcile and sync transactions, go to the left menu → accounting → reconcile.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6962cfe-Reconcile__Sync_2.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. Pro tip: Review the Transaction UI summary of transactions to make sure you have zero transactions left to categorize. If all transactions are listed under “To Be Reconciled,” you are ready to move into the reconciliation process. If you have remaining transactions left in the “Needs Categorization” summary, resolve those first before moving onto the next step.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b2a7dd1-Reconcile__Sync_2a.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. Review the “Accounting Details” column for the contact, general ledger mapping, and amount on the categorized transactions for reasonableness. When you are ready to sync the data into your GL (ERP) software, you can individually select each transaction by choosing the check box on the left side and selecting the green “Reconcile Selected Transaction” button on the upper right. Once reconciled and synced you are able to view the transactions in your GL (ERP) system.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/35ae172-Reconcile__Sync_3.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. You may also select multiple transactions at once using the checkbox at the top of the column. You have the option to expand up to 100 transactions on the page.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/bfedc48-Reconcile__Sync_4.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. If you need to reconcile more than 100 transactions at once, an alternative option is to use System Jobs. Locate Administration > System Jobs.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/232ae68-Reconcile__Sync_5.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Once you are at System Jobs, using the “Create Job” button, you can mass reconcile transactions by wallet by choosing  
   a. **Action:** Reconcile Transactions  
   b. **Wallet:** Select up to 10 wallets  
   c. **Start Date:** Select the first date you would like the range to apply to.  
   d. **End Date:** Select the last date you would like the range to apply to.  
   e. Select “RUN”

![](https://files.readme.io/dff4228-Reconcile__Sync_6f.png)

7. Once you select RUN, the status will show a loading icon.

![](https://files.readme.io/8e8c71d-image.png)

8. Your System Job is completed when the Status column indicates a green check mark.

![](https://files.readme.io/b917de9-image.png)

9. Important Note: Unreconciling a transaction in Bitwave does NOT un-reconcile the corresponding transaction in your GL (ERP) system, it will simply create an out of sync situation between Bitwave and your ERP system.
