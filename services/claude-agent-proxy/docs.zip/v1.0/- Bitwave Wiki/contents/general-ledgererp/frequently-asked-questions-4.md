---
title: "❓FAQs"
slug: "frequently-asked-questions-4"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:48:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 15:07:12 GMT+0000 (Coordinated Universal Time)"
---
# Accounting & General Ledger

***

## Q: How do I reconcile trades?

### :a::

Trades show up in the Trading screen after they are categorized and ready to be reconciled.These trades won't show up in Reconcile tab. You need to accept these trades to move them from categorized to reconciled status.

## Q: How often does the ERP sync to Bitwave?

### :a::

The sync cadence between your ERP and Bitwave differs based on the system:

- Netsuite - Data syncs every 15-20 minutes.
- Sage - Data syncs once a day.
- QBO - Data syncs every 12 hours.

Alternatively, you may manually sync your data between the ERP and Bitwave to bypass the default sync status.

## Q: How do I reconcile my Rolled up Journal Entry Report to my Actions report

### :a::

Step 1: Obtain your Rolled up Journal Entry Report for the period in question

Step 2: Obtain your Actions report for the period in question

Step 3: Perform the reconciliation

- 1. First To reconcile the Rolled Up Journal Entry Debits:

     - Take the Actions Report and filter the "action" column  for all "buy"
     - In addition to the filter above filter the "isTrade" column for FALSE  (meaning exclude all TRUE)
     - Sum up the "carryingvalue" column
     - The result should EXACTLY match the sum of debits from the JE Report or Rolled up JE Report
     - See the image below for the filtered columns
     - ![](https://files.readme.io/4a50c59-image.png)

       <br />

  2. Second to reconciled the Rolled Up  Journal Entry Credits:  
         - Take the Actions Report and filter the "action" column  for all "sell"  
     ,
- In addition to the filter above filter the "isTrade" column for FALSE    (meaning exclude all TRUE)

  - Sum up the "fairmarketvalueDisposed" column
  - The result should EXACTLY match the sum of debits from the JE Report or Rolled up JE Report
    - See the image below for filtered columns
  - ![](https://files.readme.io/cd60fd8-image.png)

    ```
     <br />
    ```

    Alternatively you can actually run the detailed JE report and compare LINE by LINE to the actions report.

Bitwave does not produce a journal entry for trade transactions.  Instead the cost basis change from the trade is recorded via the realized gain/loss journal entry, which is a debit/credit to Realized Gain/Loss and offsetting debit/credit to the digital asset GL account.  For more on recording realized gain/loss journal entries, see <https://docs.bitwave.io/docs/record-realized-gainloss>.

## Q: Does Bitwave produce a journal entry for trades?

### :a::

Bitwave does not produce a journal entry for trade transactions.  Instead the cost basis change from the trade is recorded via the realized gain/loss journal entry, which is a debit/credit to Realized Gain/Loss and offsetting debit/credit to the digital asset GL account.  For more on recording realized gain/loss journal entries, see <https://docs.bitwave.io/docs/record-realized-gainloss>.

## Q: How to lock / unlock a specific period of transactions?

### :a:: Use our [Locking Period Guide HERE](https://docs.bitwave.io/docs/locking-periods)

***

## Q: How to account for staking rewards as created property?

### :a::

A tax professional may take the position that staking rewards are created property. This should be accounted in bitwave by receiving the staking rewards at zero cost in a rewards wallet. For more information on how to setup a wallet for staking rewards see, <https://docs.bitwave.io/docs/how-do-i-account-for-tokens-staked-on-an-exchange>

\*\*Note that Wallet Level Inventories will be required in order to track the staked tokens at their original cost basis and the created property staking rewards at zero costs. Additional without separate inventories, the staked tokens will be pickable for disposals. For more information on how to setup Wallet Level Inventory groups for staked units and rewards see, <https://docs.bitwave.io/edit/recognizing-gainloss-for-unintended-stake>

***

## Q: New GL in QuickBooks is not showing in Bitwave?

:a:  In the left-hand corner of your Bitwave app,

1. Navigate to Administration.
2. Go to Accounting Connections.
3. Click on the “Sync” to update the new GL in Bitwave.
4. It will update the new GL into Bitwave.

***

## Q: We did modification in our ERP ( Contacts, categories ( GL accounts ), Invoices, etc ) and I can't see it in Bitwave, what should i do?

### :a::

Under Administration > Accounting Connections. you can sync your accounting connection after any addition or modification in your ERP. This way it syncs faster in BItwave.

***

## Q: How to check if QBO connection status is updated or not ?

:a:In the left-hand corner of your Bitwave app,

1. Navigate to Administration.
2. Go to Accounting Connections.
3. Check the “Setup Status” and “Last Sync” to check if Quickbooks is updated or not.

***

## Q: I waited for 10 mins after reconciling a set of transactions, but getting an error. What should I do?

### :a::

You can create a ticket in our in app chat support system,  
It will require you few things to create this error query :  
   a. Organization name and Organization ID : Check FAQ no.3 (<https://docs.bitwave.io/docs/frequently-asked-questions-9>)  
   b. Error Message screenshot

***

## Q: There is a red exclamation mark in my Accounting Connections page next to the ERP name. What should i do?

## :a::

You can disconnect and reconnect your ERP account.

Here is the documentation guide for connecting your ERP :

Xero : <https://docs.bitwave.io/docs/xero>

Netsuite : <https://docs.bitwave.io/docs/netsuite>

QBO : <https://docs.bitwave.io/docs/quickbooks>

Sage : <https://docs.bitwave.io/docs/sage-intacct-configuration-guide>

***

## Q: If I have added new contacts in QuickBooks how long will it take for bitwave to pick up the new contacts?

### 🅰️:

It generally takes 12 hours to sync in the new contacts in Bitwave

***

## Q: How do I ensure that my accounting connection is up to date and syncing?

### 🅰️:

There are two things that you can ensure in order to check if the accounting connection is up to date:

1. First check if the sync date is up to date.
2. Check the contacts and categories in Bitwave , If everything ties up there You are good to go

***

## Q : I added new contacts and categories in my Quickbooks/Xero/Sage intacct/Netsuite but i am not able to locate them in Bitwave. How can i get them into Bitwave?

### :a::

Everytime a new contact or a category is added into your ERP system, It requires a sync to get added into your bitwave account. For syncing your accounting connection :

1. Login to Bitwave.
2. Go to Administration.
3. Click on Accounting Connection.
4. Now click on sync and refresh your browser page

   ![](https://files.readme.io/0643cfb-image.png)
5. After a fresh Sync, your newly added Contacts and Categories will be available in your Bitwave Account.

***

## Q: How to "marked as reconciled" the trades in UI?

### :a: :

Here are the steps on how to "marked as reconciled"" trades in UI

1. Go to Trading under Transactions tab on the left hand side menu
2. Click on the Accept on the transaction you want to ""marked as reconciled""..
3. You can also change the Page size and select multiple transactions  you want to reconcile in bulk.
4. Click on Accept"

## Q : How to resolve the variance between the Adjusted Register and the Bitwave Balance Report in month end close reconciliation?

### :a: :

This issue is basically a categorization issue where some transactions are incorrectly categorized which cause variances while performing a reconciliation Steps to rectify the variance in your reconciliation : 

1. Run the reports by the same method but making the time frame shorter for finding the exact date of variance ( monthly to weekly to daily )
2. Example : Break the month, 1 - 15 march and then 16 - 31 march.
3. Find out which half has the variance
4. Then break that half again i.e. 1 - 15 march has variance so the break could be 1 - 7 and 8 - 15.
5. This way you can break this half by weeks and continuing till you find the exact variance date.
6. Lets say you got 3rd of march the date where the variance is starting from, try to find if the variance amount matches any transaction amount in the Transaction UI or something related to the variance amount.
7. If not, then it is recommended to uncategorize and recategorize that specific day's transactions.
8. If you cannot find the variance from reviewing the Transaction UI, you will need to compare at the transaction level detail between these three reports to find out which report is missing data:
9. Journal Entry or Expanded JE Report -> this report drives the values in the DR and CR rows 2 and 3
10. Actions Report -> this report drives the Realized and Unrealized gain / loss rows 5 and 10
11. Export Report -> this report drives the Bitwave Balance in row 15

***

## Q:Why is my manual wallet not uploading to Bitwave?

### :a::

There are a few common reasons why your manual wallet might not be uploading to Bitwave:

1. Make sure your file is in the right format (CSV).
2. Ensure all required fields are filled in and in the correct format.
3. Ensure you have the correct account ID:  
   <br />  
      Navigate to: Left Menu -> Wallets & Connections -> Wallets.  
      Click "Details" next to your wallet.  
      Copy the ID from the ID field.

### :a::

Bitwave will sync your chart of accounts and other relevant information such as invoices, vendors, and customers from your ERP software.

***

## Q: How long does it take for the initial sync of ERP data to complete?

### :a::

The initial sync typically ranges from 5 minutes up to 1 hour. You may start seeing some data immediately after setup, but full synchronization can take some time.

***

## Q: Where can I find my synced ERP data in Bitwave?

### :a::

You can view your synced ERP data in Bitwave by following these steps:

Go to: Menu -> Accounting -> Categories & Contacts.

***

## Q: How do I reconcile transactions in bulk?

### :a::

:a::  Here are the steps to reconcile transactions in bulk

1. Go to systems jobs under administration tab on the left hand side menu
2. Click on create job

![](https://files.readme.io/cd5cf19-image.png)

3. Select the action ' reconcile'
4. Select the wallet and choose the time period then hit run

***

### Q: How does spec id and cost average tax strategies work ?

## 🅰️:

Under the spec id tax strategy, Tax lots will be selected based on set coin selection strategies while under cost average tax strategy, The average of the cost will be used as cost basis.

***

## Q: What is the difference between reconciled and to be reconciled?

### :a::

Reconciled means already pushed to ERP and to be reconciled means its ready to be pushed to ERP but is not reconciled yet.

***

## Q: How to Connect ERP to Bitwave?

### :a::

  1 - Go to: Menu -> Administration -> Accounting Connections -> Click "Connect New Account".

2. Select preferred ERP Software

   - Follow the prompts to allow Bitwave access.

3. Finish ERP Setup by  Returning  to: Menu -> Administration -> Accounting Connections -> Click "Finish Setup"
   - Then Create accounts: Bitwave - Digital Assets and Bitwave - Crypto Fees.
   - Press the sync button.

4. To View Synced Data from ERP 
   - Go to: Menu -> Accounting -> Categories & Contacts.
   - Initial sync may take 5 minutes to 1 hour.  
     More more detailed explanation use   connecting to ERP [Guide ](https://bitwave.stonly.com/kb/guide/en/segment-2c-connect-your-general-ledger-erp-software-PpeLB3ZcwV/Steps/)

***

## Q:  After accepting the trades will there be a difference in Rolled Up Journal Entry Reports, Balance Figures and Gain/Loss figures?

### :a::

Nope, Accepting trades only marks them as reconciled. There will be no difference in Rolled Up Journal Entry reports, Balance Figures, and Gain/Loss figures and Bitwave does not produce a journal entry for the trade transactions.

***

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

***

## Q: How can we delete transactions from ERP (Quickbooks, Netsuite or Xero)?

## :a::

It’s a manual process which is to be done by the customer. Bitwave cannot delete any transaction from the ERP.

***

## Q: Can I add a Coinbase account to Bitwave for a different entity while keeping it segregated from the existing entity?

## :a::

Yes, we can set this up for you. We will need to update the current Service Agreement to accommodate multiple entities. Please reach out to us via in-app chat support with the following details:

1. Organization Name
2. Organization ID

## Q: I reconciled transactions in Bitwave but don’t see them in QuickBooks Online. What happened?

:a::  
If your transactions are marked as "Reconciled" but not appearing in your ERP (like QuickBooks), it's likely they were only flagged as “Reconciled” and not actually "Synced." Only transactions with a status of "Synced" are pushed to the ERP.

To resolve this:

Ensure you use the “Sync” action in the Transactions UI.

Check the transaction status in the All Transactions view.

Remember, “Marked as Reconciled” does not automatically push the transaction to your ERP

## Q: What’s the difference between “Marked as Reconciled” and “Synced” in Bitwave?

:a::  
Marked as Reconciled: The transaction is flagged as reviewed internally, but is not sent to your ERP system.

Synced: The transaction is both reconciled and pushed to your ERP (e.g., QuickBooks Online or NetSuite).

To send transactions to your ERP, always use the “Sync” action.

## Q: I can’t find my April transactions in the Reconcile or Transaction view — where are they?

:a::  
If you're unable to locate April transactions:

Go to the All Transactions view.

Adjust the date filter to cover April 1 to April 30.

Look for transactions labeled as “Marked Synced” instead of “Synced.”

Transactions marked only as “Marked Synced” have not been fully pushed to your ERP.

## Q: How can I fix transactions that were mistakenly marked as reconciled but not synced?

:a::  
You can correct this by:

Navigating to the All Transactions view.

Undoing the reconciliation, if necessary.

Reprocessing the transactions using the “Sync” action.

Confirming the status updates to “Synced.”

This will ensure the transactions are properly exported to your ERP.

## Q: What info should I provide if I need support on reconciliation/sync issues?

:a::  
To get quicker support from Bitwave, include the following details:

Organization Name and ID

Wallet ID (if applicable)

Transaction IDs and Date Range

A short description of the issue

Your email address

***

<br />

## Q: I’m getting an error (code "account code") when trying to reconcile a crypto transaction to Xero. What should I do?

:a::

This error often occurs when the default fee account isn't set up correctly. To fix this, go to Administration > Accounting Setup and update the Fee Account back, or ensure it matches the account code you've configured in Xero. If the issue persists, please contact our support team for further help.

***

<br />

## Q: I’m getting an error related to the Crypto Fees account when trying to reconcile transactions, even though the account code is correct in Xero and Bitwave. What should I do?

:a::

This error may occur if Bitwave is still trying to use an outdated account reference. First, confirm the Crypto Fees account is correctly set in both Xero and Bitwave. Then, go to Administration > Accounting Setup and ensure the updated account code (e.g., 7800) is saved there. If reconciliation errors continue, revert to the old code temporarily if needed for urgent tasks, and reach out to our support team.

***

<br />

## Q: I can’t edit the Default Fee Account under Accounting Connections in Bitwave. How do I make changes?

:a::

If you find the fields under Administration > Accounting Connections uneditable, try navigating to Administration > Accounting Setup instead. There, you should be able to update your account settings, including the Default Fee Account. If the fields are still locked or the issue continues, please contact our team for further help.

***

<br />

## Q: I disconnected and reconnected my Xero integration to fix an account mapping issue, but it didn’t solve the problem. What should I do next?

:a::

Disconnecting and reconnecting Xero can refresh some settings, but it might not update account references. After reconnecting, make sure to review and update account mappings under Administration > Accounting Setup to ensure the correct accounts are linked. If the problem persists, let our support team know and we’ll assist directly.

***

<br />

## Q: I logged in through Xero but don't see any options to connect wallets or perform actions on the dashboard. What should I do?

:a::

If you're using Bitwave with Xero and find that your dashboard appears empty or lacks options, it's likely due to an incomplete setup. We recommend following our Xero integration guide to properly configure your account. If you're still experiencing issues after reviewing the guide, feel free to reach out to our support team for further assistance.

***

<br />

## Q: Why are some of my transactions failing to sync with QuickBooks Online (QBO)?

:a::

Sync failures can occur for various reasons. If you're seeing errors when syncing to QBO, try the following steps: 1: Uncategorize the transaction. 2: Re-categorize it. 3: Navigate to the Reconcile screen under the Accounting tab and reconcile the transaction again. If the issue persists, please provide the transaction ID to our support team,  we may need to escalate it to our engineering team.

***

## Q: How do I delete transactions that were synced to QuickBooks Online (QBO) from Bitwave?

:a::

To delete transactions that were synced to QBO, you’ll need to manually remove them directly within QBO. Bitwave does not currently support an "unsync" feature for this process.

***

## Q: Is unreconciling transactions in Bitwave the correct first step before removing them from QBO?

:a::

Yes, unreconciling the transactions in Bitwave is the correct first step. After that, manually delete the transactions in QBO. Once done, you can reconcile and resync the corrected transactions back into QBO.

***

## Q: I’m getting an internal server error when trying to categorize certain transactions. What should I do?

:a::

This may be due to a temporary issue or conflicting data within the transaction. Please send a list of the affected transaction IDs to support. Our team will investigate and escalate internally as needed.

***

## Q: My categorization rule didn’t work nothing was categorized. What should I do?

:a::

First, ensure all required pricing is applied before creating the rule. If the rule still doesn’t work, delete it and contact support with your token list so we can assist with pricing and rule setup.

***

## Q: What happens if I categorize a transaction before the token has proper pricing?

:a::

If a transaction is categorized before accurate pricing is applied, it may reflect $0 or incorrect values. Always ensure tokens are priced first—either automatically or via override—then proceed with categorization.

***

## Q: Can I create multiple tax lots for a single wallet in Bitwave, especially as of a specific date like 1/1/2025?

:a::

Yes, you can create multiple tax lots for one wallet by splitting your deposits into individual tax lots and importing them manually using the beginning balance import template. Assign a cost basis to each lot to accurately track them.

***

## Q: How do I specify which tax lot is used first according to FIFO (First In, First Out)?

:a::

Bitwave uses the earliest timestamp of the tax lot you import to determine the order for FIFO. The tax lot with the earliest date will be used first.

***

## Q: When importing tax lots using the CSV template, are there any formatting rules I should be aware of?

:a::

Yes, make sure that amounts and cost fields do not contain commas, as this can cause upload errors.

***

## Q: How can I find the wallet ID associated with each transaction or tax lot?

:a::

<br />

For wallet IDs, export the Transactions report by going to Transactions > Export, selecting your time period, and exporting all wallets.

The Actions Report shows wallet names, not IDs. To link names to IDs, search wallet names in the Wallets section of Bitwave and view their details.

***

## Q: What should I do if my transactions fail to sync with QuickBooks (QBO)?

:a::

If transactions fail to sync with QBO, first try uncategorizing and then recategorizing the transaction. After that, go to the Reconcile screen under the Accounting tab and attempt to reconcile it again. If this does not resolve the issue, you may need to un-sync and unreconcile the transaction, then sync it again. If problems persist, contact support for further assistance.

***

## Q: How can I mark trades as reconciled or synced in Bitwave?

:a::

To mark trades as reconciled/synced, go to the Trading Tab and click “Accept” for the relevant trades. This action will complete the reconciliation process for those trades in the transactions UI.

***

## Q: What should I do if my QuickBooks Online (QBO) sync has stopped and I see an exclamation point next to the connection?

:a::

If your QBO sync has stopped and you're seeing an exclamation point next to the connection, it likely means the integration needs to be reconnected. Try re-setting up the QBO connection. If the issue persists, proceed to disconnect and reconnect the account via the settings menu (click the three dots next to the connection and choose "Reconnect"). This typically resolves the problem.

***

## Q: What if re-setting up the QBO connection doesn’t fix the issue?

:a::

If simply re-setting up the connection doesn’t work, try fully disconnecting the QBO integration and then reconnecting it. You can do this by clicking on the three-dot menu next to the QBO connection in your Bitwave dashboard and selecting “Reconnect.” If the issue continues, reach out to our support team with the requested details for further troubleshooting.

***

## Q: How can I tell if the QBO sync issue has been resolved?

:a::

Once you’ve reconnected the QBO integration, look for syncing activity to resume. You might see a clock icon temporarily, indicating that syncing is in progress. If data starts syncing again and no error messages appear, the issue has likely been resolved.

***

## Q: What should I do if I receive an error when pushing a transaction and suspect it might be related to QBO?

:a::

If you’re seeing an error while pushing a transaction and suspect it may be linked to QuickBooks Online (QBO), please check if your QBO connection is active. If it appears to be disabled, reconnect your QBO account to Bitwave to ensure it is up to date.

***

## Q: Can I create a Journal Entry (JE) in QBO to fix a sync issue if I'm in a hurry?

:a::

Yes, if you're under time constraints, you can manually create a JE in QuickBooks Online (QBO). Just let us know, and we'll continue troubleshooting on our end.

***

## Q: What do I need to do in Bitwave if I re-number GL account numbers in QuickBooks Online (QBO)?

:a::

If you're only renumbering accounts in your QBO Chart of Accounts and not adding or deleting them, you should ensure that the transactions in Bitwave are still correctly categorized. The numbers you see in Bitwave reflect the QBO accounts you've selected during transaction categorization. If the account numbers change in QBO, double-check that each transaction in Bitwave still maps correctly to the intended accounts.

***

## Q: Do I need to notify Bitwave or take any specific steps if I update my QBO Chart of Accounts?

:a::

While you don't need to notify Bitwave for account number changes, it's important to verify that account mappings in your Bitwave transactions are still accurate after making changes in QBO. No need to re-add or delete accounts in Bitwave if you're only renumbering.

***

## Q: Why does my Bitwave report show a gain when my QuickBooks shows a loss?

:a::

This discrepancy could be due to differences in data sync timing or cost basis methodology. For example, if your data from January to September was synced via another platform (like Gilded) and only Q4 was synced through Bitwave, make sure all data is fully integrated in Bitwave for accurate reporting. Additionally, ensure the cost basis settings (e.g., FIFO) match between QuickBooks and Bitwave.

***

## Q: Which cost basis method should I use in Bitwave for accurate tax reporting?

:a::

You can choose either FIFO (First-In, First-Out) or Cost Average depending on your accounting preference. If you’re aiming to match your QuickBooks records, we recommend using the same method in Bitwave. FIFO is commonly used and supported in the Cost Basis Roll Forward Report.

***

## Q: Why do I get a “failed to reconcile” error when reconciling transactions?

:a::

This error can sometimes occur due to a temporary sync issue. We recommend clearing your browser cache and performing a hard refresh of your Bitwave organization. This often resolves the problem and allows reconciliation to complete successfully.

***

<br />

***
