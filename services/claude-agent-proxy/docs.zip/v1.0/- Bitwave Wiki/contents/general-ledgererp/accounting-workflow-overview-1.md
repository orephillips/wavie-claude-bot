---
title: "Accounting Workflow Overview"
slug: "accounting-workflow-overview-1"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:31:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:31:56 GMT+0000 (Coordinated Universal Time)"
---
<br>

![](https://files.readme.io/ea76a22-Screenshot_2024-01-12_at_02-52-57_The_Perfect_ONBOARDING_USER_GUIDE.png)

**Introduction to the Accounting Workflow**

The accounting module is one of the core modules of Bitwave. Data that is synced or created in Bitwave  is referred to as “Transactions”. Transactions are synced into Bitwave via on-chain wallets, exchanges, and non-custodial wallets that were set up in previous steps. Once that data is populated, you are ready for the accounting workflow. The accounting workflow is a two-step process: (1) **Categorization** and (2) **Reconciliation & Sync**. The first step is a process called Categorization, which is relevant to the “preparer.” This step requires that you determine how to classify the transactions and apply or code the actual transaction to a general ledger account. This step may require that you perform further research or inquire with your company or firm’s internal or external team members for further information regarding the business use case in order to complete the Categorization process.

The second step in the accounting workflow is the Reconciliation & Sync process, which is performed by the “reviewer.” During the Reconciliation process, the reviewer does a high level review of the coding to ensure that transactions have been classified properly and that the fiat values are reasonable prior to syncing that data over to the general ledger (ERP) system.

If users choose to not sync their data to their ERP, they may use the journal entry reports to manually record their data to their general ledger instead, in which case they may use the Rolled Up Journal Entry.

The accounting workflow in Bitwave is broken into two major steps:  
a. **Categorization: **This involves applying a category and contact to the transactions. This can be considered to be activity performed by the "preparer." There are two approaches to categorization:  
(i) _Individual categorization:_ performed by the user in the user interface or via the manual import template.  
(ii) _Rules based categorization:_ performed through creation of pre-set rules by the user which are applied to transactions fitting the criteria by the rules engine.  
b. **Reconciliation and Sync:** This involves reviewing categorized transactions and syncing those transactions to your GL (ERP) software.
