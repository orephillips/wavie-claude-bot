---
title: "Netsuite Enterprise Payments Setup"
slug: "bitwave-to-netsuite-enterprise-payments-setup"
excerpt: ""
hidden: false
createdAt: "Thu Oct 24 2024 14:28:03 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 24 2024 15:07:54 GMT+0000 (Coordinated Universal Time)"
---
## Netsuite Payments Setup

**Step 1: Create a Custom Record**

<br />

![](https://files.readme.io/887c32a5869281cfbb13813428312afd218150bdd3ab7b98004a14e06649e31a-1.png)

<br />

**Step 2a: Create Saved Search FOR BILLS**

The following are the fields that are needed

![](https://files.readme.io/9be8c9293acc60df57ac3595e855a58ff823ae88f7a394307ba9e54b74da160d-2.png)

<br />

**Step 2b: Create Saved Search FOR Vendors**

The following are the fields that are needed:  
**•** Vendor Name  
**•** Email1  
**•** Email 2  
We use this for emailing remittance to vendors

<br />

**Step 3: Add Permissions for Custom Record to the “Bitwave Role”**

![](https://files.readme.io/d74ca474c945f9a79f6c9db6f87a00dc0f3a84e26eb304b81ab99193bc9bc903-3.png)

<br />

Add the REST WEB SERVICES

![](https://files.readme.io/11a0c2d806307886c31adc3d7448bd93fae730bfa5e2d458ada279acb39c0e73-4.png)

<br />

**Step 4: Provide The following IDS from Netsuite Custom Record**

**•** Script ID  
**•** Address  
**•** Network  
**•** IsValidated  
**•** LastValidatedDate  
**•** Vendor  
**•** Cryptocurrency

![](https://files.readme.io/44664610ad8a39be2cba6ff3cf110e5b4d451a5e8b38a83a498cf5d87622a5c6-5.png)

<br />

**Step 5: Provide The following IDS from the Netsuite Bill Saved Search**

**•** Bill Saved Search ID  
**•** Array ID  
**•** isWalletValid  
**•** Address  
**•** CryptoCurrency  
**•** LastValidated  
**•** Network  
**•** Vendor  
**•** IsNotCrypto  
**•** PricingMethod (Optional / Future)

![](https://files.readme.io/25bd8dcb6f4e2522f3edb584826da425fcb7dddaf4b256c28beafdec13f4dd3c-6.png)

<br />

**Step 6: Obtain the following IDs from the Vendor Saved Search**

**•** Saved Search ID  
**•** Array ID  
**•** Email1 ID  
**•** Email2 ID

![](https://files.readme.io/c99a3a9f4af590c1e173bc5754733c09967a2f5367902924df445814ec2b9001-7.png)

<br />

Once you have this information a Bitwave Solutions Specialist can use this information to connect Bitwave to Netsuite Saved Search which would then sync information into the Enterprise Payments App.
