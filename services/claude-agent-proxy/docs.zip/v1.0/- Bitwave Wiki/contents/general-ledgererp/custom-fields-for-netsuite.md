---
title: "Custom Fields for Netsuite"
slug: "custom-fields-for-netsuite"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:45:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 01:50:17 GMT+0000 (Coordinated Universal Time)"
---
