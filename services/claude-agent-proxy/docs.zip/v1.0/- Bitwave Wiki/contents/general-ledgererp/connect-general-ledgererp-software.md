---
title: "Connect General Ledger/ERP Software"
slug: "connect-general-ledgererp-software"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:24:57 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 20 2024 23:48:07 GMT+0000 (Coordinated Universal Time)"
---
[XERO SETUP](https://docs.bitwave.io/page/xero)

[SAGE SETUP](https://docs.bitwave.io/docs/sage-intacct-configuration-guide)

[NETSUITE SETUP](https://docs.bitwave.io/page/netsuite)

[QUICKBOOKS SETUP](https://docs.bitwave.io/docs/quickbooks)
