---
title: "Month End Close Discrepancies"
slug: "month-end-close-discrepancies"
excerpt: ""
hidden: true
createdAt: "Fri Jun 28 2024 15:28:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 18:21:01 GMT+0000 (Coordinated Universal Time)"
---
## I am completing my Month End Reconciliation and I have a variance. How do I resolve my variance?

Step 1: Determine the date that the variance starts. 

Add a new column to the Month End Reconciliation template and begin to narrow down the date in which the variance starts. 

For example, if we reconciled the period of 1/1/2024 - 1/31/2024 and noted a variance, then we will want to use the date that is the half way point, 1/15/2024, to determine if the variance fell in the first half of the month or in the second half of the month.

![](https://files.readme.io/5d2a3ff-image.png)

> 📘 The reports you will need for the variance reconciliation is the same as the reports you would need for the month-end-reconciliation process:
> 
> - Rolled Up Journal Entry Report
> - Inventory Views Actions Report
> - Balance Report
> 
> Run the following reports from the day after the last period, in this example 1/1/2024 - 1/15/2024 or for the period end date, which is 1/15/2024 for this example.

<br />

### Rolled Up JE Report

<br />

![](https://files.readme.io/f36ea05-image.png)

### Inventory Views Actions Report

For the Inventory Views dashboard, select the last day of the period, in this example 1/15/2024. This will populate the data through this date selected.

Next, select "Download Actions."

<br />

![](https://files.readme.io/06c2bfd-image.png)

<br />

### Balance Report

For the Balance Report, select the date for the end of the period that you are reconciling. 

In this example, we are selecting 1/15/2024.

![](https://files.readme.io/9151006-image.png)

<br />

<br />

Reasons that the reconciliation would show a variance

- Missing Transactions
- Categorization Issue
- Pricing Issue
- <br />
