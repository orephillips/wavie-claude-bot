---
title: "Sage Connection Guide"
slug: "sage-intacct-configuration-guide"
excerpt: ""
hidden: false
createdAt: "Fri Oct 14 2022 18:25:44 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon May 20 2024 18:39:11 GMT+0000 (Coordinated Universal Time)"
---
This document provides step-by-step instructions on how to set up the connection between Bitwave and Sage Intacct.

## Prerequisites

Subscribe to Web Services

1. Company → Subscriptions
2. Find “Web Services” and click on it to Subscribe
3. Ignore the warning about additional charges

![](https://files.readme.io/0ead877-1.png "1.png")

## IP Address

Add Bitwave’s IP Addresses below to Sage Intacct’s allowed list.

104.196.183.18

35.230.22.143

1. Company → Company Info
2. Click EDIT
3. Click on the “Security” tab
4. Go to the field labeled “Enforce IP address filters” and click the Edit icon

![](https://files.readme.io/394336b-2.png "2.png")

## Sender ID

Add Bitwave’s Sender ID **BitwaveMPP** to Sage Intacct’s allowed list.

1. Company → Company Info
2. Click EDIT
3. Click on the “Security” tab
4. Go to the section labeled “Web Services authorizations” and add the Sender ID

![](https://files.readme.io/e6ef5bb-3.png "3.png")

## Users

Create a Web Services Bitwave user and role.

Create a Role 

1. Company → Roles
2. Click ADD
3. Input a “Name”
4. Click SAVE
5. Click on the necessary Permission for

![](https://files.readme.io/b59c723-4.png "4.png")

![](https://files.readme.io/cebb2f9-5.png "5.png")

Company Permissions

![](https://files.readme.io/0dde614-6.png "6.png")

Cash Management Permissions

![](https://files.readme.io/d393309-7.png "7.png")

General Ledger Permissions

![](https://files.readme.io/df772c5-8.png "8.png")

Account Payables Permissions

![](https://files.readme.io/90e2259-9.png "9.png")

Account Receivable Permissions

![](https://files.readme.io/14aef59-10.png "10.png")

### Create Web Service User

1. Company → Web Service User
2. Click NEW
3. Input values for these fields  
   a. User ID e.g. Bitwave_XML  
   b. Last name  
   c. First name  
   d. Email address  
   e. Make sure the User Type = Business User
4. Click on the ‘Roles information’ tab and select the Role created in the prior step
5. Click SAVE
6. Ignore any warning that there will be a charge for creating the User

![](https://files.readme.io/91d0ad2-11.png "11.png")

## Accounts

Bitwave - Digital Assets Account

1. Go to Cash Management → Checking → Add

![](https://files.readme.io/dc4edfb-12.png "12.png")

2. Enter the **Account Id**, **Account number**, and **Bank name**  
   • **Account Id**: Bitwave DigitalAsset  
   • **Bank name:** Bitwave - Digital Assets

![](https://files.readme.io/6de1545-13.png "13.png")

3. A GL account needs to be created for this bank account. See the next section

![](https://files.readme.io/ab972fb-14.png "14.png")

4. Fill out the following fields:  
   • Primary/Sub Account number: Use any available GL account number  
   • Title: **Bitwave - Digital Assets Clearing**  
   • Account Type: **Balance Sheet Account**  
   • Normal Balance: **Debit**  
   • Period End Closing Type: **Non-Closing Account**  
   • Dimension settings: Do not select any dimension settings; these are not required  
   • Click **Save**

![](https://files.readme.io/c0a2ac9-15.png "15.png")

## Bitwave - Crypto Fees Account

1. Go to General Ledger → General Ledger Accounts → Add

![](https://files.readme.io/7f32cf3-16.png "16.png")

2. Fill out the following fields:  
   • Primary/Sub Account number: Use any available GL account number  
   • Title: **Bitwave - Crypto Fees**  
   • Account Type: **Income Statement Account**  
   • Normal Balance: **Debit**  
   • Period End Closing Type: **Non-Closing Account**  
   • Dimension settings: Do not select any dimension settings; these are not required

![](https://files.readme.io/6396204-17.png "17.png")

## Integration

Connect Sage Intacct to Bitwave

1. Go to ORGANIZATION → CONNECTIONS → CREATE NEW ACCOUNTS

![](https://files.readme.io/34f628d-18.png "18.png")

2. Click Sage Intacct

![](https://files.readme.io/c3f68c4-19.png "19.png")

3. Enter details as below  
   • Entity ID: Enter your entity id or leave blank for root  
   • Webservice User: Enter user created in prerequisites  
   • Webservice Password: Enter password for above user  
   • Digital Asset Account Code: **Bitwave - Digital Assets**  
   • Fee Account Code: **Bitwave - Crypto Fees**  
   • Base Currency: **USD**

![](https://files.readme.io/b2bcc07-20.png "20.png")

4. Click SAVE
