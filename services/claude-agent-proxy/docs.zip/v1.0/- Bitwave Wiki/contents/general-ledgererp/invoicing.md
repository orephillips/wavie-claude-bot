---
title: "Invoice Categorization"
slug: "invoicing"
excerpt: "Set up Invoice Categorization With Different Accounting Connections"
hidden: false
createdAt: "Fri Jun 28 2024 16:31:02 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 16:16:16 GMT+0000 (Coordinated Universal Time)"
---
This feature allows you to associate blockchain transactions with customer invoices or vendor bills.

This is a useful categorization to automatically apply payments to customer invoices or vendor bills without having to post payment into ERPs and then manually apply. In addition, it automatically calculates forex between historical exchange rate and fmv of the transaction. 

This feature is in the transaction page.

![](https://files.readme.io/fd44e70-Screenshot_2024-06-28_at_12.49.27_PM.png)

To begin using the invoice categorization, we have to set up the Default Accounts Payable and Default Accounts Receiveble. 

![](https://files.readme.io/82eb699-Screenshot_2024-06-28_at_12.35.47_PM.png)

**QuickBooks and Xero**

The Default Accounts Payable and the Default Accounts Receivable accounts are the normal AP or AR accounts in your Chart of Accounts. 

The end result of the sync process is that we will have Vendor Bill Payment or Deposit, and the Forex will be posted as Journal Entries against Accounts Payable or Accounts Receivable. 

**Netsuite**

The integration is a bit different for Netsuite. First we have to create an account in Netsuite with BANK type, and we usually call it Bitwave Clearing. The currency has to be the same currency of the Netsuite organization, and it has to be the same subsidiary. 

The Default Accounts Payable and the Default Accounts Receivable will be the clearing account we just created. 

The end result of the sync process is we will post Vendor Payment or Customer Payment in their nominal currency against the clearing account. We then post a Check or a Deposit from that clearing account to the digital asset account along with the Forex adjustment as a line item. 

To enable multi-currency, we will have to put the organization's base currency id in Netsuite in the Netsuite Connection. You can find that id in the Currency page in Netsuite. 

![](https://files.readme.io/db72757-Screenshot_2024-06-28_at_12.58.14_PM.png)
