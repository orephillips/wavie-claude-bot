---
title: "Netsuite Connection Guide"
slug: "netsuite"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 04 2024 19:52:22 GMT+0000 (Coordinated Universal Time)"
---
[block:embed]
{
  "url": "https://drive.google.com/file/d/16-5HnMxfMGiXAZKjBLQN8AbpjmfDKM2A/view?usp=drive_link",
  "title": "NetsuiteIntegration_v1-3.pdf",
  "favicon": "https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_32dp.png",
  "image": "https://lh3.googleusercontent.com/drive-viewer/AKGpihZKgG9oJtVCK19-8eARaJ0NsNYv_GDK0VV2-BBXNklo9orlVHC5MlSoZ1SMViVZT-pbc5qgngaH1qHK5R2EjyBNxj2rP0p1vxg=s1600-rw-v1",
  "provider": "drive.google.com",
  "href": "https://drive.google.com/file/d/16-5HnMxfMGiXAZKjBLQN8AbpjmfDKM2A/view?usp=drive_link",
  "typeOfEmbed": "pdf"
}
[/block]


## Netsuite Connection Guide

<br />

![](https://files.readme.io/faa1d79-0.png "0.png")

![](https://files.readme.io/86a2195-NetsuiteIntegration_v1-3_page-0003.jpg)

![](https://files.readme.io/17d84ae-NetsuiteIntegration_v1-3_page-0004.jpg)

![](https://files.readme.io/96153aa-NetsuiteIntegration_v1-3_page-0005.jpg)

<br />

![](https://files.readme.io/e6422cc-NetsuiteIntegration_v1-3_page-0006.jpg)

<br />

![](https://files.readme.io/2ba3b8b-NetsuiteIntegration_v1-3_page-0007.jpg)

<br />

![](https://files.readme.io/6c6bbda-NetsuiteIntegration_v1-3_page-0008.jpg)

<br />

![](https://files.readme.io/f9016b6-NetsuiteIntegration_v1-3_page-0009.jpg)

<br />

![](https://files.readme.io/9e58098-NetsuiteIntegration_v1-3_page-0010.jpg)

<br />

![](https://files.readme.io/2fee441-NetsuiteIntegration_v1-3_page-0011.jpg)

<br />

![](https://files.readme.io/d7ad7f9-NetsuiteIntegration_v1-3_page-0012.jpg)

> ❗️ **STEP 28 - ADDITIONAL NOTES**
> 
> **NETSUITE SETUP FOR AR/AP**
> 
> Within Netsuite In order to perform AR and AP from Bitwave to Netsuite
> 
> 1. Bitwave AR Clearing Account of TYPE BANK is required to be setup
> 2. Bitwave AP Clearing Account of TYPE BANK is required to be setup
> 
> **BITWAVE SETUP FOR AR/AP**
> 
> 1. Proceed to Administration -> Accounting Setup
> 2. Choose the AR clearing Account identified above as your Default  Account Receivable Category
> 3. Choose the AP Clearing Account identified above as your Default Account Payable Category

<br />

![](https://files.readme.io/cb63765-NetsuiteIntegration_v1-3_page-0013.jpg)

![](https://files.readme.io/26d88ab-NetsuiteIntegration_v1-3_page-0014.jpg)

![](https://files.readme.io/da34aea-NetsuiteIntegration_v1-3_page-0015.jpg)

![](https://files.readme.io/625261b-NetsuiteIntegration_v1-3_page-0016.jpg)

<br />

## How to Update Your Netsuite Accounting Connection Keys

Step 1: Navigate to Administration > Accounting Connections

Step 2: Select "Update Credentials"

![](https://files.readme.io/5174094-image.png)

Step 3: Obtain the following fields

- Consumer Key/Secret - Follow [Step 9](https://docs.bitwave.io/docs/netsuite#netsuite-connection-guide) in the previous section
- Token Key/Token Secret - Follow [Steps 20-24](https://docs.bitwave.io/docs/netsuite#netsuite-connection-guide) in the previous section

![](https://files.readme.io/483cdcb-image.png)

Step 4: Select SAVE. Success!
