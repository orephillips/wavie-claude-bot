---
title: "Period End Close"
slug: "period-end-close-1"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:25:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:28:21 GMT+0000 (Coordinated Universal Time)"
---
1. Once you have reconciled and synced transactions to your ERP, you are ready for the period end close process. Navigate to the Period End Close on the left menu. Follow the steps noted on this screen. Note, the blue text indicates links to the corresponding report.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/822f7ec-Period_End_Close_1.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. First download the Period End Reconciliation Template.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a5808de-Period_End_Close_2.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. Next, run the Gain/Loss scenario for the period period and locate the Cumulative Cost basis of digital assets and input that value in D7 for the beginning cost basis in the Period End Reconciliation Template.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/80ac144-Period_End_Close_3.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ce2c802-Period_End_Close_3.2.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Scroll down to locate the Gain Loss summary. Note the “Unrealized” figure. If the figure is green, this is a positive value. If the figure is negative and colored in red, this indicates a negative value.Scroll down to locate the Gain Loss summary. Note the “Unrealized” figure. If the figure is green, this is a positive value. If the figure is negative and colored in red, this indicates a negative value.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8dfc02b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Transfer the Unrealized Gain or Loss from the Scenario Runner to the Period End Close Template in row 9 for the corresponding period. For example, if you are closing for the period 1/1/2024-1/31/2024, you will transfer the values to the 1/31/2024 column in cell E9.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5b8c611-Period_End_Close_5.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Transfer the Realized Short Term and Realized Long Term Gain or Loss to the Period End Close Template in row 5.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1c80868-Period_End_Close_6.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


7. Next, run the Balance Report by navigating on the left menu to _reports_.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/40e13e0-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


a. Select the Balance Report which allows you to query the fair market value of each digital asset at the end of the day selected at 11:59 PM (based on the entity’s timezone).

For example, if you wish to know what your end of day balance of BTC was on 9/22/2021, you would run the balance report for this date.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/116316b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


8. Select the Balance as of the end of day either grouped by wallet or without grouping. All other fields are optional.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b68203e-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


9. Transfer the total fiat value to the Period End Close Template in row 14.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/13c99f3-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4715e8b-Period_End_Close_9.2.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


10. Next run the Rolled Up Journal Entry Report

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eef867a-Period_End_Close_10.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


11. Select the corresponding time period as the Gain/Loss report, grouping is optional, and choose the appropriate Accounting Connection (your ERP system).

    Transfer the Report Total values to the Period End Close Template in rows 2 and 3.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/93df62b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/270f846-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


12. The Bitwave Variance column in row 16 is expected to have a $0 variance or based on materiality thresholds. Material differences should be investigated and resolved.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/70fb507-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


13. Record manual entries to your ERP to recognize the realized gain/loss amount from row 5 and true up unrealized gain/loss amount from row 9 to the FMV noted on row 14 based on the accounting method that your entity has adopted.

**Period End Close**

<https://www.loom.com/share/9f871709cc5a4142bf9c11e54f9bb1bf>
