---
title: "Inventory Views"
slug: "inventory-views"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:36:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 18:52:12 GMT+0000 (Coordinated Universal Time)"
---
## What is the Inventory Views Dashboard?

![](https://files.readme.io/896f5be-image.png)

## What are the capabilities of Inventory Views?

“Inventory View” was born out of Bitwave’s engagement with clients involved in some of the most complex and high volume digital asset use cases in which we consistently observed the need to “view” digital asset outcomes from multiple different lenses.

Users can at a glance, access important balance, lot, and roll-forward information for their digital asset inventory (e.g. cost basis acquired, cost basis disposed, impairment, carrying value, FMV, unrealized G/L, and more…) through an “Inventory View”.

Users will also notice right away that all of the data tables are highly responsive and performant which will be a breath of fresh air for our users ranging from hundreds of thousands to millions of transactions a year.

Users can now easily maintain separated tax and accounting books by creating multiple views of their inventory (Note: creating 2 or more inventory views requires the purchase of an upgrade).

From Inventory Views, you may find important information about your digital asset holdings as of any date (or date range), including:

- Holdings token quantity
- Cost basis
- Carrying Value
- Market Value
- Unrealized gain/loss position
- Realized gain/loss
- Impairment Expense
- Fair Value Adjustments

## Application for Multi-Book Accounting

Bitwave enables our users to maintain several sets of books in parallel for different purposes (e.g. GAAP books, tax books, etc.) via our [Inventory Views functionality](https://docs.bitwave.io/docs/setup-inventory-views). In conjunction with this multi-book approach, users can leverage a different custom Multiple Inventory configuration for each set of books. For example, a single Bitwave environment could use a single Inventory setup for GAAP Books, an Inventory Group setup for tax books, and WLI setup for Treasury Management. There is no limit to the different configurations of Inventory grouping that can be created and used for different books, without any rework needed from the user. This becomes especially important because our users are able to easily test different configurations to achieve their desired results.

## Glossary

[block:parameters]
{
  "data": {
    "h-0": "Tab",
    "h-1": "Description",
    "0-0": "Inventory View",
    "0-1": "A projection of a digital asset inventory given a variety of treatment options including inventory relief strategy, impairment rules, and capitalization vs expense settings. As an example, a single view an represent the various treatment options required for GAAP, while another view represent treatment options required for non-GAAP and so on.",
    "1-0": "Dashboard Tab",
    "1-1": "Provides a summary of important inventory information, such as cost basis acquired and disposed, carrying value, FMV, and unrealized gain and loss as of a specific date.",
    "2-0": "Actions Tab",
    "2-1": "Provides detailed information pertaining to specific actions performed on digital assets including disposal, acquisition, impairment and other actions filterable by asset and as of a specific date.",
    "3-0": "Lots Tab",
    "3-1": "Provides comprehensive information on each individual lot in your digital asset inventory. It provides full historical information on the actions affecting each lot including lot identification, acquisition, disposal, impairment, and amount data filterable by asset and as of a specific date.",
    "4-0": "Reports Tab",
    "4-1": "A list of reports, including the “Cost Basis Roll Forward Report and Reclass” with more reports to come.",
    "5-0": "Updates Tab",
    "5-1": "Provides detailed information of the status of when the inventory view was last updated.",
    "6-0": "Settings Tab",
    "6-1": "Shows the selected treatment options of the inventory view and provides the capability to permanently DELETE a view.\\*\\*\\*  \nA projection of a digital asset inventory given a variety of treatment options including inventory relief strategy, impairment rules, and capitalization vs expense settings. As an example, a single view an represent the various treatment options required for GAAP, while another view represent treatment options required for non-GAAP and so on."
  },
  "cols": 2,
  "rows": 7,
  "align": [
    "left",
    "left"
  ]
}
[/block]
