---
title: "Export Transactions"
slug: "transactions-export-1"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:00:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 17:53:51 GMT+0000 (Coordinated Universal Time)"
---
The Export Transactions Report provides a CSV download of every transaction that occurred within the period entered in the start and end date complete with date/time, amount, asset, transaction hash and more.

Run the Transactions Export Report by navigating on the left menu to Reports.

![](https://files.readme.io/b701bc7-image.png)

The report can also be accessed by navigating to Export under Transactions in the left menu.

![](https://files.readme.io/03886e7-image.png)

Select the Export Transactions From Date and To Date and an option to export for All wallets or a single wallet.

For example, to query the transaction detail for January of 2021 From date of 1/1/2021 and To date of 1/31/2021 would be selected along with the All wallets default.

\*\*\*The Export Transactions Report exports transaction detail in it's original manually entered, imported or synced state. The result is that any combined sub transactions will be query results of the report and the new combined transaction and transaction ID will not appear on the report.
