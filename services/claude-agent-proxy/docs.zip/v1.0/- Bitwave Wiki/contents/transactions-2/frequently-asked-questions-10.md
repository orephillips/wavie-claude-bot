---
title: "❓FAQs"
slug: "frequently-asked-questions-10"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:03:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 15:02:02 GMT+0000 (Coordinated Universal Time)"
---
# Transactions

***

## Q: How to find missing transactions?

### :a:﻿:﻿

### 1\. To start finding missing transactions, two files are needed:

> - ### Bitwave Transactions Export
>   1. You can find this go by going to **Bitwave** -> **Transactions** -> **Export** -> Set your parameters and click **Export**
> - ### Transactions Export from blockchain explorer (i.e. Etherscan, Solscan, Snowtrace)
>   1. Double check to get all files from the explorer. Some explorers will have _Deposits and Withdrawals_ separate from _Internal Transfers_. Also if you are including _Layer 2 tokens_ then download that file too.
>
> > ❗️ If Explorer doesn't have downloadable reports then use [TableCapture](https://chromewebstore.google.com/detail/table-capture/iebpjdmgckacbodjpijphcplhebcmeop) OR another extension that requires more technical skill is [WebScraper](https://chromewebstore.google.com/detail/web-scraper-free-web-scra/jnhgnonknehpejjnehehllkliplmbmhn)

### 2\.  Steps to find missing transactions

- Paste both files in different tabs in the same sheet. 
- Use a VLOOKUP on the transaction hash in the blockchain export with respect to the  transaction ID column in the Bitwave Export.
- Now use a filter for all the results that contain N/A 
- These are the txns which are not in Bitwave.

### There are multiple reasons a transaction may be missing in Bitwave including, but not limited to, the following:

1. The transaction is being filtered out due to settings in Bitwave.

There may be a filter selection enabled that is filtering out the transactions. Double check the filter settings for Reconciliation, Categorization, and Ignored status in the Bitwave application.

2. There are issues with the blockchain wallet syncing.

This issue may be caused by 1) large transaction volume in the wallet (>50k transactions), 2) a wallet that does not have any transactions, or 3) a general syncer issue. Once you have verified that the wallet is not empty, please reach out to the Bitwave In-App chat for support with this issue.

3. There are issues with the import for a manual wallet.

There could be either an incorrect format with the import file used or a non-unique ID in the import file. Check to ensure that the import process did not return any errors and that all IDs used in column A of the import file are unique across all transaction IDs in the Bitwave application instance. Feel free to reach out to the Bitwave In-App chat for support with this issue. 

4. There are issues with an Exchange/Custodial wallet API key.

There could be permissions issues with the API key provided. Please double check permissions on the platform you are connecting from and follow our \[API connection guides](<https://docs.bitwave.io/docs/all-connection-guides>).

***

## Q: Whats the difference between deleting transactions in the UI and using system jobs:

### :a:﻿:

When a user deletes a wallet without deleting the transactions via the system jobs, then there is a possibility of having the wallet removed but that transactions remain. This makes it difficult to locate these transactions to remove. Also, deleting the transactions from the UI(not using the system jobs) can delete the internal transfer as a whole which will ultimately affect the other wallet that was involved in this internal transfer transaction.

***

## Q. How do I bulk categorize transactions?

### 🅰️.

There are several ways in which bulk categorization can be done:

1. First one is within the transaction UI, just select all the transactions that you want categorized together with the help of 'select all' checkbox and then click on ' Categorize' button. (Note: This method may only work on Standard transaction type).
2. Second one is with of the System jobs template. Under Administration > System Jobs > Create Job and select 'Categorize Transactions', After that download the template that shows up and fill the details, after that upload that csv in Bitwave and click on Run. 
3. Third one is with the help of Rules, You can create rules in order to categorize transactions as well. For more info on rules, you can refer to this [page](https://docs.bitwave.io/edit/how-to-use-rules)

***

## Q: How do bulk uncategorize transactions in Bitwave?

### :a::

- Navigate to the Administration section in the left menu of your Bitwave dashboard.
- Select "System Jobs" from the options available.
- Click on "Create Job" to initiate a new job.
- Choose "Uncategorize" as the type of job you want to create.
- Ensure that no specific wallets are selected to uncategorize transactions from all wallets.
- Specify the date range for the transactions you wish to uncategorize.
- Hit the "Run Job" button to execute the task.
- Finally, click "Submit" to confirm and initiate the automated job.

> NOTE: Depending on the size of your organization, the automated job may take anywhere from 5 minutes to 2 hours to complete.
>
> NOTE: It's essential to remember to turn off any rules that automatically categorize transactions in your organization to prevent interference with the uncategorization process.

***

## Q. How to manually edit transactions for single transactions?

### 🅰️.

1. Login to Bitwave
2. Select 'Transactions'
3. Click on the transaction you want to edit pricing.
4. At the bottom of the transaction line, click on the pencil icon in front of using rate 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/84a4bba-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Edit the price of the token and click on 'Save'

***

## Q. How does the Export Transactions Report show fees?

### :a::

The Export Transactions Report displays fees on the same line item as the deposit detail or withdraw detail that incurred the fee with column L being the feeAmount column N being the feeValueInBaseCurrency and column W being the feeAsset. 

***

***

## Q: How to check the Exchange balances connected via API?

### :a::

To Validate the Exchange Balances

1. **Checking that Connection is Live: **  
   Ensure all of your exchange connections are live. If a wallet or API key was added incorrectly, then transactions from this wallet will not appear. Check that the connection is live by reviewing the wallet or connection in the wallet dashboard and that balances are appearing there. Even if balances are 0, it should still show here.Ensure transactions are showing up in the Transactions UI. We recommend waiting at least 24 hours before performing any balance validation in order to give Bitwave time to sync all transactions,
2. **Validating Balances using the Balance Check Report**

The Balance report can be used to compare your Bitwave org balances with exchange wallet balances.

1. In the left-hand corner of your Bitwave app, go to ""Wallets & Connection.
2. Navigate to ""Reports.
3. Click on ""Balance Report
4. Select yesterday’s date, group by wallet and select the Exchange in the wallet field of which you have to compare the balance.
5. Click RUN REPORT
6. Download Balance report as CSV and export to a spreadsheet.  
   This will give you the up to date balances of all your exchange wallet, based on transactions which have synced into Bitwave.  
   To perform the Balance check you will need to compare the Dashboard Exchange Balances with the Balance Report Balances.

## Q: How do i ignore transactions

### :a::

There are multiple ways to ignore transactions in Bitwave

**Approach 1: Ignoring on a Txn by Txn Basis in the UI**

To Ignore a transactions in the UI simply 

- Log in to Bitwave
- Go to the transactions screen (Left Menu -> Transactions)
- Filter for the Wallet and/or Date period where the transaction or transactions you'd like to ignore can be found
- Select the transaction(s)
- Click Ignore. See full screenshots here

  ![](https://files.readme.io/8bd82f9-image.png)

  <br />

**Approach 2: Ignoring using System Jobs**

This is to be used when you have a large group of transactions to be ignored. Note that its only parameters are Wallet, Date and therefore this would ignore all transactions within a specified wallet over a specified period:

Please review the following link for[ details](https://docs.bitwave.io/edit/system-jobs)

## Q: What are the different ways to delete the transactions?

### 🅰️:

1. **How to Delete transaction from transactions UI**

(Suitable for deleting few random transactions)

\-> Go to the Transactions tab on the left hand side menu.  
    -> Click on the box on the left side of the transaction you want to delete. ( You can select multiple as well)  
    ->  Click on the More actions drop down above  
    -> Then Click delete.

2. **How to delete transactions Via system Jobs**

( Suitable when deleting multiple transaction from particular wallet for a specific period )

\-> Go to Administration tab on the left hand side menu  
-> Click on system Jobs  
-> Then create job  
-> In actions dropdown click delete transaction  
-> Then select the wallet and time period and hit run. 

3. **How to delete transactions Via CSV Bulk Action.**

\-> Go to Administration tab on the left-hand side menu  
-> Click on system Jobs  
-> Then create job  
-> In actions dropdown click CSV Bulk Action.  
-> Then Upload the CSV and hit run.

## Q: Does Bitwave Sync Solana Staking Rewards Automatically?

### A: Bitwave does automatically sync Solona staking rewards. You can set up this feature by following these steps:

1. Identify the stake account associated with your Solona wallet
   1. Search the address in \[Solscan](<https://solscan.io/>)
   2. Navigate to the “Stake Accounts” tab on the address page
   3. Copy the associated stake accounts to add to Bitwave
2. Add the address of the owner of the staking account in Bitwave
   1. Add the address as a wallet in Bitwave
   2. Bitwave will then sync all associated staking rewards into the Bitwave transactions UI

***

## Q: How to filter out the transfer and fees transactions and bulk reconcile them?

### A: Here are the steps which you can follow to filter transfers and fees transactions and bulk reconcile them ,

1. Download the Export file

2. So first to get all transfer txns, you need to filter the from and to addresses so that they are your personal addresses

3. Then to filter for fee txns you need to filter the Operation column for Fees in the export file.

4. Capture all these txns IDs and use system job CSV bulk action.  
   ​  
   Here is the  [template ](https://docs.google.com/spreadsheets/d/1WlkGPZ6bgy7a37LiROerLRJ8lYpk3r39NT3EiiRDwek/edit#gid=281708604)for CSV Bulk Action.  
   ​  
   Note :- Put Action as reconcile and put the transaction IDs in the first column.

***

## Q: Where can I find USD transactions?

### :a:: You can find USD transactions in Transactions Report export.

***

## Q: How to lock the transactions to prevent prevent any changes within a certain period?

### :a:

- Navigate to the Accounting section in the left menu of your Bitwave dashboard.
- Select "Period End Close" from the options available
- Click on the "Enable transaction locking".
- Select the date to lock transactions up to and including that date.
- Click on Save.

***

## Q: How do I export transactions from my organization in Bitwave?

### :a:: In order to export transactions from bitwave you can follow these steps:

### 1. Login to bitwave

### 2. Under menu select 'Transactions'

![](https://files.readme.io/139b226-image.png)

### 3. Select 'Export' under the transactions tab

### 4. Specify the time period for which you want to download the transactions

### 5. Click on Export and the transactions will be downloaded for you in a csv file.

***

## Q: In what format will the exported transactions be provided (e.g.,PDF,CSV)?

### :a:: The exported transactions will be provided in the CSV format

***

## Q : How do I run a transaction history report for one single token for a specific wallet?

### :a: : Follow the steps below :-

1. Go to transactions
2. Click on register
3. Select wallet name
4. Select date till which you want the history of transactions
5. Select ticker/token name
6. Hit load register

Also you can download this report by clicking on " Download CSV "

![](https://files.readme.io/0461536-CC.png)

***

## Q: How to reconcile transactions when the transactions didn't show up in Reconcile Tab under Accounting?

### :a::

For the Txns that  transactions didn't show up in Reconcile Tab under Accounting are trades so to reconcile those txns following steps are to be followed  
​

1. Go to Transactions in left-side menu.
2. Go to Trading.
3. Make the page size to 100
4. Select all the transactions in bulk
5. Click Accept.

This will reconcile all your transactions that are under To be Reconciled, that didn't showed up in reconcile tab.

***

## Q:  How do I combine a transaction?

### 🅰️:

Transactions can be combined by following steps given below:  
    a. Go to Transactions and click all transactions.  
    b. Select the transactions that needs to be combined by check marking box on their left.  
    c. After selecting the transactions, Click on Combine and txns will be combined.

***

### Q:   What should I do if I have multiple transactions that need categorization?

### 🅰️:

There are two ways to categorize multiple transactions. Those are listed below:

1. Categorizing  Transactions from transaction UI  
       a. Go to Transactions and click all transactions.  
       b. Select the transactions that needs to be categorized by check marking box on their left.  
       c. After selecting the transactions, Click on Categorize.  
      d. Fill out the contact and cactegory and all selected txns would be categorized.  
   NOTE:- Trade txns cannot be categorized in BULK.

2. Categorizing txns through System Jobs:  
   a. Go to Administration.  
    b. Select System jobs, and hit create job on right hand side.  
    c. seletct the action as Categorize transactions.  
   d. Download the CSV and fill out the txns and contact and category ID and downloas CSV.  
   e. Upload the CSV  
   f. Hit Run.

***

## Q. How do I split a trade transaction?

### 🅰️.

1.Create Manual Transactions:

- Create one manual transaction for the trade itself.
- Create another manual transaction for any associated fees.  
  2.Uncategorize Original Transaction:
- After creating the manual transactions, uncategorize the original transaction that included both the trade and the fee.
- Once uncategorized, you can ignore the original transaction in your records or mark it as reconciled, depending on your accounting or tracking system.

***

## Q: How much time it takes for a wallet to get synced completely?

### :a:

The time that wallet takes to get resync depends on the number of transactions that wallet have:

1. If the transaction count is less , it would take about 2-3 hours for transactions to sync in.
2. If the transaction count is more, it would take atleast 24 hours for transactions to sync in. 

Note: Usually customers are advised to wait 24 hours to get wallet synced in fully.

***

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q: Is it possible to save transaction when you put google sheet in Memo in transaction?

:a:  
       No, you would not be able to save transaction, if you put google sheet link in the Memo of transaction. It would give error while saving.

## Q: Why the manual trade transaction get ignored and gets combined with already ignored onchain transactions?

:a: 

For the import, where the transactions are getting ignored is because of using  same blockchain id as it is onchain, and also if the onchain transaction are ignored , after importing because manual transactions have  same blockchain id, those will also be ignored and get combined with the ignored ones.

To manually import those txns, always use .V1, .V2 respectively at the end of blockchain id, just to differentiate them.

For example : for one blockchain id having trade dispose, trade acquired and trade fees use .V1 , for second having trade dispose, trade acquired and trade fees use .V2 and so on.

## Q: How to Edit Trade transactions that are manually imported?

### :a:We usually cannot edit trade transactions but we have 2 ways to edit the transactions.

​  
First , You can ignore that particular transaction and reupload with the changes that you want to make.  
​  
Second, You can Change the transaction type from trade to standard and then just Select and edit the transaction and then again make it to trade.

***

## Q: What does "Confirm" besides transactions in transaction UI means?

:a:: 

This is part of the inline categorization, if you categorize everything inline there, you can just hit confirm to finish categorization. If you pre-select contact, this will often all be pre-categorized, so all you need to do is hit confirm. In that case, it’ll be blue.

***

​  
​

## Q: How to accept more than 100 trades at a time in bitwave?

### :a:

​In order to accept trades in bulk you can use as **' Mark as reconciled'** feature under system jobs. ( **NOTE -** Please use this feature **only when** you have reconciled all the non trade transactions for the time period you are running the system job for)  
​  
Here is the detailed guide on system jobs to help you create system job in bitwave.  
​<https://docs.bitwave.io/docs/system-jobs-1>  
​  
You can use CSV Bulk Action feature as well which Allows you to mark individual transactions as reconciled by using a csv file. You can find this feature as well under system jobs. ( **NOTE **- this feature can only be used if you have the transaction id's of the trades you are trying to accept or Mark as reconciled

![](https://files.readme.io/e202d1f97fe95b9077d37f422b81150a0578c7e055fc5be4ff33a0d0cc7c1e27-image.png)

***

## Q: How to Un-combine a transaction?

### :a::

Transaction can be un-combined by following steps given below:

<br />

1. Go to Transactions and click all transactions.
2. Select the Transaction that needs to be un-combined by check marking box on their left.
3. After selecting the Transaction, Click on Un-combine and transaction will be un-combined.

![](https://files.readme.io/29e27eda93897f52986d1390cbd9d6e7eff5f77f698894c261d3de0ff22f028f-Screenshot_at_Mar_25_23-46-52.png)

***

<br />

## Q: What causes an uncategorized transaction count in the Inventory Actions Report, but not in the Transactions tab?

:a::

This could be due to: 1 Technical syncing issues. 2 Duplicate or legacy transactions not visible in the Transactions tab but still flagged in Inventory calculations. Please try updating your Inventory Views. If the issue persists, contact support to review and refresh your data.

***

<br />

## Q: What are the blank transactions that show a “Ready to price” status?

:a::

These typically represent transactions with a value of zero. They are safe to ignore as they don’t affect your financial reporting.

***

<br />

## Q: Why is Bitwave not identifying certain transactions as bridges?What are the blank transactions that show a “Ready to price” status?

:a::

Bitwave may not automatically detect bridge transactions if the receiving wallet address is different. Bridges don’t always use the same address across blockchains. If needed, you can manually label these as internal transfers using internal transfer categorization.

***

<br />

## Q: How do I record locked assets or internal transfers from exchange wallets?

:a::

Create a manual wallet in Bitwave and import the transactions as internal transfers. Detailed steps are available in the manual wallet import guide.

***

<br />

## Q:  Why isn’t my manually added transaction showing up under “All Transactions”?

:a:: 

If a transaction you created using the “+” button in the UI isn't appearing, first ensure it's saved correctly and the filters in your view aren’t hiding it. If the issue persists, try refreshing your browser or clearing your cache. If you're still having trouble, please reach out to support with your transaction and wallet details so we can investigate further.

***

<br />

## Q:  How do I combine transactions and mark them as a trade in Bitwave?

:a::

After importing standard deposits/withdrawals: 1: Select the checkboxes for two related transactions. 2: Click Combine. 3: Open the new transaction and select Trade under transaction type, then click Save.

***

<br />

## Q:  My import was successful, but the transaction doesn't appear under "Needs Categorization." Why?

:a::

If your imported transaction isn’t appearing, it may be due to a duplicate blockchain ID. Bitwave requires each transaction to have a unique blockchain ID. Try updating the ID in your import file and reimport the transaction.

***

<br />

## Q:  I’m seeing the error “Transactions with a tradeId must have a trade transaction type.” What causes this?

:a::

This error typically occurs when: 1: A trade ID is assigned, but only one side of the trade is present. 2: Trade transaction types are missing or incorrect. Ensure that each trade includes both acquired and disposed sides and that both share the same trade ID and account ID.

***

<br />

## Q:  Where can I find the correct CSV template to bulk delete transactions in Bitwave?

:a::

To bulk delete transactions, you need to use a specific CSV template available in our documentation. You can find the correct template and instructions here. If you’ve downloaded a different template by navigating through Admin > System Jobs > Run > CSV Bulk Upload, it may not be the one designed for deletions.

***

<br />

## Q:  What should I enter in the "Transaction ID" field when using the bulk delete template?

:a::

You should use the blockchain transaction hash (also known as the blockchain ID) for deleting transactions. These can typically be retrieved from your export report. The internal "ID" column from Bitwave or reference numbers used in import templates are not applicable for deletions.

***

<br />

## Q:  How does Bitwave know which wallet a transaction belongs to when performing a bulk delete?

:a::

Bitwave identifies transactions by their unique blockchain hashes. If a transaction hash appears in more than one wallet, deleting it through the bulk CSV upload will remove it from all wallets it appears in. To avoid unintended deletions, make sure the transaction hashes listed are exclusive to the wallet you intend to modify.

***

<br />

## Q:   I accidentally imported duplicate transactions into two wallets. How can I remove just the duplicates from one wallet without affecting the other?

:a::

If the same transaction hash appears in multiple wallets (e.g., both DEGEN and BASE wallets), a bulk deletion using only the hash may remove it from all instances. In this case, it's safest to manually identify which transactions were manually imported and intended for deletion, and ensure you're not deleting synced transactions from another wallet. If necessary, you can delete and re-sync a wallet to reset its state.

***

<br />

## Q:  My wallet isn’t syncing or showing transactions correctly. What should I do?

:a::

First, try refreshing your browser, sometimes transactions take a moment to display. If that doesn’t help, check if the wallet is set up properly for auto-sync. If you’ve imported transactions manually or the wallet was misconfigured, consider deleting and re-creating the wallet for a clean sync.

***

<br />

## Q:  What should I do if a transaction is missing in Bitwave?

:a::

If you notice a missing transaction in Bitwave, please contact our support team and include your organization name in the message. This helps us locate your account and investigate the issue more efficiently.

***

<br />

## Q:  How should I handle staking and unstaking transactions, like converting OM to sOM and then back to OM?

:a::

When you stake OM and receive sOM, you should treat the sOM as having a cost basis equivalent to the original OM. When you later unstake (convert sOM back to OM), the transaction reflects a gain or loss based on the value difference at the time of conversion. If pricing data isn’t available, you can manually adjust the price using the pencil icon in Bitwave.

***

<br />

## Q:  Some transactions are not recognized as internal transfers. How do I ensure Bitwave correctly identifies internal transfers?

:a::

Both wallets involved in an internal transfer must be added to your Bitwave instance. If one wallet is missing, Bitwave cannot automatically detect it as an internal transfer. Add all relevant wallets to your instance to enable proper recognition.

***

<br />

## Q:  Can I manually adjust the cost basis of a specific transaction, such as a withdrawal from a vesting contract?

:a::

Yes, you can manually adjust the cost basis by editing the transaction in the UI. Simply click the pencil icon next to the cost basis field and update the value as needed.

***

<br />

## Q:  Why do some imported transactions not appear in the “All Transactions” tab?

:a::

Some transactions may be in an "ignored" state by default. You can locate and unignore these transactions by searching their IDs in the UI, filtering for ignored transactions, selecting them, and choosing "unignore" under More Actions.

***

<br />

## Q:  Why are some of my Solana transactions not showing up in Bitwave?

:a::

Sometimes transactions on Solana or other blockchains may not immediately appear in Bitwave due to sync delays or missing wallet details. To help us investigate, please provide your organization name and ID, wallet ID (if applicable), and transaction IDs.

***

<br />

## Q:  What should I do if I notice missing transactions in my Bitwave account after syncing?

:a::

If you notice missing transactions, first ensure your wallet is properly connected and synced. If the problem persists, contact Bitwave support with relevant details (organization info, wallet ID, transaction IDs) for further investigation.

***

<br />

## Q:  Why am I seeing an error message when categorizing a transaction that combines a manual deposit and an on-chain withdrawal?

:a::

This error typically occurs when a manual "deposit/acquired" transaction is recorded after the corresponding "withdrawal/disposed" transaction. Bitwave requires that acquisitions occur before disposals to ensure accurate tracking. To resolve this, delete the manual deposit transaction and re-create it with the same amount and ticker, ensuring it is dated just before the withdrawal. Then, combine the two transactions and categorize them as a trade.

***

<br />

## Q:  How do I fix the “Disposals before the Acquisitions” error?

:a::

To fix this error, delete the manual deposit/acquired transaction that was added after the disposal. Then, re-enter the deposit transaction with the correct date (before the disposal). Once both transactions are correctly ordered, you can combine them and categorize the result as a trade.

***

<br />

## Q:  Some transactions from my Coinbase Retail wallet aren’t showing up what should I do?

:a::

If transactions (e.g., outgoing SOL) are missing from your Coinbase Retail wallet view, please export your full transaction history from Coinbase and send it to us. CSV format is preferred. Our team will review and follow up with any next steps.

***

<br />

## Q:  How do I confirm which Exchange wallet is affected when reporting missing transactions?

:a::

If you're unsure, feel free to confirm by sending a screenshot or identifying details of the wallet. This helps us ensure we’re troubleshooting the correct account (e.g., distinguishing between Coinbase Retail and Coinbase Exchange).

***

<br />

## Q:  Does the FMV field show the value as of today or the transaction date?

:a::

The FMV (Fair Market Value) shown is based on today’s date, not the transaction date.

***

<br />

## Q:  What should I do if Bitwave's system seems stuck when trying to uncombine transactions?

:a::

Sometimes the system may take a few moments to process uncombine actions. If a transaction remains in a pending state for too long, please share the transaction ID with us so we can troubleshoot and assist directly.

***

<br />

## Q:  Why does my Wallet show a negative balance even though transactions should net to zero?

:a::

This can occur if the first recorded transaction in a wallet is a withdrawal without a preceding deposit. It’s essential to ensure all deposits are present. If all transfers were internal and should net to zero, we can help adjust or recreate the correct entries.

***

<br />

## Q:  How should I handle large transactions to liquidity pools, such as the transaction?

:a::

For those transactions (e.g., 127 ETH to a liquidity pool), we may recommend creating a separate manual wallet to track these properly. Our team will guide you on the best approach depending on recoverability and reporting requirements.

***

<br />

## Q:  What should I do if I’m unsure whether to track a liquidity pool transaction manually or through API?

:a::

For large or complex transactions like liquidity pool activity or time-locked exchange deposits, our team can advise whether to use a manual wallet or API integration. Please share the transaction details with us for specific guidance.

***

<br />

## Q:  How should I handle transactions that move funds from Coinbase Exchange to Coinbase Retail in Bitwave?

:a::

If funds are first sent from Coinbase Exchange to Coinbase Retail before being paid to vendors, these should be categorized as Internal Transfers. This helps accurately reflect the movement of funds within your organization.

***

<br />

## Q:  Bitwave is not showing the option to treat a transaction as an Internal Transfer. What should I do?

:a::

If the Internal Transfer option isn't appearing for individual transactions, you’ll need to manually select and combine the relevant transactions in the Bitwave UI. Once selected as a pair (outgoing and incoming), you can then categorize the combined transaction as an Internal Transfer.

***

<br />

## Q:  How can I ensure that all transaction fees for trades and transfers flow into my preferred accounting category in Bitwave?

:a::

To have all transaction fees flow into your chosen account (e.g., "Other Expenses:Blockchain Transaction Fees"), first verify that this account is set as your default fee category in Bitwave. Additionally, check if your organization is configured to capitalize fees, as this setting can affect how fees are categorized. Make sure to enable the "Allow Transaction Inference" option, which allows Bitwave to record gas fees correctly under the specified contact category.

***

<br />

## Q:   What does the "capitalize fees" setting in Bitwave mean, and how does it affect my transaction fees?

:a::

The "capitalize fees" setting means that instead of immediately expensing transaction fees, the fees are added to the cost basis of the asset. This impacts which account the fees are posted to in your accounting system. If you want fees to flow directly to an expense account like "Other Expenses:Blockchain Transaction Fees," review this setting and adjust if necessary.

***

<br />

## Q:   What is the "Allow Transaction Inference" checkbox, and why do I need to enable it?

:a::

The "Allow Transaction Inference" option enables Bitwave to automatically identify and record new gas fee transactions using your chosen contact category. Enabling this setting ensures that transaction fees such as gas fees on blockchain transfers are properly tracked and categorized in your accounting.

***

<br />

## Q:   My transaction fees are appearing in the "Bitwave - Crypto Fees" account instead of my specified expense account. How can I fix this?

:a::

This usually happens if your organization’s fee settings or transaction inference options are not configured correctly. Confirm that your default fee category is set to your preferred expense account, check if fee capitalization is enabled, and make sure the "Allow Transaction Inference" option is checked to route fees properly into your accounting system.

***

<br />

## Q:  What happens if I accidentally use the same transaction ID for different transactions?

:a::

Using the same transaction ID across different uploads can cause syncing issues, such as transactions disappearing or not matching correctly. It’s best to use unique transaction hashes or IDs when manually importing transactions.

***

<br />

## Q:  I uploaded withdrawal transactions manually, and now my synced deposits are missing what should I do?

:a::

This may occur if manually imported transactions share the same transaction hash as synced ones. In such cases, you can delete the problematic transactions and request a resync. Afterward, reimport the manual transactions using different (unique) transaction hashes.

***

<br />

## Q: Why is my wallet balance not updating after uploading transactions?

:a::

The Wallet & Connections tab may take some time to reflect recent changes, even if the Balance Report is correct. If your Balance Report shows accurate data, rest assured the dashboard will sync shortly.

***

<br />

## Q: How can I check if transactions were ignored during syncing to ERP?

:a::

You can check the "Ignored" tab in Bitwave to see if any transactions were skipped during syncing. This is often where unmatched or duplicate transactions are sent.

***

## Q: Will missing tokens affect how transactions are categorized in Bitwave?

:a::

Yes, accurate token recognition is essential for correct transaction categorization, including coin type, quantity, and trade type. If a token is missing, please alert our team so we can ensure your transaction history is complete and accurate.

***
