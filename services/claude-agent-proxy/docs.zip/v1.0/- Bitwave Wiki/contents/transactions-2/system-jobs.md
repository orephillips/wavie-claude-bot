---
title: "System Jobs"
slug: "system-jobs"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 03:59:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 04:04:31 GMT+0000 (Coordinated Universal Time)"
---
System Jobs allows the user to modify transactions at scale using custom actions.

<p><span style="color: rgb(209, 72, 65);"><strong><span style="font-size: 18px;">WAIT! THIS FUNCTION IS TO BE USED WITH CAUTION. Please note you are not able to undo a job after it begins.</span></strong></span></p>

<ol>
    <li style="list-style-type: decimal; font-size: 16px;">
        <p>Go to <strong>Administration</strong></p>
    </li>
    <li style="list-style-type: decimal; font-size: 16px;">
        <p>Go to <strong>System Jobs</strong></p>
    </li>
    <li style="list-style-type: decimal; font-size: 16px;">
        <p>Click on <strong>Create Job</strong></p>
    </li>  

</ol>

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/56b54e4-10000.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


![](https://files.readme.io/214c528-Screenshot_2024-03-08_235141.png)

![](https://files.readme.io/29bc982-Screenshot_2024-03-08_235153.png)

<p><span style="font-size: 16px;"><br></span></p>
<p><span style="font-size: 16px;">Types of Actions (and requirements):</span></p>
<ul>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Delete Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Ignore Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Mark transactions as Reconciled</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Reconcile Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Categorize Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Upload CSV</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Uncategorize Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>Unignore Transactions</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Wallet</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Date</p>
            </li>
        </ul>
    </li>
    <li style="list-style-type: disc; font-size: 16px;">
        <p>CSV Bulk Action: Allows you to Update individual transactions using a csv file. HERE IS THE&nbsp;<a href="https://docs.google.com/spreadsheets/d/1B3nxxstUEK9g39Q2nEjc1CU6j5HLJggocf76J87Rk8g/edit?usp=sharing"><u><span style="color: rgb(17, 85, 204);">TEMPLATE</span></u></a>. The available actions are&nbsp;</p>
        <ul style="font-size: initial;">
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Delete Transactions</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Ignore Transactions</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Mark transactions as Reconciled</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Reconcile Transactions</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Categorize Transactions</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Uncategorize Transactions</p>
            </li>
            <li style="list-style-type: circle; font-size: 16px;">
                <p>Unignore Transactions</p>
            </li>
        </ul>
    </li>
</ul>

***

***

***

***
