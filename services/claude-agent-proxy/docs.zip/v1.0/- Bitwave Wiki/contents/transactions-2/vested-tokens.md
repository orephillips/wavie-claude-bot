---
title: "Vested Tokens"
slug: "vested-tokens"
excerpt: "How do I account for vested tokens in Bitwave?"
hidden: false
createdAt: "Fri Jun 28 2024 15:33:11 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 16:16:47 GMT+0000 (Coordinated Universal Time)"
---
Option 1 Use Account Transfer: 

Transactions for fully vested tokens that are synched from on chain or imported can be categorized as Account Transfer. When categorizing as Account Transfer an Asset type category must be selected in the Transfer From dropdown. The example below credits Account Receivable to close the open balance, assuming the accounting system has an existing entry that debited AR for the tokens receivable. 

![](https://files.readme.io/5b486bc-image.png)

The cost basis of the token receivable is updated in the External Costs Basis screen under Accounting in the left pane. Use the edit button to open the Edit External Tax Details screen and edit the Acquisition Cost and Acquisition Date.

![](https://files.readme.io/432fa1f-image.png)

The Balance Report will continue to show the assets in the portfolio balance as of the on chain transaction date.

![](https://files.readme.io/96e92bd-image.png)

Inventory View reporting will show the asset acquired using the date and cost edited in the External Cost Basis screen.

![](https://files.readme.io/b5ba1f5-image.png)

\*\*Note that this difference in timing will result in a variance in the reconciliation workbook.

Option 2 Use a Manual Wallet:

A manual wallet can be created for locked token transactions manually entered or imported into Bitwave at acquisition cost and on the date of the start of the vesting schedule. 

![](https://files.readme.io/334ce87-image.png)

The example below categorizes to an clearing account, assuming the accounting system has an entry that credits the consideration given to enter into the vesting agreement.

![](https://files.readme.io/6976588-image.png)

The vested token inflows that are synched from on chain or imported will need a matching outflow from the locked token manual wallet. The inflow and outflow will be combined in order to categorize as an internal transfer.

![](https://files.readme.io/d58436c-Screenshot_2024-06-28_at_11.55.19_AM.png)

![](https://files.readme.io/78406c0-image.png)

All reporting will show the locked tokens in the portfolio balance. Since they will be in their own wallets, the locked token balance and fully vested token balances will be separate.

\*\*Note that Wallet Level Inventories may be required if additional tokens are acquired before all tokens have been fully vested. Without separate inventories, the locked tokens will be pickable for disposals.

Option 3 Use DeFi Module:

A DeFi wallet can be created for locked token transactions manually entered or imported into Bitwave at acquisition cost and on the date of the start of the vesting schedule. As a best practice the wallet address were the fully vested tokens will be received and the token address can be used in the wallet's configuration.

![](https://files.readme.io/919bf45-image.png)

The example below categorizes to an clearing account, assuming the accounting system has an entry that credits the consideration given to enter into the vesting agreement.

![](https://files.readme.io/6976588-image.png)

Categorizing the vested token inflows that are synched from on chain or imported as Advanced DeFi will automatically create the matching outflow from the locked token DeFi wallet.

![](https://files.readme.io/22c6e24-image.png)

All reporting will show the locked tokens in the portfolio balance. Since they will be in their own wallets, the locked token balance and fully vested token balances will be separate.

\*\*Note that Wallet Level Inventories may be required if additional tokens are acquired before all tokens have been fully vested. Without separate inventories, the locked tokens will be pickable for disposals.
