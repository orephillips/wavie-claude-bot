---
title: "Txn UI vs System Jobs"
slug: "txn-ui-vs-system-jobs"
excerpt: ""
hidden: true
createdAt: "Fri Jun 28 2024 15:27:41 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 15:27:41 GMT+0000 (Coordinated Universal Time)"
---
