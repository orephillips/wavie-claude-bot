---
title: "How do I account for tokens staked on an exchange?"
slug: "how-do-i-account-for-tokens-staked-on-an-exchange"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 16:52:17 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 21:46:26 GMT+0000 (Coordinated Universal Time)"
---
By default tokens staked on an exchange will show in Bitwave as disposals and incur gain/loss. A DeFi wallet can be created in order to track the staked assets as part of portfolio balance and show the outflows in Bitwave as transfers.

![](https://files.readme.io/add589c-image.png)

Categorizing the staked assets outflow as Advanced DeFi will automatically create the inflow into the DeFi wallet.

![](https://files.readme.io/41045d9-image.png)

Categorizing the unstaked assets inflow as Advanced DeFi will automatically create the outflow from the DeFi wallet.

![](https://files.readme.io/421fab6-image.png)

The difference between what was staked and unstaked will be a manual entry categorized to revenue.

![](https://files.readme.io/556b1a3-image.png)
