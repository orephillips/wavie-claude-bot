---
title: "Locking Periods"
slug: "locking-periods"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 04:18:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 17:22:12 GMT+0000 (Coordinated Universal Time)"
---
**Locking Periods in Bitwave**

Ensuring the integrity and accuracy of financial transactions is paramount in any accounting system. In Bitwave, one way to safeguard transaction records is by implementing period locking. This feature allows users to restrict modifications to transactions within a specified period, providing a safeguard against accidental deleting or ignoring transactions. Once transactions are locked, you cannot alter them, and no new transactions will sync into Bitwave during the locked period.

> 🚧 Please note all transactions within your Lock Period must be Categorized

<br />

Let's explore how to lock a period in Bitwave:

**How to lock a period:**  
● **Navigate to Accounting:** Begin by accessing the accounting section located on the right-hand side of the application.

![](https://files.readme.io/2e40581-Screenshot_2024-03-03_at_6.07.04_AM.png)

● Locate “**Period End Close**”

![](https://files.readme.io/cd1214a-Screenshot_2024-03-03_at_6.08.20_AM.png)

● Click on **Enable Transaction Locking**

![](https://files.readme.io/0a2cd98-Screenshot_2024-03-03_at_6.09.49_AM.png)

● **Set Lock Date:** Specify the end date for the period you wish to lock. For example, if you intend to  
lock transactions up to December 31, 2023, enter this date accordingly.

![](https://files.readme.io/5a66698-Picture1.png)

● **Save Changes:** After entering the desired lock date, click "Save" to apply the changes.

![](https://files.readme.io/d1f151f-Screenshot_2024-03-03_at_6.13.49_AM.png)

● **Confirm Locking:** To confirm that transactions are successfully locked, navigate to the transaction overview. Locked transactions will be indicated by a small lock icon next to them.

![](https://files.readme.io/2ea3559-Screenshot_2024-03-03_at_6.18.01_AM.png)

_**Period locking often aligns with the closing of accounting periods, ensuring that financial data remains static for reporting purposes**_

***

**Unlocking and Modifying Period Locks:**

Should the need arise to unlock a period or modify the lock date, users can easily manage these settings within the  
Bitwave platform:

● **Navigate to Accounting**: Begin by accessing the accounting section located on the right-hand side of the application.

![](https://files.readme.io/9ea7548-Screenshot_2024-03-03_at_6.07.04_AM.png)

● Locate “**Period End Close**”

![](https://files.readme.io/c13d0ba-Screenshot_2024-03-03_at_6.08.20_AM.png)

● Click **Unlock All**

![](https://files.readme.io/6824e71-Screenshot_2024-03-03_at_6.29.39_AM.png)

● Click “**Confirm**” to Unlock transactions

***

● **Editing Lock Date:**

Similarly, users can edit the lock date by accessing the period close settings and adjusting the specified date as needed. Remember to save changes after editing the lock date.

**_Note that transactions with uncategorized or unignored statuses cannot be locked in Bitwave. Ensure all transactions are appropriately categorized or ignored before implementing period locks._**
