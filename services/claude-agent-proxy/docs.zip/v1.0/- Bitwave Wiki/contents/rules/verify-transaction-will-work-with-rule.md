---
title: "Verify Transaction Will Work with Rule"
slug: "verify-transaction-will-work-with-rule"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:59:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 11 2024 01:15:34 GMT+0000 (Coordinated Universal Time)"
---
How to Validate that the Rule will have an affect on the Transaction?

1. Copy the Transaction Id. (Find the transaction ID in Transactions -> All Transactions -> Search for your Transaction)
2. Go to your recently Created Rule. (Find rule in Transactions -> Rules -> Search for your Rule)
3. Click on the Pencil on the right side.

![](https://files.readme.io/3c710eb-image.png)

4. Scroll Down to where it says "Transaction ID". Populate the search box with your Transaction ID

![](https://files.readme.io/a66e6fc-image_6.png)

5. Click Validate Changes.
6. If your Transaction ID was not valid then reconfigure your rule.

![](https://files.readme.io/69ca18d-Screenshot_2024-03-21_221715.png)

![](https://files.readme.io/3ed0286-Screenshot_2024-03-21_221825.png)

7. Click Save.
8. Refresh the page.
9. Then populate your transaction ID again.
10. Click Validate Changes.
11. Repeat process, until you reached a successful validation.

![](https://files.readme.io/6636efd-image_8.png)

***

***

***

***
