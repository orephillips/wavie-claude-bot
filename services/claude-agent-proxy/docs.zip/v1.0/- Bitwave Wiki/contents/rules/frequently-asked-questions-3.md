---
title: "❓FAQs"
slug: "frequently-asked-questions-3"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:08:24 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 30 2025 18:53:28 GMT+0000 (Coordinated Universal Time)"
---
## Q: How do I disable rule(s)?

### :a::

- Start by navigating to the Transactions section in the left menu of your Bitwave dashboard.
- From the Transactions menu, select the Rules sub-menu. This will direct you to the Rules screen, displaying a list of all your existing rules.
- Once on the Rules screen, locate the "Select All" checkbox positioned at the top left corner of the screen. Check this box to select all rules listed.
  - Optionally, you may also select individual rules instead.
- Next, click on the "Actions" button located in the top right corner of the screen. A drop-down menu will appear. Select the "Disable" option from this menu.
- This action will deactivate the selected rules in your organization, temporarily halting automated categorization for those rules.

## Q: How do I enable rule(s)?

### :a::

- Start by navigating to the Transactions section in the left menu of your Bitwave dashboard.
- From the Transactions menu, select the Rules sub-menu. This will direct you to the Rules screen, displaying a list of all your existing rules.
- Once on the Rules screen, locate the "Select All" checkbox positioned at the top left corner of the screen. Check this box to select all rules listed.
  - Optionally, you may also select individual rules instead.
- Again, click on the "Actions" button located at the top right corner of the screen, but this time select the "Enable" option from the drop-down menu.
- This action will activate the selected rules in your organization, temporarily halting automated categorization for those rules.

## Q: How do I troubleshoot a rule not working for categorized transactions in Bitwave

### :a::

Follow these steps to troubleshoot:

- Clear cache and cookies for the Bitwave page, then log out and log back in.
  - Ensure the rule direction is filled out when creating the rule.
    - Run the rule by selecting it, clicking on "Actions" on the right side, and then clicking on "Run."
      - If the rule processes successfully but doesn't apply, try refreshing the page and running the rule again.
        - Ensure transactions include a description.
          - If issues persist, contact Bitwave support for further assistance.

## Q: Can a rule run successfully without the token get priced in the transactions?

:a::  Yes, the rule can be run successfully without the token get priced in Bitwave. You need to enable the “Ignore Fail Pricing” while setting up the rule. **However note. this means that any transactions for which we "Ignore Fail Pricing" would result in that transaction**being priced at $0 fair market value. If that is not your intention then it means that Bitwave has failed to price a token you expect to be priced. You should reach out via our bitwave chat to request the token be priced.

***

<br />

## Q: How do I automatically categorize trades and gas fees as "crypto fees"?

:a::

<br />

"You can set up categorization rules for trades and gas fees by following these video guides:

Trade Categorization Rule Setup : <https://docs.bitwave.io/docs/set-up-categorization-rules#3-trade-transactions-rule>  
Gas Fee Rule Setup : <https://docs.bitwave.io/docs/set-up-categorization-rules#3-trade-transactions-rule>

Be sure to check the ""Include Fee Categorization"" box when setting up trade rules to ensure fees are included."

***

<br />

## Q: Why is the advanced categorization option greyed out in my rules setup?

:a::

This may be due to a caching issue. Try performing a hard refresh of your browser and clearing your cache and cookies. If the problem persists, reach out to our support team for assistance.

***

<br />

## Q: How long does it take for categorization rules to apply to transactions?

:a::

Processing time depends on the volume of transactions. If you have a large number of entries, it may take a little while for the rules to fully apply.

***

<br />

## Q: How can I create rules to automatically categorize transaction fees and gas fees?

:a::

Bitwave supports creating trade rules to automatically categorize fees such as "crypto fees" for both trade fees and contract execution (gas) fees. To do this, use the rule creation feature under categorization rules. If the advanced categorization option is greyed out, try clearing your browser cache and cookies, then refresh.

***

<br />

## Q: Should I enable the option to include fee categorization when setting up trade rules?

:a::

Yes, selecting the option to include fee categorization ensures that associated fees are also properly categorized when trades are processed.

***

## Q: Why isn’t my rule applying to transactions having fees I believe it should match?

:a::

One common reason rules don’t apply is if transaction fees are included but the rule doesn’t account for them. Make sure to check the "Categorize Fees" option in your rule settings. This will ensure the rule matches transactions that include fees.

***

## Q: What should I do if my rule isn’t working due to missing price data for a token?

:a::

If a transaction involves a token that doesn’t have pricing data, the rule may not apply. To resolve this, you can either update the pricing for that specific ticker or enable the “Ignore Fail Pricing” option in your rule. This allows the rule to categorize the transaction even if pricing data is missing.

***

## Q: I created a categorization rule, but my transactions are still uncategorized. Is there a delay?

:a::

Yes, due to high volume, it may take some time for rules to process and apply to transactions. Please allow some time, then refresh to see the updates.

***

<br />

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]
