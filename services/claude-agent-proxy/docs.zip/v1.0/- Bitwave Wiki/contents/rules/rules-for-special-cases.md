---
title: "Rules for Special Cases"
slug: "rules-for-special-cases"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 01:02:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 19:03:15 GMT+0000 (Coordinated Universal Time)"
---
## How to Set Up Detailed Rules for Vendor Payments

> NOTE: This guide assumes a general understanding of rule creation in Bitwave. For general rule creation steps, follow the steps listed [here](https://docs.bitwave.io/docs/how-to-use-rules).
>
>  NOTE: it is recommended that you first begin by setting up the desired rule and apply it to a small time frame (such as a day or two). This is to test and ensure that the rule works as intended before applying it to all transactions that fall within the rule’s parameters.

### Step 1: Navigate to the Rules Screen

1. Navigate to Transactions > Rules in the Bitwave application
2. Click the “Create Rule” button

### Step 2: Set up the Rule

1. Name the rule and set priority
2. Point the rule to a particular wallet
3. Specify a token for the rule
4. Change the categorization to “Detailed Categorization”
5. Click “Add Line” at the bottom of the rule creation page. This will add a detailed line to the rule creation
   1. Select “Amount” for Value Extractor
   2. Select “COIN” for Asset Extractor
   3. Specify the address you are paying to or are receiving payment from in the Qualifier Extractor section
      1. Use this format to categorize disposals:
         ```
         txnLineTo == 0x0000...
         ```
      2. Use this format to categorize additions:
         ```
         txnLineFrom == 0x0000...
         ```
   4. Select a category for the transaction
   5. Select a vendor for who you are paying
   6. Set the direction for the rule to “All”

<!----->

9. Repeat step 2(5) as many times as needed to create the desired rule

> NOTE: This rule works for any combination of sending to the addresses specified in the rule.  
> ex. You specify 10 addresses in 1 rule related to USDC payments from wallet 0xExample.  
> Any payment related to those 10 addresses in USDC from 0xExample will be categorized according to the detailed rule.

1. A tx paying 8 of the addresses, a tx paying 5 of the addresses and a tx paying 1 of the addresses will all be categorized.
2. A tx paying 10 of the addresses and an additional unspecified address would remain uncategorized.

### Step 3: Save the Rule

Click “Save” at the bottom of the rules creation page
