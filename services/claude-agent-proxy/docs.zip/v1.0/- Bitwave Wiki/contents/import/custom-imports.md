---
title: "Custom Import Transforms"
slug: "custom-imports"
excerpt: "Import Raw Transaction Data Directly into Bitwave"
hidden: false
createdAt: "Thu Apr 11 2024 01:04:04 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 21:21:50 GMT+0000 (Coordinated Universal Time)"
---
Importing Raw Data Directly into Bitwave

What it is/definition  
A Custom Import Transform imports your raw transaction history into Bitwave without having to create a standard manual import.

Below is a sample spot order transaction export:

![](https://files.readme.io/e7ec179-image.png)

To convert this into a manual import requires splitting each action in a trade onto its own line, turning 1 line of KuCoin data into 3 individual lines on the Bitwave manual import template.

![](https://files.readme.io/3e95894-image.png)

The Custom Import Transform maps the original raw .csv data to the correct fields to import into Bitwave without manual manipulation. If you have large data sets or frequent activity on an unsupported chain or exchange the Transform will save time, reduce errors, and increase efficiency.

To find our current Custom Import Transforms, go to Transactions --> Import Advanced --> New Import

![](https://files.readme.io/232b8da-image.png)

Keep File Import as Type, then click the dropdown under File Type for a list of our active Transforms. 

![](https://files.readme.io/92756f9-image.png)

Select the Transform, download the sample file, then select the Bitwave account you would like to import to from the Accountid dropdown.

![](https://files.readme.io/e7ab049-image.png)

Open the Sample File, copy the top header and paste it on your raw data sheet - this will remove any potential special or hidden characters that may be in the raw .csv file.

![](https://files.readme.io/f1cdb6c-image.png)

Save your raw .csv file with the new header and select Next.

Click on Choose File, select your raw .csv, then click Upload

![](https://files.readme.io/c110a9f-image.png)

Once the file is uploaded click Generate Preview.

Follow the prompt to Validate and Import in Advanced Manual Import

<https://docs.bitwave.io/docs/advanced-manual-import>

To request a Custom Import Transform - please reach out to your Solutions Specialist.
