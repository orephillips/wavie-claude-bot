---
title: "❓FAQs"
slug: "frequently-asked-questions-2"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:55:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 15:01:23 GMT+0000 (Coordinated Universal Time)"
---
> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q : How can I verify that my transactions have been successfully imported and are visible in Bitwave?

### :a: : To check if the transactions are successfully imported into your bitwave instance, you can come to import page and check the status. If it says complete, check the wallet you imported the transactions into. The transactions should show in there.

![](https://files.readme.io/087976e-1.png)

Q: How do i import trades?

🅰️: Please refer to the [following article with full details](https://docs.bitwave.io/docs/importing-trades)

***

<br />

## Q : Why did I receive a “Data Upload Failed” error when importing a upload file to the wallet?

:a::

This error typically indicates a temporary server issue. Try clearing your browser cache and reattempting the upload. If the issue persists, please share the file with our support team so we can investigate further.

***

<br />

## Q : How do I import transactions with categorizations into Bitwave?

:a::

You can follow this documentation on manual imports. Make sure to use the provided template and include categorization data in the appropriate fields.

***

<br />

## Q : I’m importing transactions into Bitwave, but I keep getting an error that a trade must include two transactions. What does that mean?

:a::

Each trade must include both sides of the transaction (buy and sell). If your import file includes only one side or uses unique Trade IDs, it will error out. You can: 1) Remove the Trade IDs and import as regular transactions. 2) Then, manually combine and categorize them as trades in the Bitwave UI.

***

<br />

## Q : Why am I getting errors even though my data was validated during upload?

:a::

"Common causes include: 1: Incorrect date format (must be YY:MM:DD HH:MM:SS) 2: Missing seconds in timestamps. 3: Non-unique IDs. 4: Inconsistent account IDs across trade transactions.  
Review your import file carefully before uploading."

***

<br />

## Q : What is the difference between the Standard Import and Advanced Import features?

:a::

The Standard Import allows basic transaction imports, while the Advanced Import provides more detailed categorization options and additional fields for better control. Use the Standard Import for simple uploads and Advanced Import for more complex data handling.

***

<br />

## Q : Why am I receiving an unclear error message when trying to manually import transactions?

:a::

This error often occurs due to issues in the import file, such as missing data, duplicate transaction IDs, or incorrect amounts. Please check that all required fields are filled, transaction IDs are unique or grouped properly, and amounts include fees where applicable.

***

<br />

## Q : What should I do if my import file contains duplicate transaction IDs?

:a::

If your file has duplicate transaction IDs, Bitwave will overwrite the older transactions with the new ones. To record multiple transactions under the same ID, use the "groupID" column and assign the same groupID to those transactions.

***

<br />

## Q : How do I handle transactions with zero amounts but associated fees in my import file?

:a::

For transactions with zero amounts but fees, enter the fee amounts in the "amount" column to ensure they are recorded correctly.

***

<br />

## Q : I received an error when importing transactions for a new token. What does that mean?

:a::

This usually happens when the token ticker is not yet recognized in Bitwave. Once the token or a placeholder version (e.g., "ALLO-100") is created in the system, you’ll be able to import transactions using the new ticker.

***

## Q: What should I do if Bitwave doesn’t support a blockchain I use?

:a::

If Bitwave doesn’t support a particular blockchain, you can manually import your transaction data to ensure complete reporting. We recommend reviewing our blockchain integrations list first to confirm support status.

***
