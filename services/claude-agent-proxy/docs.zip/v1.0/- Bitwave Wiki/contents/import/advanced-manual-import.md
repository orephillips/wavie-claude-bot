---
title: "Advanced Manual Import"
slug: "advanced-manual-import"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:54:02 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Jun 12 2024 16:29:03 GMT+0000 (Coordinated Universal Time)"
---
> ❗️ FOR TRADES USE [STANDARD IMPORT](https://docs.bitwave.io/docs/manual-import). DO NOT USE IMPORT ADVANCED

1. Go to Transactions -> Import Advanced -> Click on New Import.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/60f85ad-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. We offer multiple types of imports. The standard import file is called “Bitwave Standard Transaction”.  
   Choose this option and click on “Download Sample File”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b55c7c7-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e39005d-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. After opening the sample file, delete all rows except the first row (Header Row). Your file should look like this

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1e02350-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a987a1a-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Please use this guide to create your import file:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ae6eb35-Green_Clean_and_Contemporary_Employee_Handbook_Training_Manual_Booklet-pages.jpg",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Now that your file is ready to import go back to Step 2, and click on “Next”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/502ba2b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Click on “Choose File” then after you picked your file, click on “Upload”.  
   After your file is finished uploading, click on “Generate Preview”.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/16b929c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


7. This is a preview of your data. Click on “Validate"

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c4a5a04-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


8. On the “Validate” step, this will tell you if any issues or errors are found (Highlighted in RED). Using the column,  
   “StatusText”, you are able to decipher the problem. Using the Tips given in Step 4, find the fix. If file is has no  
   failing transactions then click on “Run Import”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eea3ee6-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/35b3edc-10.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


9. Your file has Imported! Confirm on the Transactions page that the number of  
   transactions matches your import file.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e0b3c61-11.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


**Import Data from External sources**

<https://www.youtube.com/watch?v=civlHNiMXQw>

**Some Common Errors while Uploading**

[\<https://www.loom.com/share/a74b51e1fbdf46639d26e880f7139edf>](https://www.loom.com/share/a74b51e1fbdf46639d26e880f7139edf)
