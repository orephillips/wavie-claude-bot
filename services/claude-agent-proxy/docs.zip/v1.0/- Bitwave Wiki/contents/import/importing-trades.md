---
title: "Importing Trades"
slug: "importing-trades"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 15:25:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 16:16:31 GMT+0000 (Coordinated Universal Time)"
---
**Pre-requisite: **

The following article assumes the reader has reviewed [this article ](https://docs.bitwave.io/edit/manual-import)which covers how to import transactions within bitwave. Its important to review that article to set the context for importing a special type of transaction known as trades.

There are two approaches for importing trades into bitwave

**APPROACH 1: Importing Trades using the TradeLabel and TradeID approach**

It is often easiest to simply look at a correctly filled out example and copy and replicate that:

- A correctly filled out example can be found [at this link](https://docs.google.com/spreadsheets/d/1Y-ADZtWRSEffVdubNyog2im9HzoKnFsUgI8gJFzhVco/edit?gid=782148645#gid=782148645)
- Below is an image of a correctly filled out example

  - [block:image]{"images":[{"image":["https://files.readme.io/c027c90-image.png",null,""],"align":"center","sizing":"10000px"}]}[/block]

    <br />

Importing a trade in Bitwave requires the creation of a minimum of 2 rows in the import template and each row MUST include a  shared TRADE ID. For each individual trade, the user has to:

1. Create at least 1 TRADE ACQUIRE row (REQUIRED) (transaction Type column = tradeAcquire)
   1. This row represents the asset or assets being acquired in the trade. For example if a user bought 1 BTC for 45000 USD... then the Trade Acquire side is 1 BTC
   2. Note that you can have more than one trade acquire row
2. Create at least 1 TRADE DISPOSE row (REQUIRED) (transactionType column = tradeDispose)
   1. This row represents the asset or assets being disposed in the trade. For example if a user bought 1 BTC for 45000 USD... then the Trade Dispose side is 45000USD
   2. Note that you CAN have more than 1 trade dispose row
3. Create a no more than 1 TRADE FEE row (OPTIONAL) (transactionType column = tradeFee)
   1. This is a seperate row of its own
   2. This row represents the fee associated with the trade in question if one exists. For example if a user bought 1 BTC for 45000 USD and paid a $45 fee.. the the trade fee side is 45 USD.
   3. Note that you CANNOT have more than 1 trade fee row
4. Other requirements

   1. Filling out the fields (Please refer to the [following documentation ](https://docs.google.com/spreadsheets/d/1Y-ADZtWRSEffVdubNyog2im9HzoKnFsUgI8gJFzhVco/edit?gid=18273097#gid=18273097)which shows the screenshot below in depth.

      1. ![](https://files.readme.io/698efb7-image.png)

         Note that TradeID Must be completed
      2. Note that blockchainID must be left blank
      3. Note that cost and cost ticker must be left blank
      4. Group ID must be left blank
      5. Time of all 3 rows must match
5. Example

   1. Please refer to the following template for [an example of uploading a trade using tradelabels](https://docs.google.com/spreadsheets/d/1Y-ADZtWRSEffVdubNyog2im9HzoKnFsUgI8gJFzhVco/edit?gid=782148645#gid=782148645)

      1. ![](https://files.readme.io/2c66d40-image.png)

         <br />

**APPROACH 2: Importing Trades using deposit and withdrawal approach**

It is often easiest to simply look at a correctly filled out example and copy and replicate that:

- A correctly filled out example can be found [at this link](https://docs.google.com/spreadsheets/d/1Y-ADZtWRSEffVdubNyog2im9HzoKnFsUgI8gJFzhVco/edit?gid=782148645#gid=782148645)
- Below is an image of a correctly filled out example
- ![](https://files.readme.io/7d1daf2-image.png)

  <br />

Importing a trade in Bitwave using this approach is identical to importing a standard transaction. It requires the creation of a minimum of 2 rows in the import template and each row MUST include a GROUP ID

1. Create at least 1 deposit row (REQUIRED)
   1. This row represents the asset or assets being acquired in the trade. For example if a user bought 1 BTC for 45000 USD... then the deposit side is 1 BTC
2. Create at least 1 withdrawal row (REQUIRED)
   1. This row represents the asset or assets being disposed in the trade. For example if a user bought 1 BTC for 45000 USD... then the withdrawal side is 45000USD
3. With regard to the FEE the fee must be placed in the FEE and FEE TICKER column of the withdrawal row
   1. This is NOT a seperate row.. the amount is placed in the FEE and FEE ticker columns of the withdrawal row
4. Fields
   1. Note that the GROUP ID field MUST be populated
   2. Note that the fee is not entered as a seperate row but instead is entered into the fee and fee ticker coluns
   3. Blockchain id must be left blank
   4. Account id for all rows must be the same
   5. Cost and cost ticker should be blank
5. Example

   1. Please refer to the following template for [an example of uploading a trade using tradelabels](https://docs.google.com/spreadsheets/d/1Y-ADZtWRSEffVdubNyog2im9HzoKnFsUgI8gJFzhVco/edit?gid=782148645#gid=782148645)
   2. ![](https://files.readme.io/835b3f4-image.png)

      <br />
