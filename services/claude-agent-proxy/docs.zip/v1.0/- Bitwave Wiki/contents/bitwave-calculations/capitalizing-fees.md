---
title: "Capitalizing Fees"
slug: "capitalizing-fees"
excerpt: ""
hidden: false
createdAt: "Tue Jun 25 2024 16:00:54 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 25 2024 17:20:16 GMT+0000 (Coordinated Universal Time)"
---
