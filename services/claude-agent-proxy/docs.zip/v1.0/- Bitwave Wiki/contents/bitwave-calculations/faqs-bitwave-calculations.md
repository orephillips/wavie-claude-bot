---
title: "❓FAQs"
slug: "faqs-bitwave-calculations"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 15:46:02 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Dec 20 2024 14:21:44 GMT+0000 (Coordinated Universal Time)"
---
> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

Q:  When a client connects their wallet to Bitwave Ops to enable crypto payments, is this a one-time thing? Or must they connect the wallet every time the wish to execute a payment?  
:a: We must connect the wallet to Bitwave Ops everytime when we want to execute payment.

## Q: What is wrapping a treatment?

### :a:: Wrapping treatment involves converting a digital asset from one blockchain into a compatible token on another blockchain. This process allows the asset to be used within a different blockchain ecosystem while maintaining its original value.

For example, Ether (ETH), the native cryptocurrency of the Ethereum network, can be wrapped into Wrapped Ether (WETH). WETH is an ERC-20 token that can be used in decentralized applications (dApps) and decentralized finance (DeFi) platforms on the Ethereum network. For more information on wrapping treatment see: [Bitwave Documentation on Wrapping Treatments](https://docs.bitwave.io/docs/wrapping-treatments)

## Q: What is Solana Associated Token Account program and how to validate these ATA balances ?

### :a:

The SOL balances in Bitwave tend to be higher than of onchain balance, it is due to ATA ( Associate token program), The cost of an Associated Token Account (ATA) on Solana includes an initial fee.When an ATA is created, the System Program transfers 0.00203928 SOL to the ATA. This amount is deducted from the account that initiates the transaction.  
​  
Here's a quick way to validate solana balances against the blockchain.  
​

1. Grab bitwave SOL balance, subtract on chain solscan balance.
2. Go to 'token accounts' and multiple the number of token accounts by 0.00203928 (a fixed fee).
3. If the difference between the bitwave balance and solscan balance is equal to the result of step 2, then balances align.  
   ​  
   For more info on this you can see thi solana developer link  
   ​<https://solana.com/developers/courses/token-extensions/token-extensions-in-the-client#associated-token-accounts-ata>
