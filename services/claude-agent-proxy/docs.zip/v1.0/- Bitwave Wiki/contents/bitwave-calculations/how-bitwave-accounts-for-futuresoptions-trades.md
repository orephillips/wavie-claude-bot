---
title: "How Bitwave accounts for futures/options trades?"
slug: "how-bitwave-accounts-for-futuresoptions-trades"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 15:37:00 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 15:49:50 GMT+0000 (Coordinated Universal Time)"
---
