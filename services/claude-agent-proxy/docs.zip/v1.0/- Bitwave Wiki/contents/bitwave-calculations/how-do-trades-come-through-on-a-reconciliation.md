---
title: "How do trades come through on a reconciliation?"
slug: "how-do-trades-come-through-on-a-reconciliation"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 15:35:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 15:49:42 GMT+0000 (Coordinated Universal Time)"
---
