---
title: "Manual Wallets"
slug: "manual"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:30:26 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:14:52 GMT+0000 (Coordinated Universal Time)"
---
**Manual Wallet**

1. Go to **Wallets & Connections**
2. Go to **Wallets**
3. Click on **Create Wallet**
4. Click on **Other** (Click Dropdown)
5. Choose **Manual** and fill in details. 
6. Click **Add Wallet(s).**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3e1828a-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
