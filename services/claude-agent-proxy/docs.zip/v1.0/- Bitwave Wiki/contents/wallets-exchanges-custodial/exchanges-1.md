---
title: "Exchange Wallets"
slug: "exchanges-1"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:30:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:14:32 GMT+0000 (Coordinated Universal Time)"
---
**Exchanges**

1. Go to **Wallets & Connections**
2. Go to **Wallets**
3. Click on **Create Wallet**
4. Click on **Exchange** (Click Dropdown)
5. Choose the exchange and fill in details. 
6. Click **Add Wallet(s)**. (Note: Syncing transactions could take up to 24 hours.)

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0fed240-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
