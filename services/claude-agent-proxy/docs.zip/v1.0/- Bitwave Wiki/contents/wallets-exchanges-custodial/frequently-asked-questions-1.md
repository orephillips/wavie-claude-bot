---
title: "❓FAQs"
slug: "frequently-asked-questions-1"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 00:30:47 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 03 2025 14:59:35 GMT+0000 (Coordinated Universal Time)"
---
# Wallets, Exchanges, Custodial & Manual Wallets

## Q: How to add onchain wallets?

### :a::

1.Go to Wallets & Connections

2.Go to Wallets

3.Click on Create Wallet

4.Click on Blockchain Dropdown

5.Choose the network and fill in details.

6.Click Add Wallet(s). (Note: Syncing transactions could take up to 24 hours.)

***

## Q: How to add Exchange Wallets ?

### :a::

1. Go to Wallets & Connections
2. Go to Wallets.
3. Click on Create Wallet.
4. Click on Exchange (Click Dropdown).
5. Choose the exchange and fill in details.
6. Click Add Wallet(s). (Note: Syncing transactions could take up to 24 hours.)

***

## Q: How to add manual wallets?

### :a::

1. Go to Wallets & Connections
2. Go to Wallets
3. Click on Create Wallet
4. Click on Other (Click Dropdown)
5. Choose Manual and fill in details.
6. Click Add Wallet(s).

***

***

## Q. How to delete a wallet ?

### :a:﻿:

Steps to delete a wallet in Bitwave 

1. Go to left hand side menu in Bitwave and click on Administration 

   ![](https://files.readme.io/2fffc6c-image.png)

2. Make sure to first delete all transactions from that wallet.

   3. Click on Wallets tab under Administration 

   ![](https://files.readme.io/da88390-image.png)

3. Click on Actions then delete 

   ![](https://files.readme.io/60fd00c-image.png)

***

## Q: How do I delete a connection?

### :a::

Please reach out to Bitwave's in-app chat for assistance in deleting a connection (exchange wallet).

***

## Q: To connect Fireblocks to Bitwave Is the API key generated through the Fireblocks UI and What permissions can we set on the API key and private key?

### :a::

The API is created via Fireblocks and you are able to give read-only access during the setup process. The keys are encrypted at rest, and the information being protected is read-only Fireblocks data (transactions, wallet addresses, etc.)

***

## Q: How do I get a list of all my wallets with name, addresses and IDs?

### :a::

1. Click on **Reports**
2. Select **Balance Report**
3. Enter the latest date.
4. Click on the **Group by** option and choose **Wallets**
5. Enable the **Include Empty Balances** option.
6. Click **Run Report**
7. Click **Download CSV**
8. Open the downloaded CSV file to view the Wallet names and Wallet IDs.

> Note: The "Group by" feature has two options - 
>
> "None" displays the total balance of the specific token, and 
>
> "Wallets" shows the total balance of different wallets in your organization.

***

## Q: How do I get my wallet name and ID?

### :a::

1. In the left-hand corner of your Bitwave app, go to "Wallets & Connection."
2. Navigate to "Wallets."
3. Click on "Details."
4. You'll find the wallet name and ID listed.
5. Double Click to Highlight

***

## Q: How long will it take for transactions to start syncing into Bitwave using an onchain wallet?

### :a::

Syncing will begin within ten minutes and complete within hours for all but very high volume wallets. After initial sync completes, new transactions will be synced in at least every 12 hours (depending on the network).

## Q: Will a wallet resync uncategorize transactions?

### :a::

No, the wallet resync doesn't uncategorize transactions that have been categorized. The purpose of a wallet resync is to add txns to Bitwave that have been deleted or are missing.

## Q: How to get the connection id ?

### :a:

In the left-hand corner of your Bitwave app,

1. Navigate to Wallets & Connections.
2. Go to Connections.
3. Right Click on the screen (blank area).
4. Click on Inspect
5. Click on Network.
6. Scroll down and open the last “graphql”.
7. Copy the “id” for the respective exchange or connection.

***

## Q. How to delete a wallet?

### 🅰️:

In order to delete a wallet, you can follow these steps:

1. Login to Bitwave
2. Navigate to Administration under the menu and Click on Wallets 

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0bc11a4-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. Click on Actions button in front of the wallet you want to delete 
4. Click Delete and the wallet will be deleted from your Bitwave org

## Q. How do i run a balance check report?

### 🅰️:

1. Go to Left Menu -> Reports -> Balance Check Report. 

![](https://files.readme.io/8b7277e-image.png)

2. Open the report and select the date you want to run a balance check as of

3. Notice the Bitwave Balance Vs Third Party Balance Column which shows the balance in bitwave as opposed to the expected balance as per the third party balance source.  

![](https://files.readme.io/7693671-image.png)

Note: there are several scenarios where a third party balance may be unavailable including:

- In most cases, third party balance information is not available for a date prior to when the wallet was connected.
- In most cases, third party balance may not be available for certain obscure tokens or networks for which historic balances are not available
- Other cases may apply. Please reach out via our chat tool for nuanced conversation if you notice an unavailable third party balance that you expect to be available.

***

## Q: How to get API Keys and Private Keys for Fireblocks?

### :a::

To get you Fireblocks API keys, Please refer to this documentation :-

<https://developers.fireblocks.com/docs/secure-api-configuration>

To get you Fireblocks Private keys, Please refer to this documentation :-

<https://developers.fireblocks.com/docs/quickstart>

Remember : Private keys are your API Private keys not the actual Private keys for your wallet.

***

## Q. Unknown wallet show up in my balance report but it doesn't show up in the wallets tab ?

### :a:. Here's what can be done to sort this -

​  
unknown wallet” means a wallet was deleted but all the transactions were not, so now bitwave has transactions still in it for the deleted wallet  
​  
In order to fix this you can follow these steps:  
1- run transaction export for all dates  
2- find that wallet ID in the wallet ID column on the transaction export and from there get your list of transactions  
3- delete them either manually or via csv bulk actions  
​  
Then the unknown wallet will no longer appear on the balance report

***

## Q: Transactions are not syncing in my wallet. Any suggestions to fix it?

### :a::

This generally requires a wallet resync, which requires that a few details be provided to the [in-app chat](https://docs.bitwave.io/docs/in-app-support) support:

1. ORG ID and ORG NAME :

- Administration > Organistation > You can see organisation name and Organisation ID.

2. WALLET ID and WALLET NAME  : 

- In the left-hand corner of your Bitwave app, go to "Wallets & Connection."
- Navigate to "Wallets."
- Click on "Details."
- You'll find the wallet name and ID listed.
- Double Click to Highlight

3. BLOCKCHAIN : Blockchain integrated ( ETH, Solana, Polygon, Arbitrum, etc )
4. Provide this information to the [in-app chat](https://docs.bitwave.io/docs/in-app-support) support specialist as a request to resync your wallet.

> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q: We have setup a SOL validator, should we just add wallet as a manual wallet or vote account address ?

### :a::

Validators earn rewards based on the total stake delegated to their vote account (self-stake + delegated stake). These rewards are distributed to the vote account and are considered income. We would advise plugging in your main wallet/vote account address - then once your data is syncing into Bitwave - you can review to confirm.

***

<br />

## Q: What information is helpful to have when using a UTXO Bitcoin address?

### :a::

Bitwave XPUB Integration Questionnaire

To streamline the integration process and avoid syncing issues, please provide the following details regarding your xpub/zpub/ypub. Accurate and complete information is crucial for successful setup.

XPUB/YPUB/ZPUB Details  
	•	Provide the full xpub/zpub/ypub key:  
	•	(Please ensure there are no spaces or formatting errors)

Wallet Information  
	•	What type of wallet generated this xpub/zpub/ypub?  
	•	Examples: Electrum, Ledger, Trezor, other (please specify)  
	•	Wallet software version:  
	•	(If applicable)  
	•	Is this wallet connected to a specific blockchain or multiple chains?  
	•	(e.g., BTC, BCH, LTC, etc.)

Derivation Paths  
	•	What is the derivation path used for this xpub/zpub/ypub?  
	•	(e.g., m/84’/0’/0’ for zpubs, m/44’/0’/0’ for xpubs, etc.)  
	•	Is this a custom derivation path?  
	•	(If yes, please provide the details.)

Address Details  
	•	Can you provide a few sample addresses generated from this xpub/zpub/ypub?  
	•	(Include at least 3 sample addresses for validation.)  
	•	What type of addresses are expected?  
	•	Legacy (P2PKH), SegWit (P2SH-P2WPKH), or Native SegWit (Bech32)  
	•	Are there any gaps or unused addresses between transactions?

Transactions and Syncing  
	•	How many transactions are expected to sync initially?  
	•	(An estimate is fine.)  
	•	Are there any known transaction gaps or unusual patterns?  
	•	Is this xpub/zpub/ypub actively used, or is it historical?  
Additional Configuration  
	•	Are you using multiple xpub/zpub/ypub keys for the same wallet?  
	•	(If yes, provide the additional keys.)  
	•	Do you expect to use this wallet across multiple accounts or organizational units?  
	•	(Explain if applicable.)

Technical Assistance  
	•	Would you like live assistance in generating this xpub/zpub/ypub correctly?  
	•	Do you need help identifying or confirming the derivation path?

Security and Permissions  
	•	Are there any restrictions or security policies related to how this xpub/zpub/ypub can be used?  
	•	Is there an expiration for the xpub/zpub/ypub, or will it require periodic re-validation?

Comments or Notes  
	•	Please provide any additional information that might be helpful for integration.

***

<br />

## Q: Why isn’t my Kraken wallet syncing new transactions in Bitwave?

:a::

If your Kraken wallet hasn’t updated in Bitwave, first try clicking “Update Credentials” in the Kraken connection settings. This can help re-authenticate the connection. Afterward, wait up to 24 hours for transactions to sync. If the issue persists, our support team may need to escalate it for further investigation.

***

<br />

## Q: Can I manually import Kraken transactions using a CSV file?

:a::

Yes, you can manually import Kraken transactions by uploading a CSV file. Here is the user guide on how to manually import the transactions. However, we recommend confirming whether the direct sync issue has been resolved first to avoid duplicates later.

***

<br />

## Q: What happens if I import transactions manually and then the sync starts working again?

:a::

If you manually import transactions and the Kraken sync issue is later resolved, there's a chance those transactions could be duplicated. Bitwave includes tools to help identify and manage duplicates, but we recommend checking with support before uploading to determine the best approach.

***

<br />

## Q: Why is Bitwave asking for a new Kraken API key even though I already updated it?

:a::

Sometimes, even a newly generated API key may lack the correct permissions or may not be fully active. If you’re seeing a "successful sync" but no transactions, it’s possible that the key is invalid or missing necessary access scopes. Double-check in Kraken that your key is active and has permission to read all transaction data.

***

<br />

## Q: How can I check if my Kraken API key is still valid or has the correct permissions?

:a::

Log into your Kraken account and review the API key settings. Ensure it hasn't expired and that all necessary permissions (especially “Query Ledger Entries” and “Query Trades”) are enabled. If everything looks correct and issues persist, try generating a new key and updating it in Bitwave.

***

<br />

## Q: Does Bitwave integrate with Fireblocks?

:a::

Yes, Bitwave supports integration with Fireblocks. Here is the guide on how to connect the Fireblocks to Bitwave.

***

<br />

## Q: What caused the negative balance in my deleted wallet?

:a::

The negative balance was traced back to a specific transaction that remained after the associated wallet was deleted. Please contact support for further investigation. If you're still seeing the negative balance.

***

<br />

## Q: Can I permanently remove or hide wallets so they don’t clutter filters?

:a::

While disabling the wallets will stop them from syncing, they may still appear in filters. For permanent removal, follow the steps outlined in our wallet deletion guide here.

***

<br />

## Q: I added a wallet, but the transactions aren't showing up. What should I do?

:a::

Make sure you've selected the correct wallet type. For Solana wallets, you must create a Solana-specific wallet in Bitwave, not a manual one. After setup, transactions typically appear within 24 hours.

***

<br />

## Q: What should I do if I need to mass ignore transactions from certain wallets?

:a::

You can use Bitwave’s System Jobs feature to mass ignore transactions efficiently. Read our guide on System Jobs for step-by-step instructions.

***

<br />

## Q: Can I edit the date and time of a transaction after it has been created from the Transactions UI page?

:a::

Yes, you can edit a transaction date by clicking the Edit button next to the transaction entry in Bitwave.

***

<br />

## Q: Are token names case-sensitive in Bitwave?

:a::

Yes token names are case-sensitive in Bitwave. For exammple “tBTC” and “TBTC” refer to different assets. Please ensure you're using the exact token name that matches what you’ve requested to be whitelisted.

***

<br />

## Q: Do I need a separate wallet connection in Bitwave for Coinbase.com (Retail) versus exchange.coinbase.com (Coinbase Exchange)?

:a::

 Yes, Coinbase Retail and Coinbase Exchange require separate connections in Bitwave. If you're already connected to Coinbase Exchange (formerly known as CoinbasePro in Bitwave), you'll need to set up an additional connection for Coinbase Retail to capture activity from Coinbase.com.

***

<br />

## Q:  How do I know which version of Coinbase I'm using Retail, Exchange, or Prime?

:a::

<br />

"Coinbase Retail is for individual users and accessed via Coinbase.com.  
Coinbase Exchange (previously called CoinbasePro in Bitwave) is a platform for trading and managing crypto assets more actively.  
Coinbase Prime is designed for institutions and offers advanced features like OTC trading and custody solutions.

If you're unsure which one applies to you, check with your operations or finance team."

***

<br />

## Q:   Where can I find the instructions to connect my Coinbase Retail account to Bitwave?

:a::

You can follow the official documentation here: Coinbase Retail Setup Guide. Be sure to follow each step carefully, including handling your API keys correctly.

***

<br />

## Q:  I successfully added my Coinbase Retail API keys. How long does it take for my transactions to appear in Bitwave?

:a::

Once your Coinbase Retail connection is set up, it may take 24 to 48 hours for your transaction data to start appearing, depending on the volume of activity. If you don't see anything after that time, please reach out to our support team.

***

<br />

## Q: How do I check the status of a Coinbase Retail once it’s connected?

:a::

You can check the connection status within the Wallets & Connections section in Bitwave. A clock icon typically indicates the process is still running. If you're unsure or it’s been more than 48 hours, contact support for help.

***

<br />

## Q: The documentation mentions removing “/n” from the API secret in  Coinbase Retail guide what does that mean?

:a::

This refers to newline characters (\\n) that can accidentally be included when copying the API secret key. You should remove all instances of \\n, including those at the beginning, end, or in the middle of the key, before pasting it into the connection field in Bitwave.

***

<br />

## Q: The API keys I have look different than what’s shown in the documentation. What should I do?

:a::

If your API keys were generated after February 5, 2025, they may have a new format. Be sure to copy the full key and secret exactly as provided and follow the latest instructions. If in doubt, contact support to ensure compatibility.

***

<br />

## Q: Why isn’t Bitwave recognizing my BitGo API key even though I copied it correctly?

:a::

This can happen if not all required fields are filled out during the integration setup. Please ensure that you’ve selected or added an Exchange Contact in the connection form. If this dropdown appears empty, it’s likely because no contacts have been created in your Bitwave instance.

***

<br />

## Q: I've set up a contact and completed the form in Bitgo connection, but now I’m getting an error when uploading the token. What should I do?

:a::

First, double-check that your BitGo API key was created correctly. If errors persist, try generating a new API key and ensuring it has view permissions and includes the IP addresses listed in our BitGo Integration Guide. If issues continue, please contact support for further troubleshooting.

***

<br />

## Q:  Do I need to whitelist Bitwave’s IPs when using the BitGo integration?

:a::

Yes, IP whitelisting is required. Please ensure you’ve added all the IP addresses listed in our integration guide to your BitGo key’s settings.

***

<br />

## Q:  I’ve tried generating a new API key multiple times  in BitGo and it’s still not working. What else can I do?

:a::

If you’ve confirmed the key is correct, has the proper permissions, and IPs are whitelisted, please reach out to our support team with the API key details so our engineering team can assist. We're also happy to set up a call to walk through the process with you.

***

<br />

## Q:  I was asked to update my Coinbase Retail API keys how do I proceed?

:a::

When prompted, please update your Coinbase Retail API keys directly in the Bitwave platform. This helps ensure that all data, including recent transactions, syncs correctly. Let us know once you've updated them so we can continue investigating any remaining issues.

***

<br />

## Q:  I accidentally selected the wrong Coinbase type. Can I fix it?

:a::

Yes. If you chose the wrong type (e.g., Exchange instead of Retail), you’ll need to delete the incorrect wallet and re-add it with the correct type.

***

<br />

## Q:  Can I permanently delete disabled wallets so they don’t appear in wallet filters?

:a::

Yes, disabled wallets can be permanently deleted to clean up your wallet filters. However, if you encounter errors while deleting wallets, please contact support. Our team can manually delete these wallets on your behalf.

***

<br />

## Q:  Should deposits to exchanges that lock tokens be tracked through API or recorded manually?

:a::

It depends on whether the tokens are recoverable and how the client intends to report them. Our team will evaluate and recommend either API-based tracking or manual entry based on your specific scenario.

***

<br />

## Q:  Does Bitwave support transactions on ApeChain and Abstract Chain (Ethereum Layer 2s)?

:a::

ApeChain and Abstract Chain are currently on our product roadmap, but support has not yet been released. While we don't have an exact timeline for integration, our team is actively tracking interest and development. Stay tuned for updates!. In the meantime you can upload the data via manual imports into the wallets, after creating manual wallets for respective chains.

***

<br />

## Q:  What should I do if I don’t see any options in the “Exchange Contact” dropdown when connecting BitGo?

:a::

This usually means there are no contacts available in your Bitwave instance. You’ll need to create a Bitwave or ERP contact before the dropdown becomes active. Follow this guide to create a contact: Creating Manual Contacts.

***

## Q: What IP addresses does a customer have to whitelist when creating API keys in their exchanges.

:a::

Yes certain exchange providers and other sources will ask for IP addresses to whitelist to ensure they only receive requests from those IPs. Please whitelist the following IPs in your source platform please whitelist these IPs 104.196.183.18 and 35.230.22.143 these are the bitwave IP addresses from which we will initiate requests for data.

***

## Q: Why would I need to delete and resync transactions in QBO?

:a::

If transactions were synced with the wrong Bitwave general ledger (GL) account in QBO, you may need to unreconcile them in Bitwave, delete them manually from QBO, and then resync with the correct GL mapping.

***

## Q: Why isn’t my Coinbase Retail wallet updating in Bitwave?

:a::

If your Coinbase Retail wallet hasn’t updated, it's often due to expired or incorrect API credentials. Please check and update your API key and private key as outlined in our Coinbase Retail API connection guide. Make sure to remove all newline characters (\\n) when entering your keys, as incorrect formatting may cause the sync to fail.

***

## Q: My API keys are correct but my wallet still isn’t syncing what should I do?

:a::

Sometimes, updates may take several hours or overnight to reflect. If the sync doesn’t happen after that time, double-check your key formatting and ensure you’ve entered both the API key and private key correctly. If issues persist, contact our support team for further assistance.

***

## Q: How do I delete a wallet I accidentally uploaded to the wrong organization?

:a::

You can delete a wallet by selecting it in Bitwave and clicking "Delete." For more details, refer to our wallet deletion FAQ.

***

## Q: Why am I not seeing any account balances or transactions after connecting my Fireblocks wallet?

:a::

After connecting a wallet, it may take some time for the balances and transactions to load. If everything is correctly linked, give it a few moments and refresh the page. If the issue persists, contact support with your organization and wallet IDs.

***

## Q: How do I set opening balances for all of my wallets in Bitwave?

:a::

<br />

"If you know the balances as of a specific date, you can either:

```
Categorize all transactions prior to that date as “opening balance,” or

Run a balance report for that date and manually import a deposit for each asset, categorizing each as an opening balance."
```

***

## Q: Why is my Coinbase Exchange API only pulling deposits and withdrawals, but not trades?

:a::

This may be due to a permissions or configuration issue within your API setup. First, ensure your API key has the necessary permissions to access trade data. If trades still don’t appear, please update your API credentials in Bitwave and try again. If the issue persists, reach out to our support team with your organization and wallet details so we can investigate further.

***

## Q: What steps should I take after updating my Coinbase API credentials in Bitwave?

:a::

After entering your new API key, secret, and passphrase into Bitwave, please log out and log back in to ensure the changes take effect. Then, check if your trade data has synced successfully.

***

## Q: What information should I include when sending a Coinbase report to Bitwave?

:a::

Please include a detailed transaction report from Coinbase that reflects everthing you expect to see in Bitwave. This helps our support team compare the data and determine what’s missing, enabling a quicker resolution.

***

## Q: I deleted about 20 wallets in Bitwave, but they are still showing. How long does it take for wallets to be deleted?

:a::

Wallet deletions in Bitwave should take effect immediately after you complete the deletion process. If deleted wallets are still visible, please try refreshing your Bitwave instance (e.g., reload the page or clear your browser cache) and check again. If the wallets still appear after refreshing, please contact support for further assistance.

***

## Q: Does Bitwave automatically integrate blockchain data for wallets, or do I need to do this manually?

:a::

Bitwave supports automatic blockchain data integration for a wide range of blockchains. You typically don't need to manually integrate data unless you're using a blockchain that isn’t currently supported. In such cases, you can import data manually.

***

## Q: How can I see which blockchains are integrated with Bitwave for a particular wallet?

:a::

While you can’t view blockchain integrations on a per-wallet basis directly in the app, you can refer to our full list of supported blockchain integrations here: Bitwave Blockchain Integrations. This page is regularly updated with the most current integrations.

***

## Q: I minted a token (e.g., fragSOL), but I don't see it reflected in Bitwave. What should I do?

:a::

If you've minted a token and it’s not showing in Bitwave, please provide us with the Organization ID, Wallet ID, and Transaction ID. Include the token name and a link to the transaction on a blockchain explorer (e.g., Solscan). Our team will investigate and, if necessary, work to add the token and resync the wallet to ensure accurate categorization.

***

## Q: How long does it take for Bitwave to reflect newly supported tokens after a wallet resync?

:a::

Once a new token is added and a wallet resync is requested, it typically takes a short time for transactions to appear. However, in rare cases, issues with blockchain API upgrades or syncing may delay this process. Our support team will keep you informed throughout and escalate to engineering if needed.

***

## Q: What happens if I still don’t see the token after a resync?

:a::

If the token doesn't appear after a wallet resync, we will escalate the issue to our engineering team to investigate further. There may be a need for backend upgrades or additional API integration to support the token properly.

***
