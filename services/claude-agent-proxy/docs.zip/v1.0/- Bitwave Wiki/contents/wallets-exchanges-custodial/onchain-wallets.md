---
title: "Onchain Wallets"
slug: "onchain-wallets"
excerpt: "Bitwave is an enterprise finance platform designed to help businesses manage, track, and report digital assets at scale. Bitwave customers can use the instructions below to securely connect their wallets to the platform. With Bitwave, you'll have total visibility into your on-chain financial landscape. https://www.bitwave.io/"
hidden: false
createdAt: "Thu Apr 11 2024 00:29:58 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 23 2024 18:22:04 GMT+0000 (Coordinated Universal Time)"
---
**Onchain Wallets**

1. Go to **Wallets & Connections**
2. Go to **Wallets**
3. Click on **Create Wallet**
4. Click on **Blockchain** Dropdown
5. Choose the network and fill in details.
6. Click **Add Wallet(s)**. (Note: Syncing transactions could take up to 24 hours.)

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6b1d421-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]
