---
title: "Journal Entry Reports"
slug: "journal-entry-report"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 02:49:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Apr 15 2024 20:42:40 GMT+0000 (Coordinated Universal Time)"
---
Journal Entry Report: This report provides the detailed transaction by transaction view of the rolled up journal entry report. It can be exported to a CSV file.

\*The Report Total for Debit and Credit at the bottom of the report is the net asset change to Digital Assets only.

![](https://files.readme.io/baea49f-Screenshot_2024-03-26_at_8.56.11AM.png)

Journal Entry Report (Expanded): This report provides an expanded detailed transaction by transaction CSV download that can be saved and accessed on a future date.

To run this report select a Start Date, End Date and Connection from a Manual chart of accounts or from an accounting software connection.

![](https://files.readme.io/8302f4d-fbab2d1b-71b1-485a-a9bf-32a9e40b7cf3.png)

Rolled Up Journal Entry Report: This report provides an aggregated view of all the journal entries for the period. It can be aggregated by category and contact.

1. Run the Rolled Up Journal Entry Report

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eef867a-Period_End_Close_10.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. Select the corresponding time period as the Gain/Loss report, grouping is optional, and choose the appropriate Accounting Connection (your ERP system).

Transfer the Report Total values to the Period End Close Template in rows 2 and 3.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/93df62b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


![](https://files.readme.io/93f4ca6-270f846-image.png)

***

***

***

***
