---
title: "❓FAQs"
slug: "frequently-asked-questions-7"
excerpt: "Undo Reconciliation"
hidden: false
createdAt: "Thu Apr 11 2024 02:59:49 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 30 2025 18:57:49 GMT+0000 (Coordinated Universal Time)"
---
> 📬 Don't see your question listed here? Hit the "Suggest Edits" button in the upper right and add a question for our Support Team!
> 
> [block:image]{"images":[{"image":["https://files.readme.io/ff1cf2f-image.png",null,"Send us your questions! We're happy to help!"],"align":"center","sizing":"30% ","border":true,"caption":"Send us your questions! We're happy to help!"}]}[/block]

## Q. How do I run a report for just the specific token?

### 🅰️.

In order to run a report for just a specific token, you can do the same with the help of a register report. Here are the steps to run a register report:

1. Login to bitwave
2. Select 'Transactions' and click on 'Register'

![](https://files.readme.io/c1c4c33-image.png)

3. Put in the 'Wallet name', Date, and the 'Ticker' 
4. Click on 'Load register' and the report will run for that particular token

## Q: How to check the Transactions having negative balances in Actions Report?

:a: 

You need to go through the Actions report to check the transactions which are causing the negative balances.  
​  
Steps to download the Actions Report.  
​  
In the left-hand corner of your Bitwave app,

1. Navigate to Inventory.
2. Click on Update Now
3. Wait for few minutes to update the Inventory view (you can check the update status in the Updates.
4. Go to Actions
5. Run the Actions report on the desired date.
6. Then Click on Download Actions of (desired date).
7. Filter the "assetBalance" in the report to get the transactions causing the negative balance.  
   ​  
   Be make sure that all the transactions are categorized before doing all these steps."

## Q: How to check the variance of specific token in a wallet?

:a:

- Go to Register under Transactions tab on the left hand side menu
- Select the Wallet under the Wallet Name dropdown.
- Choose the desired date.
- Fill out the Token name in the Ticker Box
- Click on "LOAD REGISTER".

Q : What causes the balance report not to pull in pricing?

:a::  The balance report doesn't pull pricing when there is no pricing for the asset on the day selected from the pricing source configured for that org.

Q: What is the difference between Journal Entry Report and Journal Entry (Expanded) Report  
:a: **Journal Entry Report: **This report provides the detailed transaction by transaction view of the rolled up journal entry report. It can be exported to a CSV file.  
The Report Total for Debit and Credit at the bottom of the report is the net asset change to Digital Assets only.  
**Journal Entry Report (Expanded): **This report provides an expanded detailed transaction by transaction CSV download that can be saved and accessed on a future date.

Q : Does Bitwave have a feature to show block numbers?

:a:: To get block numbers from Bitwave, simply :   

1. Login to Bitwave.
2. Go to Reports.
3. Click on Balance report.
4. Select a date for which you want to get the block number.

![](https://files.readme.io/a3f778a-Screenshot6.png)

5. Click on group by and select wallets and select any wallet. 

   ![](https://files.readme.io/6876017-Screenshot7.png)
6. The number that show here are the block numbers of that specific date.

   ![](https://files.readme.io/9e4e8b9-Screenshot8.png)

# Q: Why is an Unknown Wallet Appearing in My Balance Reports?

🅰️: One reason an unknown wallet could be appearing in your balance report would be that a wallet was deleted, but the transactions associated with the deleted wallet still remain in Bitwave. This can be resolved in one of two ways:

### Adding the deleted wallet back into Bitwave

This option makes the most sense if it becomes apparent that the deleted wallet should not have been deleted.

### Deleting the transactions with the associated wallet

This option makes the most sense if the associated transactions with the wallet need to be deleted. The process for this involves creating a system job to delete transactions with the associated wallet. 

For this process of deleting these transactions, follow the steps below:

1. Navigate to the System Jobs page (Administration > System Jobs)
2. Click “Create Job"
3. Select “Delete Transactions” for the Action
4. Select the unknown wallet for the wallet
5. Select the desired date range
   1. NOTE: It is recommended to start with a small date range to ensure the job is correctly implemented and only deletes the transactions that need to be deleted.

If the unknown wallet issue occurs from a scenario other than a deleted wallet with transactions remaining, please reach out to your Bitwave solutions expert for further assistance.

# Q: How do I view the FIFO layers on Actions Report?

🅰️: The bitwave actions report can be sorted by column N lotAcquisitionTimestampSEC and then by column D timestamp. This will sort the buys as of the first lot acquired and sort disposals in FIFO order by lot. 

# Q: How do I extract data from bitwave for form 8949?

🅰️: The bitwave actions report provides all the detail required to produce your 8949. Each tax and accounting preparer  has different requirements on the level of aggregation preferred or required (lot level, Asset level etc) and as such aligning with your technical tax / accounting expert will drive how you use the actions report to populate the 8949

# Q: How do I extract data from bitwave for form 1099?

🅰️: The bitwave actions report provides all the detail required to produce your 1099. Each tax and accounting preparer  has different requirements on the level of aggregation preferred or required (lot level, Asset level etc) and as such aligning with your technical tax / accounting expert will drive how you use the actions report to populate the 1099

# Q: How to Download Actions Report:

🅰️: Go to Inventory.  
Click on Actions.  
Add the preferred date range or submit date filters.  
Once filtered, click on "Download Actions" to export the report as a CSV file.

# Q. Why does the balance check report show some third-party balance fields as empty?

### 🅰️ Currently, the balance check report in Bitwave displays third-party balances for major tokens. In the meantime, we recommend validating tokens using the balance report in Bitwave and comparing it with the on-chain balance.

***

## Q. Is it possible to build own reports through API? like to pull data from the account into PowerQuery?

### 🅰️.

Yeah, you can build your own reports through API.  
Here is the user guide for your reference  
​<https://docs.bitwave.io/reference/get-an-api-key>  
​

***

## Q: Why sometimes there is a discrepancy in the coin balances between the number of open lot positions and the balances shown in the wallet balance report?

### 🅰️

The tax lots report is generated based on categorization, so if there are un-categorized transactions, or categorized transactions where the quantities do not match the actual transaction, this is what causes the difference.

***

## Q: Which is the alternate report that can be used if balance report is showing error while generating?

:a:

If balance report shows error while generating , you can use " Balance report (Expanded)" report to get the results. 

Following are the steps to get balance report (Expanded)

1. Go to reports on left side menu.  
   2.Click on Balance report (expanded).  
   3.Fillout the date and the group by (whether by wallet or none)  
   4.Hit run and keep refreshing until the status says succeeded.  
   5.Once the status says suceeded, click on download button in front of the report to download the report.
   ***
   <br />

***

## Q: Do we have any report that gives summary of all the fees for tax purposes?

:a:

If the bitwave environment is configured to capitalize fees on trades. and you only want  fees that were expensed (not capitalized)  
Then, you should use the Journal Entry report and filter it to your fee category(ies).

***

<br />

## Q: How to get the Bitwave SOC report?

### 🅰️

To get the Bitwave SOC report you can reach out to us via in app chat support with following details

1. Org Name
2. Org ID

***

<br />

## Q: How Do I Integrate Snowflake with Bitwave?

### 🅰️

To integrate Snowflake, please follow our setup guide here : [Setup Snowflake](https://docs.bitwave.io/docs/setup-snowflake)

***

<br />

## Q: The Gain/Loss report isn't working—how can I still get my data for book closing?

:a::

If the Gain/Loss report is not functioning, we recommend using the Inventory Views instead. Be sure to specify your report settings (e.g., FIFO method, capitalize fees, ignore NFTs) and request the data for the needed periods. You can also provide your Organization Name, Organization ID, and any other relevant details to support a quicker response.

***

<br />

## Q: How can I export a report of all uncategorized transactions?

:a::

You can download the Actions report, then filter the “Status” column (Column F) for “Uncategorized.” If the numbers still seem off, try removing duplicate rows to align with what’s shown in the Transactions page. Make sure to update the Inventory View before download the Actions Report.

***

<br />

<br />

## Q: Why do categorized fees still appear as “uncategorized” in reports?

:a::

If only part of the transaction (like the main asset) remains uncategorized, the report may still show all associated lines including the already categorized fee as “uncategorized.” Make sure all components of the transaction are fully categorized.

***

<br />

## Q: Why do I see different numbers of uncategorized transactions in different reports (e.g., Actions report vs. Transactions page)?

:a::

The difference is usually due to how Bitwave displays transaction lines. For example, a single transaction with both a fee and an asset may show as two uncategorized lines in the Actions report, but only as one transaction on the Transactions page. To reconcile the numbers, try removing duplicates from the Actions report after filtering for “Uncategorized.”

***

## Q: Why is there a -0.01 balance in my balance check report for a "null" account, and will this impact my reallocation?

:a::

Yes, a -0.01 balance showing for a "null" account can affect reallocation and may lead to errors. We recommend you finding that speicifc transactions of that null acocunt as the null account here simply means a deleted wallet. So, you may find those deleted wallet's transactions and delete those from UI and then update the inventory views

***

## Q: What does "incomplete transaction" mean in the Actions Report?

:a::

"Incomplete transaction" usually indicates that a transaction is uncategorized. If a transaction appears as "incomplete" even after categorization, try uncategorizing and recategorizing it, and update your inventory view to the current date. If the issue persists, contact support with the transaction ID for further assistance.

***

## Q: What should I do if I receive a "Problem generating report" error when running a Balance Report?

:a::

If you encounter an error while generating a Balance Report, try running an expanded version of the report. This often provides the needed results. If the issue persists, please contact our support team with your Organization ID and Organization Name and a description of the issue.

***

## Q:  How can I run a Cost Basis Roll Forward Report for a specific date range?

:a::

 You can generate a Cost Basis Roll Forward Report by navigating to the “Reports” section under the appropriate view (e.g., Test View) and setting your desired date range (e.g., 01/01/2024 to 12/31/2024). If the report does not populate, please notify our support team.

***

## Q:  Where can I download a report that includes unrealized gains and losses for all transactions?

:a::

You can view unrealized gains and losses by downloading the Dashboard Summary from the Inventory view. For detailed transaction data, try downloading the Actions Report from the Inventory > Actions section. If you're unable to download it, let us know the specific date range, and we can assist you.

***

## Q: How can I compare cost basis to Fair Market Value (FMV)?

:a::

You can use the Cost Basis Roll Forward Report. Go to the Inventory section → Reports → Cost Basis Roll Forward Report, and make sure to check the Include FMV option before running the report.

***

## Q: Does the FMV section in Bitwave balance report show the value as of today or the transaction date?

:a::

The FMV shown of the assets are based on today's date.

***

## Q: Why am I getting a "problem generating report" error when downloading the balance report?

:a::

This can occasionally happen due to cached data or a temporary system hiccup. Please try refreshing your browser, clearing cookies and cache, and then attempting the download again. If the issue persists, it may resolve after waiting a short while. If not, please contact support.

***

## Q:  How do I generate a gain/loss report or check the cost basis applied to transactions?

:a::

Download the Actions Report after categorizing your transactions and updating inventory views. This report includes cost basis and gain/loss information for each transaction.

***

## Q: How can I view and compare cost basis against FMV in Bitwave?

:a::

Use the "Cost Basis Roll Forward" report available under Inventory > Reports. Be sure to select the option "Include FMV" before running the report to view FMV alongside cost basis.

***
