---
title: "Balance Report"
slug: "balance-report"
excerpt: ""
hidden: false
createdAt: "Thu Apr 11 2024 02:48:59 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 17:54:08 GMT+0000 (Coordinated Universal Time)"
---
<p>The balance report allows users to query the balance and FMV of each digital asset at the end of any given date.</p>
<p><br /></p>
<p>1. Run the Balance Report by navigating on the left menu to <strong>Reports</strong>.</p>

![](https://files.readme.io/15f9184-40e13e0-image.png)

<p>Select the <strong>Balance Report</strong> which allows querying the fair market value of each digital asset at the end of the day selected at 11:59:59 PM (based on the entity’s timezone).</p>

<p>***The Balance Report's 11:59:59 PM end of day selection is controlled by the Bitwave Engine version in the Organization menu under Administration in the left task pane. Selecting an engine version 2.0 or above will configure the Balance Report for 11:59:59 PM end of day pricing. Using an engine version below 2.0 will configure the Balance Report for 00:00:00 AM end of day pricing.</p>

![](https://files.readme.io/01edf9c-image.png)

<p>For example, to query the end of day balance of BTC on 9/22/2021, the balance report would be run for this date.</p>

![](https://files.readme.io/b50ddab-116316b-image.png)

<p>Select the Balance as of the end of day either grouped by wallet or without grouping. All other fields are optional.</p>

![](https://files.readme.io/90050f1-b68203e-image.png)

<p>Transfer the total fiat value to the Period End Close Template in row 14.</p>

![](https://files.readme.io/1ba9131-13c99f3-image.png)

<p>The <strong>Balance Report (Expanded)</strong> is recommended to be used for larger volume orgs. This version of the report will automatically save the results as a downloadable CSV file</p>

![](https://files.readme.io/9ea3fbd-image.png)

![](https://files.readme.io/463059d-image.png)

***

***
