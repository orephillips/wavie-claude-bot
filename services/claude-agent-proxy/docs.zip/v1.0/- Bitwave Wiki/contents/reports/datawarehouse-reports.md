---
title: "Datawarehouse Reports"
slug: "datawarehouse-reports"
excerpt: ""
hidden: false
createdAt: "Fri Jun 28 2024 15:27:06 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 28 2024 17:54:27 GMT+0000 (Coordinated Universal Time)"
---
Q: **What is a datawarehouse report? What is the difference that and regular reports?**

🅰️: Bitwave has a robust data architecture that enables reporting of various types and at various levels.

- Standard Non Datawarehouse Report: A standard (non datawarehouse) report is generated directly off bitwave's database. An example of this is the standard transaction export report found in the Left Menu -> Transactions -> Export

  ![](https://files.readme.io/f41f728-image.png)
- Datawarehouse Report: A datawarehouse report is a report that is produced from a bitwave datawarehouse. Specifically bitwave copies / replicates all data from its core databases into a datawarehouse on a near real time basis for advanced reporting purposes. When a report is a datawarehouse report it means that the report is generated NOT directly from the core database but from the copy that is stored in the datawarehouse. An example of this is the Datawarehouse transaction export report found in the Left Menu -> Transactions -> Export
- ![](https://files.readme.io/9a3f848-image.png)

  Note: While the copy/replication from our database to the datawarehouse is immediately it is possible although extremely rare for the datawarehouse to be behind in situations where we have some sort of outage.
