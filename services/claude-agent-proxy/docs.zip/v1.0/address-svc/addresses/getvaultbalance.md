---
title: "/networks/{networkId}/addresses/{vaultAddress}/vaultBalance"
slug: "getvaultbalance"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 03:59:19 GMT+0000 (Coordinated Universal Time)"
---
## Vault Balance

The _/networks/{networkId}/addresses/{vaultAddress}/vaultBalance_ endpoint will return a vault balance.
