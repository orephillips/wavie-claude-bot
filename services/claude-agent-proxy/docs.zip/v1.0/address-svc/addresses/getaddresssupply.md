---
title: "/networks/{networkId}/addresses/{address}/supply"
slug: "getaddresssupply"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:01:26 GMT+0000 (Coordinated Universal Time)"
---
## Token Supply

The _/networks/{networkId}/addresses/{address}/supply_ endpoint will return the token supply for your involved pool or vault.
