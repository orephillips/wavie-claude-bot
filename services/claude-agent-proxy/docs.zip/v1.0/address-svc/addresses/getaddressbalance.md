---
title: "/networks/{networkId}/addresses/{address}/balance"
slug: "getaddressbalance"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 03:58:00 GMT+0000 (Coordinated Universal Time)"
---
## Address Balance

The _/networks/{networkId}/addresses/{address}/balance_ endpoint will return the balance for that particular address.
