---
title: "/networks/{networkId}/addresses/{address}/read/{method}"
slug: "read"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:02:34 GMT+0000 (Coordinated Universal Time)"
---
## Contract method

The _/networks/{networkId}/addresses/{address}/read/{method}_ endpoint returns the contract method. This is done by calling the smart contract and executing the source code.
