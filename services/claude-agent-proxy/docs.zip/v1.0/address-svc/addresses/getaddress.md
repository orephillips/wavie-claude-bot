---
title: "/networks/{networkId}/addresses/{address}"
slug: "getaddress"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 03:56:28 GMT+0000 (Coordinated Universal Time)"
---
## Address Info

The _/networks/{networkId}/addresses/{address}_ endpoint will retrieve information surrounding the blockchain address, such as tokens, block addresses, and assets.
