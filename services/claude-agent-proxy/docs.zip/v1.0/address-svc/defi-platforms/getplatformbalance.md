---
title: "/networks/{networkId}/platforms/{platformId}/balance"
slug: "getplatformbalance"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:05:37 GMT+0000 (Coordinated Universal Time)"
---
## DeFi Balance

The _/networks/{networkId}/platforms/{platformId}/balance_ endpoint will return blockchain balances for your DeFi platform, such as vaults and liquidity pools.
