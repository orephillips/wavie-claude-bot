---
title: "/networks/{networkId}/blocks"
slug: "listblocks"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:06:34 GMT+0000 (Coordinated Universal Time)"
---
## Time-stamped Blocks

The _/networks/{networkId}/blocks_ endpoint will return all the blocks at that particular time-stamp.
