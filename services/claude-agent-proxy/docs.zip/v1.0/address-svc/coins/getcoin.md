---
title: "/coins/{coinId}"
slug: "getcoin"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:06:25 GMT+0000 (Coordinated Universal Time)"
---
## Coin Information

The _/coins/{coinId}_ endpoint will return information about a coin, such as a logo, name, description, and social media links.
