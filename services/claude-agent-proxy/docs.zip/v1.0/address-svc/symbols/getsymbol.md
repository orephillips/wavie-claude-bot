---
title: "/symbols/{symbol}"
slug: "getsymbol"
excerpt: ""
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 04:26:43 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Oct 14 2021 04:06:13 GMT+0000 (Coordinated Universal Time)"
---
## Supported Symbols

The _/symbols/{symbol}_ endpoint will return cryptocurrency symbols supported by Bitwave.
