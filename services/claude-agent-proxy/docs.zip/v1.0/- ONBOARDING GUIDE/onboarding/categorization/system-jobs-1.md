---
title: "System Jobs"
slug: "system-jobs-1"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 17:11:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Jul 11 2024 14:20:18 GMT+0000 (Coordinated Universal Time)"
---
System Jobs allows the user to modify transactions at scale using custom actions.

> 🚧 WAIT! THIS FUNCTION IS TO BE USED WITH CAUTION. Please note you are not able to undo a job after it begins.

### Create System Jobs

1. Go to **Administration**
2. Go to **System Jobs**
3. Click on **Create Job**

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/56b54e4-10000.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "70% "
    }
  ]
}
[/block]


![](https://files.readme.io/214c528-Screenshot_2024-03-08_235141.png)

![](https://files.readme.io/29bc982-Screenshot_2024-03-08_235153.png)

### Types of Actions (and requirements)

- Delete Transactions
  - Wallet
  - Date
- Ignore Transactions
  - Wallet
  - Date
- Mark transactions as Reconciled
  - Wallet
  - Date
- Reconcile Transactions
  - Wallet
  - Date
- Categorize Transactions
  - Upload CSV
- Uncategorize Transactions
  - Wallet
  - Date
- Unignore Transactions
  - Wallet
  - Date
- CSV Bulk Action: Allows you to Update individual transactions using a csv file. [HERE IS THE TEMPLATE](https://docs.google.com/spreadsheets/d/1-cB_ttUvOLa1ZRDKzCPZpdpLrJWggnaOEi7KrjpC33Q/edit?gid=1548202767#gid=1548202767). The available actions are 
  - Delete Transactions
  - Ignore Transactions
  - Mark transactions as Reconciled
  - Reconcile Transactions
  - Categorize Transactions
  - Uncategorize Transactions
  - Unignore Transactions
