---
title: "Viewing Transactions"
slug: "viewing-transactions"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 17:10:14 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:48:49 GMT+0000 (Coordinated Universal Time)"
---
1. To view transactions click "Transactions" then "All Transactions"

![](https://files.readme.io/865114e-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_1.png)

2. All of your transactions will be presented on this screen.

   ![](https://files.readme.io/6a298b5-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_2.png)

![](https://files.readme.io/45b7633-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_2.1.png)

3. **Filter By Wallet:** This filter allows you to view transactions by wallet or view all transactions across all wallets.

   ![](https://files.readme.io/69e8735-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_2.png)
4. **Filter By Reconciliation Status:** This filter allows you to view reconciled transactions, unreconciled transactions, or all transactions.

   ![](https://files.readme.io/8c0f693-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_4.png)
5. **Filter By Categorization Status:** This filter allows you to view categorized transactions, uncategorized transactions, or all transactions.

   ![](https://files.readme.io/5f96faf-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_5.png)
6. **Filter By Ignore Status:** This filter allows you to view unignored transactions, ignored transactions, or all transactions.

   ![](https://files.readme.io/cdfd5de-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_6.png)
7. **Filter By Date:** This filter allows you to filter for all transactions on or before the date specified.

   ![](https://files.readme.io/1eee4b8-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_7.png)
8. Navigate to earlier dates using the left arrows and later dates using the right arrows.

   ![](https://files.readme.io/28344a9-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_8.png)
9. Navigate by clicking on the month and year to expand your date selection.

   ![](https://files.readme.io/7158f32-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_9.png)
10. Drill in to select the year, month, and day.

    ![](https://files.readme.io/4bbe87d-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_10.png)
11. **Filter By Display Results:** This filter allows you to display up to 250 transaction lines on a single page.

    ![](https://files.readme.io/71797d1-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_11.png)
12. Navigate chronologically between pages using the "Earlier" and "Later" selections.

    ![](https://files.readme.io/fa702f6-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_12.png)
13. Use the transaction count summary to quickly filter between categorization and reconciliation statuses:  
    **Needs Categorization:** This filter displays the number of transactions that need to be categorized.

    ![](https://files.readme.io/69829e9-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_13.png)
14. **To Be Reconciled:** This filter displays the number of transactions that have been categorized but have not been reconciled.

    ![](https://files.readme.io/bfff020-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_14.png)
15. **All:** This filter displays the total number of transactions.

    ![](https://files.readme.io/581f477-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_15.png)

![](https://files.readme.io/bdd90e3-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_15.1.png)

16. **Type:** Hover over the icon for the nature of the transaction.

    ![](https://files.readme.io/69f3fdd-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_16.png)
17. **Transaction ID:** Displays the transaction hash or public id associated with the transaction. If the transaction is colored blue, this indicates a clickable hyperlink that navigates you to the transaction as seen on the public blockchain explorer.

    ![](https://files.readme.io/0d353d6-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_17.png)
18. **Date (Local Time Zone):** Displays the date and time that the transaction occurred. The time displayed is in your local time zone unless the entity time zone is used as the default display.

    ![](https://files.readme.io/5e45020-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_18.png)
19. **Wallet:** Displays the wallet(s) impacted by an inflow or outflow of the transaction.

    ![](https://files.readme.io/dfd1582-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_19.png)
20. **From:** Displays the wallet address of the sender in the transaction.

    ![](https://files.readme.io/567a0b8-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_20.png)
21. **To:** Displays the wallet address of the receiver in the transaction.

    ![](https://files.readme.io/a6c24af-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_21.png)
22. **Ticker:** The token that is being sent or received.

    ![](https://files.readme.io/a25a1d2-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_22.png)

![](https://files.readme.io/6af35a6-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_22.1.png)

23. **Amount:** The token amount being sent or received in the transaction.

    ![](https://files.readme.io/4c99359-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_23.png)
24. **Fair Market Value (Undefined):** The fiat value being sent or received in the transaction.  
    _Note: This column is calculated by the token amount x the suggested rate. This column is used for informational purposes only and does not drive the underlying value of the transaction. To review the true fair market value, drill into the categorization window._

    ![](https://files.readme.io/3d95c89-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_24.png)
25. **Status:** A visual indicator of the categorization and reconciliation status of a transaction.  
    • An orange icon indicates that the transaction is uncategorized.  
    • A green icon indicates that the transaction is categorized.  
    • A blue icon indicates that the transaction is reconciled or marked as reconciled.\*\*

    ![](https://files.readme.io/c2d5a2e-Viewing_Transactions_and_Performing_Basic_Transaction_Functions_-_Step_25.png)
