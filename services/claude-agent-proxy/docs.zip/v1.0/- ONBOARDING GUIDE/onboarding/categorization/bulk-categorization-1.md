---
title: "Bulk Categorization"
slug: "bulk-categorization-1"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 17:11:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:47:06 GMT+0000 (Coordinated Universal Time)"
---
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/375f9d7-Bulk_Categorization_-_Step_0.png",
        null,
        "Bulk Categorization"
      ],
      "align": "center",
      "sizing": "70% ",
      "border": true
    }
  ]
}
[/block]


1. ### To start, select multiple transactions that you would like to categorize using the checkboxes (at least two transactions required).

   Note: These transactions will need to be similar in nature. For example inflow transactions can be bulk categorized with other inflow transactions. Outflow transactions can be bulk categorized with other outflow transactions.

   [block:image]{"images":[{"image":["https://files.readme.io/9e6953f-Bulk_Categorization_-_Step_1.png",null,""],"align":"center","sizing":"70% ","border":true}]}[/block]
2. ### In this example we have selected multiple contract execution fee transactions to be categorized. Once your transactions have been selected, navigate to "Categorize"

   [block:image]{"images":[{"image":["https://files.readme.io/8defb24-Bulk_Categorization_-_Step_2.png",null,""],"align":"center","sizing":"70% "}]}[/block]
3. ### Select your "Category" from the drop down menu. This category will be applied to all transactions selected.

   [block:image]{"images":[{"image":["https://files.readme.io/933e732-Bulk_Categorization_-_Step_3.png",null,""],"align":"center","sizing":"70% "}]}[/block]
4. ### Select your "Fee Contact" from the drop down menu.

   [block:image]{"images":[{"image":["https://files.readme.io/8b88c36-Bulk_Categorization_-_Step_4.png",null,""],"align":"center","sizing":"70% "}]}[/block]
5. ### Click "Save"

   [block:image]{"images":[{"image":["https://files.readme.io/490ed59-Bulk_Categorization_-_Step_5.png",null,""],"align":"center","sizing":"70% "}]}[/block]
6. ### SUCCESS! You've bulk categorized your transactions!

   [block:image]{"images":[{"image":["https://files.readme.io/d8fe3b2-Bulk_Categorization_-_Step_6.png",null,""],"align":"center","sizing":"70% "}]}[/block]
