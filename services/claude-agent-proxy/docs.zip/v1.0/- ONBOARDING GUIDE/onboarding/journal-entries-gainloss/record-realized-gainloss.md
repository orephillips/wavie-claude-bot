---
title: "Record Realized Gain/Loss"
slug: "record-realized-gainloss"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:38:29 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:46:35 GMT+0000 (Coordinated Universal Time)"
---
**Calculating & Recording Realized Gain/Loss**  
When a disposal occurs, Bitwave compares the value of the disposed asset at the time of disposal (the market value at time of disposal) vs. the cost basis of the asset being disposed to calculate the realized gain/loss on disposal. Bitwave reports on realized gain/loss in terms of short term vs. long term by looking at the acquisition date of the disposed lot to determine if it was held more or less than 12 months prior to disposal. The lot that is disposed of is determined by the picking strategy selected in the Inventory View setup.

It is important to note that Bitwave does not create/push a journal entry for realized gain/loss as part of the disposal transaction. This is because the Bitwave system allows for flexibility in the accounting treatments (picking strategy, valuation methodology, pricing, multiple inventories, etc.) used to calculate realized gains/losses via creating Inventory Views configured with the settings that align to the preferred accounting treatments. This means that two inventory views with different settings (e.g. one View configured with FIFO for GAAP books and one View configured with SPEC ID for tax books) will result in different realized gain/loss for the same disposal transaction. This means that at the time of categorization, Bitwave does not suppose that it knows which Inventory View/set of books that the user would like to use for realized gain/loss calculation purposes, so the system does not calculate a realized gain/loss at this time. Instead, we recommend that our users obtain the amount of realized gain/loss for any given period and record a journal entry directly in their general ledger.

Realized Gain/Loss Formula: 

![](https://files.readme.io/371f5c1-Screenshot_2024-04-08_010306.png)

**Example #1- Simple Disposal**  
● 1 BTC was acquired on Day 1 for $20,000 (USD)  
● The same 1 BTC was disposed of on Day 2 for $25,000 (USD)  
● Suppose for the purposes of this example that the disposal of 1 ETH was for the purposes of paying payroll expense.

When the transaction is categorized by the user and is pushed to the general ledger, the resulting journal entry will be “priced” using the value of the asset at the time of disposal:

![](https://files.readme.io/141ae3b-Screenshot_2024-04-08_010317.png)

Note that the JE pushed to the GL does not reflect the realized gain/loss from disposal OR the change in the cost basis of holdings resulting from the disposal.

**Realized Gain/Loss Calculation:**

![](https://files.readme.io/40dd7f7-Screenshot_2024-04-08_010328.png)

<br />

**Change in Cost Basis Calculation:**

![](https://files.readme.io/4e7c74c-Screenshot_2024-04-08_010437.png)

_\* Note that the journal entry pushed to the GL automatically for this transaction above included a credit to Bitwave Digital Assets of $25,000; however, the total reduction in cost basis should only be $20,000. This means that there is a $5,000 debit to the Bitwave- Digital Assets GL account so that the net change in cost basis is $20,000 (as calculated above)._

**To record the appropriate realized gain/loss and change in cost basis, users should record the following JE directly in their GL:**

![](https://files.readme.io/c3f19ac-Screenshot_2024-04-08_010443.png)

**Example #2- Trade Transaction**  
● 1 ETH was acquired on Day 1 for $3,000 (USD)  
● The same 1 ETH was traded on Day 2 for $4,000 USDC (price of ETH = $4,000 USD)

When the transaction is categorized by the user as a trade, Bitwave does not actually push a journal entry into the general ledger. This is because the entry that would be produced nets to zero, so the Bitwave system opts to not push the JE, which keeps the general ledger as clean as possible. The journal entry that Bitwave does NOT push to the GL would look like the following:

![](https://files.readme.io/15a326d-Screenshot_2024-04-08_010455.png)

As you can see, Bitwave always uses the value at the time of the transaction for journal entry purposes, so the journal entry that would be produced nets to zero, so no such entry is pushed to the GL.

Note that at this point, nothing has been recorded to reflect the realized gain/loss from the trade  
OR the change in the cost basis of holdings resulting from the trade.

**Realized Gain/Loss Calculation:**

![](https://files.readme.io/7328026-Screenshot_2024-04-08_010504.png)

<br />

**Change in Cost Basis Calculation:**

![](https://files.readme.io/abe426f-Screenshot_2024-04-08_010509.png)

_\* Note the change in cost basis resulting from the trade equals the gain/loss on the trade._

To record the appropriate realized gain/loss and change in cost basis, users should record the following JE directly in their GL:

![](https://files.readme.io/9279ecc-Screenshot_2024-04-08_010514.png)

**How to find the amount of realized gain/loss for any period:**

Navigate to the Inventory Views section and then the Reports Tab. Select the Cost Basis Rollforward report.

![](https://files.readme.io/45388cd-Picture1.png)

Choose the desired date range and select the Run Report button.

The report can be downloaded as a CSV file by clicking the Download Report button.

![](https://files.readme.io/c38699f-Picture2.png)

To see the details of the gain/loss calculation on a lot-by-lot level basis, navigate to the Actions tab, select the end date of your desired date range, and click Submit.

![](https://files.readme.io/bd8c379-Picture3.png)

The Actions report can be downloaded by clicking on the Download Actions button on the right  
side.
