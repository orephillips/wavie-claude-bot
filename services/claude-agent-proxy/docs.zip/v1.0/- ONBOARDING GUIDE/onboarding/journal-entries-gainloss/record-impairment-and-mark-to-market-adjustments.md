---
title: "Record Impairment and Mark-to-Market Adjustments"
slug: "record-impairment-and-mark-to-market-adjustments"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:38:22 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:46:47 GMT+0000 (Coordinated Universal Time)"
---
Calculating & Recording Impairment Expense  
Bitwave calculates impairment expense via a daily impairment “test.” When an Inventory View has been configured with a valuation methodology to calculate impairment , the Bitwave system will compare the cost basis rate or carrying value (cost basis - impairment) rate (if previously impaired) vs. the low price of that asset for the day (note that the inventory view can be configured to utilize close, open, high, or low price of the day for the purposes of the daily impairment test).

**Example**  
● 3 SOL were acquired on Day 1 for a total of $75 USD  
         - The cost basis rate for this lot of SOL would be $25 per SOL  
● On Day 2, the price of SOL dropped to $21 per SOL  
● On Day 3, the price of SOL dropped to $19 per SOL  
● On Day 4, the 3 SOL are sold for a total of $60 ($20 per SOL)

On Day 2, the Bitwave impairment test would compare the low price of the day of $21 vs. the cost basis rate of $25 to determine that an impairment action is needed (because the low price of the day was lower than the cost basis rate). Bitwave would calculate the impairment expense as:

![](https://files.readme.io/ff6a335-Screenshot_2024-04-08_013803.png)

_\*In order to record the impairment expense and corresponding change in cost basis, users should record the following JE directly in their GL:_

![](https://files.readme.io/34797b8-Screenshot_2024-04-08_013813.png)

On Day 3, the Bitwave impairment test would compare the low price of the day of $19 vs. the carrying value rate of $21 to determine that an impairment action is needed (because the low price of the day was lower than the carrying value rate). Note that because this lot of SOL had been previously impaired, Bitwave will use the carrying value rate for this lot instead of the cost basis rate for the impairment test. Bitwave would calculate the impairment expense as:

![](https://files.readme.io/dd72fcb-Screenshot_2024-04-08_013823.png)

_\*To record the impairment expense and corresponding change in cost basis, users should record the following JE directly in their GL:_

![](https://files.readme.io/8a5175e-Screenshot_2024-04-08_013830.png)

_Note that when using impairment, Bitwave tracks the carrying value of every lot and uses the carrying value for realized gain/loss calculation purposes if an impaired lot is disposed of. In the example above, Bitwave would maintain a carrying value of $19 per SOL and use the carrying value disposed of instead of historical cost basis because the lot had been impaired. The historical cost basis will be used for realized gain/loss on disposal for any lots that have not  
been impaired._

On Day 4, Bitwave would calculate the realized gain/loss on disposal of the 3 SOL as follows:

![](https://files.readme.io/fca674c-Screenshot_2024-04-08_013841.png)

_\*To record the appropriate realized gain/loss and change in cost basis, users should record the following JE directly in their GL:_

![](https://files.readme.io/f69297a-Screenshot_2024-04-08_013846.png)

**How to find the amount of impairment expense for any period:**

Navigate to the Inventory Views section and then the Reports Tab. Select the Cost Basis Rollforward report.

![](https://files.readme.io/35f8a6e-Picture1.png)

Choose the desired date range and select the Run Report button.

The report can be downloaded as a CSV file by clicking the Download Report button.

![](https://files.readme.io/e050e1c-Picture2.png)

![](https://files.readme.io/8266e0b-Picture3.png)
