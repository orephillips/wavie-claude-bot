---
title: "Manually Record Journal Entry Totals"
slug: "manually-record-journal-entry-totals"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:38:15 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue May 14 2024 17:06:04 GMT+0000 (Coordinated Universal Time)"
---
**When would this be applicable?**

Bitwave integrates to most major ERP platforms and therefore allows you to automatically connect your Bitwave instance to your chosen ERP.  When Bitwave is connected to your ERP, the user can automatically "push" or "Sync" Bitwave created journal entries into your ERP.   See [Connect General Ledger Software](https://docs.bitwave.io/docs/connect-general-ledger-software) for details on connecting your ERP.

However if a user chooses not to connect their ERP to Bitwave (for various reasons), the platform provides a way to generate your journal entries and manually book those journal entries into your ERP.

**How to obtain required information to manually book journal entries?**

_Standard Journal Entries_

 Bitwave detailed standard journal entry information the using the following reports:

1. Rolled Up Journal Entry Report: This report contains all journal entries performed within a defined period aggregated by Contact (i.e. vendor or customer). It can be accessed by going to Left Menu -> Report ->  Rolled Up Journal Entry Report.
2. Journal Entry Report: This report contains all journal entries performed within a defined period on a transaction by transaction basis . It can be accessed by going to Left Menu -> Report ->  Journal Entry Report

In order to obtain the total standard journal entries for the period you can execute the follow steps:

1. Run the Rolled Up Journal Entry Report for your relevant period as seen below

   1. ![](https://files.readme.io/885937b-image.png)

      <br />
2. Once the report generates scroll to the bottom of the report (in the UI or downloaded) and obtain the report totals. 

   1. The report shows the required journal entries summarized by contact.  These are the journals that can be manually created in your ERP

         ![](https://files.readme.io/1f88a35-image.png)  
      Note that if there is a need to manually create journal entries on a transaction by transaction basis. The same procedure as noted above can be performed just using a different report: the Journal Entry Report

_Adjustment Journal Entries (i.e. Gains/Losses, Impairment, Mark to Market)_

Bitwave provides adjustment (impairment, realized and mark to market journal entry information) using the following reports:

1. Bitwave Inventory Views Actions Report: This reports contains transaction by transaction detail of realized gain, and impairment adjustments that can be summed up to produce your adjustment journal entries. This report can be accessed by going to Left Menu -> Inventory View -> Actions Tab (Or Reports Tab) -> Download Actions Report. 
2. Cost Basis Rollforward Report: This report contains a rollforward of your cost basis/carrying value specifically including, beginning cost basis/carrying value, increases to cost basis, decreases to cost basis, realized and unrealized gain/losses, impairment and ending cost basis / carrying value

Booking adjustment journal entries is covered in detailed in the following guide links:

- [Recording impairment and mark to market journal entries](https://docs.bitwave.io/docs/record-impairment-and-mark-to-market-adjustments)
- [Recording realized gain and loss journal entries](https://docs.bitwave.io/docs/record-realized-gainloss)\_

An important note about adjustment journal entries is that Bitwave does not automatically sync adjustment journal entries into your ERP as they require a robust amount of review and validation by the user.\_

**Conclusion**

In summary, Bitwave allows users to directly connect their ERP to the platform and auto "push" or "sync" JEs to the ERP but in the event that the user chooses not to connect their ERP to Bitwave, the platform offers a number of reports identified above that allow the user to manually obtain and book the required Journal entries in their ERP.
