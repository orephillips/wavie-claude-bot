---
title: "Login to Bitwave"
slug: "login-to-bitwave"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:30:05 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Apr 24 2024 21:46:26 GMT+0000 (Coordinated Universal Time)"
---
### Login Steps

1. You will receive an invitation to join Bitwave from [info@bitwave.io](mailto:info@bitwave.io).
2. Click "Go to Bitwave".

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e8ffba7-Screenshot_2024-02-22_231315.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. Click Sign in with either Email, Google ,Xero, or SSO.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/524d8db-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Once signed in, you will receive a notification to join your organization.  
   Click the green check mark to accept.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3bb6447-Screenshot_2024-02-22_231501.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. To access and navigate through all the organizations you have been invited to, click here.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/074084c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Welcome to your Organization !!!

### Video Walkthrough

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F-4T7jrbA4DY%3Ffeature%3Doembed&display_name=YouTube&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D-4T7jrbA4DY&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F-4T7jrbA4DY%2Fhqdefault.jpg&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=youtube\" width=\"640\" height=\"480\" scrolling=\"no\" title=\"YouTube embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=-4T7jrbA4DY",
  "title": "Segment 0: Login to Bitwave",
  "favicon": "http://www.google.com/favicon.ico",
  "image": "https://i.ytimg.com/vi/-4T7jrbA4DY/hqdefault.jpg",
  "provider": "youtube.com",
  "href": "https://www.youtube.com/watch?v=-4T7jrbA4DY",
  "typeOfEmbed": "youtube"
}
[/block]
