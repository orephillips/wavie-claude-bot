---
title: "Import Data into Manual Wallets"
slug: "import-data-into-manual-wallets"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:32:50 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu May 30 2024 16:37:32 GMT+0000 (Coordinated Universal Time)"
---
## Manual Imports

> 🚧 For TRADES use Standard Imports. DO NOT USE ADVANCED IMPORTS.

In Bitwave we are able to import manual transactions for data that may not be able to be imported through our traditonal connections. We are able to import many different types of transactions such as:

- Deposits
- Withdrawals
- Trades
- Internal Transfers
- Staking Rewards
- Fees
- More....

The import file has many different functions as to how to handle your data. The functions include:

- Setting the cost basis
- Categorizing transactions
- Grouping transactions
- Adding memos
- Inputting From/To addresses
- Overriding transactions

### How to Use Standard Imports

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FcivlHNiMXQw%3Ffeature%3Doembed&display_name=YouTube&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DcivlHNiMXQw&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FcivlHNiMXQw%2Fhqdefault.jpg&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" title=\"YouTube embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=civlHNiMXQw",
  "title": "Segment 3d: Import Data from External Sources",
  "favicon": "http://www.google.com/favicon.ico",
  "image": "https://i.ytimg.com/vi/civlHNiMXQw/hqdefault.jpg",
  "provider": "youtube.com",
  "href": "https://www.youtube.com/watch?v=civlHNiMXQw",
  "typeOfEmbed": "youtube"
}
[/block]


### How to Use Advanced Imports

1. Go to Transactions -> Import Advanced -> Click on New Import.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/60f85ad-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


2. We offer multiple types of imports. The standard import file is called “Bitwave Standard Transaction”.  
   Choose this option and click on “Download Sample File”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b55c7c7-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e39005d-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


3. After opening the sample file, delete all rows except the first row (Header Row). Your file should look like this

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1e02350-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a987a1a-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


4. Please use this guide to create your import file:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ae6eb35-Green_Clean_and_Contemporary_Employee_Handbook_Training_Manual_Booklet-pages.jpg",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


5. Now that your file is ready to import go back to Step 2, and click on “Next”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/502ba2b-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


6. Click on “Choose File” then after you picked your file, click on “Upload”.  
   After your file is finished uploading, click on “Generate Preview”.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/16b929c-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


7. This is a preview of your data. Click on “Validate"

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c4a5a04-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


8. On the “Validate” step, this will tell you if any issues or errors are found (Highlighted in RED). Using the column,  
   “StatusText”, you are able to decipher the problem. Using the Tips given in Step 4, find the fix. If file is has no  
   failing transactions then click on “Run Import”

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eea3ee6-image.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/35b3edc-10.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


9. Your file has Imported! Confirm on the Transactions page that the number of  
   transactions matches your import file.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e0b3c61-11.png",
        null,
        ""
      ],
      "align": "center",
      "border": true
    }
  ]
}
[/block]


### Common Errors While Uploading Standard Imports

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.loom.com%2Fembed%2Fa74b51e1fbdf46639d26e880f7139edf&display_name=Loom&url=https%3A%2F%2Fwww.loom.com%2Fshare%2Fa74b51e1fbdf46639d26e880f7139edf&image=https%3A%2F%2Fcdn.loom.com%2Fsessions%2Fthumbnails%2Fa74b51e1fbdf46639d26e880f7139edf-1675089433686.gif&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=loom\" width=\"1440\" height=\"500\" scrolling=\"no\" title=\"Loom embed\" frameborder=\"0\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.loom.com/share/a74b51e1fbdf46639d26e880f7139edf",
  "title": "VE - Common Upload Errors",
  "image": "https://cdn.loom.com/sessions/thumbnails/a74b51e1fbdf46639d26e880f7139edf-1675089433686.gif",
  "provider": "loom.com",
  "href": "https://www.loom.com/share/a74b51e1fbdf46639d26e880f7139edf",
  "typeOfEmbed": "youtube"
}
[/block]
