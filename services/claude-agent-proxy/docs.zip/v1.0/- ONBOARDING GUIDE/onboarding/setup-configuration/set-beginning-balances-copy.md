---
title: "Set Beginning Balances (OLD VERSION)"
slug: "set-beginning-balances-copy"
excerpt: ""
hidden: true
createdAt: "Tue Apr 23 2024 22:34:10 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Apr 23 2024 22:34:55 GMT+0000 (Coordinated Universal Time)"
---
<br>

Option 1:

Establish beginning balances using the complete Bitwave transaction history from the earliest date available and integrate all detail to a connected accounting software.  
Categorize all activity in Bitwave  
Reconcile all activity in Bitwave

Option 2: 

Establish beginning balances using the complete Bitwave transaction history from the earliest date available and integrate current year activity to a connected accounting software.  
Generically categorize all activity in Bitwave prior to current year  
Categorize current year activity in Bitwave  
Reconcile current year activity Bitwave  
Mark as Reconcile prior year history in Bitwave (Mark as Reconcile does not push to an accounting software)

Options 3: 

Establish beginning balances using existing internal records and integrate current year activity to a connected accounting software.  
Ignore activity in Bitwave before current year  
Create deposits in Bitwave to establish wallet balances at historical cost. (This may require multiple deposits if there are multiple lots)  
Categorize current year activity in Bitwave  
Reconcile current year activity Bitwave
