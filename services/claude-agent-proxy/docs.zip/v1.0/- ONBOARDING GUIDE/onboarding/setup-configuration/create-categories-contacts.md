---
title: "Create Categories & Contacts"
slug: "create-categories-contacts"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:30:20 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 25 2024 19:24:56 GMT+0000 (Coordinated Universal Time)"
---
In Bitwave, managing contacts and categories plays a crucial role in accurately categorizing transactions and organizing financial data. Whether you're dealing with vendors, customers, or different types of transactions, having the right contacts and categories set up ensures effective accounting practices.

If a category or contact is manually created within Bitwave, the “source” will be identified as Bitwave, indicating that it was manually generated within the platform and not synchronized from an ERP. Here's a step-by-step guide on how to manually create contacts and categories in Bitwave:

### Create Manual Contacts

Contacts refer to the vendors and customers involved in transactions, providing essential details about who each transaction is made to or received from. These contacts can be created either manually in Bitwave or synced from your ERP system. Assigning a contact to every transaction during categorization helps track financial interactions and  
maintain accurate records.

1. Go to “**Accounting **“ tab on the top left corner

![](https://files.readme.io/60be224-Screenshot_2024-03-04_at_4.16.57_PM.png)

2. Click on **Contacts**

   ![](https://files.readme.io/6be324b-Screenshot_2024-03-04_at_4.57.01_PM.png)

3. Click on **Create Contact**

   ![](https://files.readme.io/28ca0aa-Screenshot_2024-03-04_at_5.04.16_PM.png)

4. Fill out the Contact form with relevant details and select Contact  
   Type from the drop down

![](https://files.readme.io/90d78fd-Screenshot_2024-03-04_at_5.14.14_PM.png)

5. Click “**save**”

### Create Manual Categores

Categories represent the types of transactions and are equivalent to GL (General Ledger) accounts such as expense, revenue, asset, etc. These categories can be manually created or synced from your ERP system. Properly defining categories helps classify transactions and facilitates financial reporting and analysis.

1. Go to “**Accounting**“ tab on the top left corner

![](https://files.readme.io/3fae3d9-Screenshot_2024-03-04_at_4.16.57_PM.png)

2. Click on **Categories**

   ![](https://files.readme.io/a5297c2-Screenshot_2024-03-04_at_4.57.01_PM.png)
3. .Click on **Create Category**

![](https://files.readme.io/6cfe8e7-Screenshot_2024-03-05_at_11.45.07_AM.png)

4. Fill out the Category form with relevant details and SELECT Category Type from the drop down

![](https://files.readme.io/6d887b7-Screenshot_2024-03-05_at_11.45.55_AM.png)

5. Click “**Save**”

![](https://files.readme.io/64efa10-Screenshot_2024-03-05_at_11.48.07_AM.png)
