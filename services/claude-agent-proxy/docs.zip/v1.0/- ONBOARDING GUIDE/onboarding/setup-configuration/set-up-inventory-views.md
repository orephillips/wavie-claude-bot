---
title: "Set Up Inventory Views"
slug: "set-up-inventory-views"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:37:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Apr 26 2024 02:39:45 GMT+0000 (Coordinated Universal Time)"
---
Inventory Views is a section within where you can get important information about your digital asset holdings as of any date (or date range), including:

- Holdings token quantity
- Cost basis
- Carrying Value
- Market Value
- Unrealized gain/loss position
- Realized gain/loss
- Impairment Expense
- Fair Value Adjustments

Inventory Views also enables Bitwave users to maintain multiple sets of books in parallel. This is accomplished by creating multiple inventory “Views,” with each View configured for the specific needs of each set of books. For example, it is common for our users to set up a View for their GAAP accounting books and a separate VIew for their tax books, each with their appropriate accounting settings.

### To Set Up an Inventory View

1. Go to **Inventory** Tab on the right hand side then Click the “**Create View**” button

![](https://files.readme.io/612dbf3-Picture1.png)

2. Configure Settings According to Preferred Accounting Treatments

   ![](https://files.readme.io/4bb3de6-Picture2.png)

### Available Configuration Settings

- Picking strategy: FIFO, LIFO, SPEC ID (note that SPEC ID is based on predefined disposal preferences in the Tax Strategy section of the Administration menu)
- Valuation Methodology: Historical Cost Basis, GAAP Impairment, GAAP Fair Value, IFRS Impairment, IFRS Impairment with Revaluation, Mark to Market
- Capitalize fees (determines if fees on trades should be capitalized as part of the acquired asset cost basis vs. being expensed)
- Ignore NFTs: when checked, NFTs will be ignored when calculating realized gain/loss, cost basis, etc.
- Ignore Org Wrapping Treatments: When checked, disposals and realized gain/loss calculations will ignore wrapping treatments set up in Wrapping Treatments section of the administration menu. When unchecked, all calculations will reflect the wrapping treatments.
- Multiple Inventories: This setting allows for the use of segregated inventories. Note that the relevant inventory groups and wallet assignments must be created before selecting  
  this option within the Inventory Management Section of the Administration menu.

### Advanced Settings - Engine Version

Version 2.2 or later must be selected when using multiple inventories, GAAP Fair Value, or any IFRS valuation methodologies.

**Click Expand in the Advanced Setting to view/edit the Engine Version**

![](https://files.readme.io/a85651d-Picture3.png)

**Choose the desired Engine Version in the dropdown menu and click collapse when finished.**

![](https://files.readme.io/122382b-Picture4.png)

### Running Updates

In order to populate your data, each inventory View must be updated to reflect the most recent changes to your transactions and categorization. To run an update, go to the Updates tab within Inventory Views and click the Update Now button.

![](https://files.readme.io/360230e-Picture5.png)

> 🛑 Note that an update must be run for Inventory Views reporting to reflect any changes to transactions or categorization since the last update.
