---
title: "Add Wallets, Exchanges, Custodial, Manual"
slug: "add-wallets-exchanges-custodial"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:30:40 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Apr 24 2024 20:33:19 GMT+0000 (Coordinated Universal Time)"
---
Our wallets page is where our users can add their crypto wallets/accounts and other sources of digital asset transaction date.

**There are a few different types of wallets/data sources that a user may want to add to Bitwave:**

- **On chain wallets**: these are wallets that are directly syncing to the blockchain network such as Bitcoin, Ethereum, Polygon, Ripple, Solana, Optimism, NEAR, BASE, Avalanche...
- **Exchanges**: these are accounts for cryptocurrency exchanges such as Coinbase, Kraken, Binance...
- **Custodial accounts**: these are accounts for custody services providers such as Anchorage, Fireblocks, Bitgo...
- **Manual Wallets**: these are unsynced wallets that can be used for imported transactions

## :sunflower: Add Wallets

[Onchain Wallets](https://docs.bitwave.io/docs/onchain-wallets)

## :sunflower: Add Exchanges

[Exchanges](https://docs.bitwave.io/docs/exchanges-1)

## :sunflower: Add Custodial Accounts

[Custodial](https://docs.bitwave.io/docs/custodial)

## :sunflower: Create Manual Wallets

[Manual](https://docs.bitwave.io/docs/manual)
