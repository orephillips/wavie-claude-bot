---
title: "Connect General Ledger Software"
slug: "connect-general-ledger-software"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:30:12 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Nov 14 2024 21:33:57 GMT+0000 (Coordinated Universal Time)"
---
![](https://files.readme.io/d024af6-image.png)

**Integrations Available:**

- Quickbooks Online
- Xero
- Netsuite
- Sage Intacct
- Request Finance

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/38f5438-image.png",
        null,
        ""
      ],
      "align": "center",
      "sizing": "-10px"
    }
  ]
}
[/block]


### Quickbooks Online Setup

[QUICKBOOKS SETUP](https://docs.bitwave.io/docs/quickbooks) 

### Xero Setup

[XERO SETUP](https://docs.bitwave.io/docs/xero)

### Netsuite Setup

[NETSUITE SETUP](https://docs.bitwave.io/docs/netsuite)

### Sage Setup

[SAGE SETUP](https://docs.bitwave.io/docs/sage-intacct-configuration-guide)

### Request Setup

REQUEST SETUP (guide coming soon!)
