---
title: "Set Accounting Defaults"
slug: "set-accounting-defaults"
excerpt: "Accounting Defaults for Gas Fees, AP, & AR"
hidden: false
createdAt: "Wed Apr 17 2024 18:30:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Apr 26 2024 17:25:36 GMT+0000 (Coordinated Universal Time)"
---
Bitwave uses Accounting Defaults to automatically apply contacts and categories to specific transaction types. Simply select “Allow Transactions Inference”, your primary network, network contact, and default fee category and Bitwave will auto-apply those settings to fee transactions. AP and AR defaults are available in Bitwave’s Invoice & Bill Payment module.

- What you need to get started:  
  Your ERP connected to Bitwave with your categories and contacts synced in.
- If you are not connecting your ERP then create:

1. Contact for Gas Fees
2. Category for Fees
3. Category for Accounts Receivable (AR)
4. Category for Accounts Payable (AP)

([How to setup Contacts & Categories](https://docs.bitwave.io/docs/create-manual-categories-in-bitwave))

**Navigate to Accounting Setup by selecting Administration - - > Accounting Setup from the menu:**

![](https://files.readme.io/87c2b4b-Picture1.png)

Your contacts and categories are pre-populated in the dropdown sections of the Accounting Setup page.

Step 1: Select a Default Gas Fee Contact for Ethereum Network from the dropdown menu.

![](https://files.readme.io/74a8a8d-Picture2.png)

Step 2: Select a Default Fee Category from the dropdown menu.

![](https://files.readme.io/bcc285b-Picture3.png)

Step 3: Select a Default Accounts Receivable Category from the dropdown.

![](https://files.readme.io/490b7dd-Picture4.png)

Step 4: Select a Default Accounts Payable Category from the dropdown.

![](https://files.readme.io/b96b53a-Picture5.png)

Step 5: Click “Save”

![](https://files.readme.io/a739511-Picture6.png)

Your Accounting Setup is now complete!
