---
title: "Check Wallet/Account Balances"
slug: "check-wallet-account-balances"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:37:28 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Jun 07 2024 19:15:59 GMT+0000 (Coordinated Universal Time)"
---
Ensuring that your wallet balances in Bitwave matches your onchain wallet balances is critical to accounting for your digital assets. The steps below outline how to perform a balance check on your wallets and exchanges.

In this guide, we will use the Bitwave balance report and compare those balances to what is shown on chain/in an exchange.

0. Checking that Connection is Live  
   Ensure all of your wallet and exchange connections are live.  
   If a wallet or API key was added incorrectly, then transactions from this wallet will not appear. Check that the connection is live by reviewing the wallet or connection in the wallet dashboard and that balances are appearing there. Even if balances are 0, it should still show here. Ensure transactions are showing up in the Transactions UI. We recommend waiting at least 24 hours before performing any balance validation in order to give Bitwave time to sync all transactions.

(Wallets balance - dashboard)\*

The image above shows a connection that is live.  
Our objective is to confirm the balances shown in bitwave match the balances that are onchain.In order to do this we need to compare the balances as of the exact same block number(time). There are several ways to do this and the methodology you select will be based mostly on tnx volume. The following guide will explain this in more detail.

Validating Balances using the Balance Check Report  
The balance check report can be used to compare your Bitwave org balances with onchain/exchange wallet balances. 

Head to the reports tab and find the balance check report.

Select the date you wish to validate for, and click run report.

Notes: Some token balances will not appear in this report and therefore will not be validated. This function is only available 48 hours after wallets/exchanges have been plugged in. 

Comparing Balances Manually as of ‘right now’

1. Run Bitwave Balance Report  
   Running the Bitwave Balance Report will give you your balances per asset and per wallet based on the transactions that are syncing into Bitwave. You can see these in the transactions UI.  
   Note: The wallets dashboard and Bitwave Balance Report pull balances from entirely different sources. The wallets dashboard pulls data directly from onchain or from an exchange, meaning we CANNOT use this to validate balances.

How to run the Bitwave Balance Report:

- Go to Reports → Balance Report
- Select today’s date, group by wallet and ‘All’ in the wallet field.
- Click RUN REPORT

This will give you the up to date balances of all your wallets, based on what has synced into Bitwave.

2. Download Balance report as CSV and export to a spreadsheet.

3. Browse for an on-chain balance checker to get the exact balances of each asset on-chain. E.G. for ethereum, we can use etherscan.io.

Simply compare the balances in etherscan to the balances shown by the balance report.

Comparing Balances Manually as of a Specific Point in Time  
There are times when you want to compare balances to a specific point in time. For this, we will use <https://etherscan.io/balancecheck-tool>. If you are not checking for an Ethereum wallet, you will need to use the balance check tool specific to the chain you are using. 

Run the Bitwave balance report at a specific time. For example, 31/12/2023, and export the balances to a spreadsheet. Make sure to copy the block number found in the balance report.

Etherscan balance checker (<https://etherscan.io/balancecheck-tool>) is an on-chain tool to check the balances of any ethereum based wallet at any point in time. Use the wallet address, the token contract address(if required) and the block number to find the onchain ETH/token balance. 

Finding the ETH balance

Finding a token balance. 

To Validate the Exchange Balances

1. Checking that Connection is Live

Ensure all of your exchange connections are live. If a wallet or API key was added incorrectly, then transactions from this wallet will not appear. Check that the connection is live by reviewing the wallet or connection in the wallet dashboard and that balances are appearing there. Even if balances are 0, it should still show here.

Ensure transactions are showing up in the Transactions UI. We recommend waiting at least 24 hours before performing any balance validation in order to give Bitwave time to sync all transactions,

The image above shows an Exchange/Connection is live. The token balances shown in the Dashboard are coming from the Exchange API.

Validating Balances using the Balance Check Report

The Balance report can be used to compare your Bitwave org balances with exchange wallet balances. 

In the left-hand corner of your Bitwave app, go to "Wallets & Connection."  
Navigate to "Reports."  
Click on "Balance Report"  
Select yesterday’s date, group by wallet and select the Exchange in the wallet field of which you have to compare the balance.  
Click RUN REPORT  
Download Balance report as CSV and export to a spreadsheet.  
.

This will give you the up to date balances of all your exchange wallet, based on transactions which have synced into Bitwave.

To perform the Balance check you will need to compare the Dashboard Exchange Balances with the Balance Report Balances.
