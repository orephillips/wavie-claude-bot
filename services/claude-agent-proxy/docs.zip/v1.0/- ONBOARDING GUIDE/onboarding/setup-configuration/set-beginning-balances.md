---
title: "Set Beginning Balances"
slug: "set-beginning-balances"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:37:19 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu May 23 2024 19:44:36 GMT+0000 (Coordinated Universal Time)"
---
## The Beginning Balance Process:

Bitwave allows you to create manual entries in order to establish wallet beginning balance quantities and cost basis.  If this lot level detail for current quantities is not something that is available then it is recommended to establish beginning balances using the complete Bitwave transaction history from the earliest date available.

### When do we have to set "beginning balances"?

Some customers intend to use Bitwave to categorize all their historical transactions (for all time). These customers do not need to have beginning balances "set" in Bitwave.

Customers that are coming to Bitwave having completed their accounting for prior periods using a different system (either in another software or in spreadsheets) will want to have a "Starting Point" in Bitwave (e.g. they completed 2021 accounting elsewhere but want to use Bitwave starting 1/1/2022)

### How do we set beginning balances?

There are two paths:

> 👍 Path 1: You have your beginning balances and cost basis.

For this to work, the customers beginning balance data must have:

- Token balance by wallet
- Acquisition date of each lot they want in their beginning balance
- Cost basis of each lot

**To execute Path 1:**

- [ ] **STEP 1:** Import beginning balance lots (provided in a CSV file) into either:
- A manual wallet called "beginning balances" and then you create internal transfer transactions from that manual wallet to the actual wallets so that the beginning wallet balances are correct
- If you know what lots you want in each wallet, you can import the beginning balance lots directly to the actual wallet that will be used going forward

> NOTE: For the "COST" columns to work on the import (to set your cost basis), you MUST categorize on the import file via the category and contact ID columns

- [ ] **STEP 2:**  Run system jobs to ignore all transactions prior to the beginning balance date

> 👍 Path 2: You don't have your beginning balance info or do but want to see how Bitwave numbers will compare.

> (Note: even if you have done their accounting well prior to bitwave, Bitwave will likely calculate a different beginning balance cost basis numebr because we are likely using a different pricing data source, so all the transactions will have different exchange rates vs. what you have used in the past).

**To execute Path 2:**

- [ ] **STEP 1:** First, you need to have all historical data in. This may be a combination of connected wallets and imports (for historical data we recommend importing data for exchanges/custodial services). Guidance on how to import data, please refer to the ["Import Data Into Manual Wallets"](https://docs.bitwave.io/docs/import-data-into-manual-wallets)guide.
- [ ] **STEP 2:** Create a "beginning balance" category AND contact that can be used to categorize all historical data prior to the desired beginning balance date. This can be done via your connected ERP or you could create a manual category/contact in Bitwave.
- [ ] **STEP 3:** Create "blanket" rules to categorize all transactions prior to beginning balance date, using the category and contact created in Step 2.
- [ ] **STEP 4:** Run system jobs to "MARK AS RECONCILED" all transactions prior to beginning balance date. (Mark as Reconcile does not push to an accounting software).
