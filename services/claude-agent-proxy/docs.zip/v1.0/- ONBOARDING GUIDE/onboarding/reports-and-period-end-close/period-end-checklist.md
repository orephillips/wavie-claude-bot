---
title: "Period End Checklist"
slug: "period-end-checklist"
excerpt: ""
hidden: false
createdAt: "Wed Apr 24 2024 01:18:08 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 10 2024 22:40:18 GMT+0000 (Coordinated Universal Time)"
---
**Period End Checklist**

The following is the period end checklist we recommend while using Bitwave. We also encourage users to expand upon this checklist adding specific nuances that are relevant to their specific finance business processes. The standard template can be found at the following link: [Close Checklist](https://docs.google.com/spreadsheets/d/1kstM7WbYOEyI2N_5nrlzR1xtMg1qLfyKQznMe_p_kNA/edit#gid=1083317839)

![](https://files.readme.io/42217fa-image.png)

**Confirmations**

1. **Confirm All Transactions have been Categorized and Reconciled: **This is the first and foundational confirmation step as in order to close a period all transactions in that period and PRIOR must be fully categorized, and where Bitwave is connected to an ERP synced (or reconciled).  This step must be executed if the user is to rely on any subsequent data in the close process. To perform this validation:

   1. Go to Left Menu -> Transaction
   2. On the Transaction Screen select the End Date
   3. Ensure that there are NO uncategorized transactions as of that end date.
   4. IF you are connected to an ERP ensure there are no TO BE reconciled transactions (ie. indicating they have not been pushed to your ERP)
   5. ![](https://files.readme.io/a65c39c-image.png)

      <br />
2. **Confirm All JES are in GL:**This involves a confirmation that all the bitwave JEs have been successfully synced to your ERP. To perform this validation:
3. Run the Bitwave Rolled Up Journal Entry Report

   1. ![](https://files.readme.io/be0b5c3-image.png)

      The report total reflects the TOTAL Debits to Digital Assets and the total Credits to Digital Assets. 
   2. The net of this amount should be the CHANGE in your digital asset account.
4. Go to your ERP and run the a report that will show you the CHANGE in the digital asset account in the same period
5. The results from (i) should match the results from (ii)

**Reconciliations**

   The following link covers the period end reconciliation in full detail: [Period End Reconciliation](https://docs.bitwave.io/docs/period-end-reconciliation) However in summary:

1. The following are the steps for executing the period end reconciliation process. They can also be found by going to Left Menu ->  Accounting -> Period End Close
2. ![](https://files.readme.io/8c55a4a-image.png)

   <br />

**Adjustments**

Each company varies in terms of what period end adjustments are relevant including impairment, mark to market, realized gains and losses etc. The following link covers typical period end adjustments and how to obtain the values to achieve them in bitwave

- [Impairment and mark to market adjustments](https://docs.bitwave.io/docs/record-impairment-and-mark-to-market-adjustments)
- [Realized Gains and Losses](https://docs.bitwave.io/docs/record-realized-gainloss)

**Close**

Once you have completed this period end reconciliation, you are ready to close your books for the period in your ERP environment. 

A complementary internal control that ensures the accuracy and completeness of your Bitwave data is to [Lock Transactions](https://docs.bitwave.io/docs/locking-periods). Once your period is locked, no new data may be synced in and this acts as a safeguard for any user error.

![](https://files.readme.io/4cbb900-image.png)
