---
title: "Period End Reconciliation"
slug: "period-end-reconciliation"
excerpt: ""
hidden: false
createdAt: "Wed Apr 24 2024 01:18:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 25 2024 15:43:19 GMT+0000 (Coordinated Universal Time)"
---
## Video Walkthrough

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.loom.com%2Fembed%2F9f871709cc5a4142bf9c11e54f9bb1bf&display_name=Loom&url=https%3A%2F%2Fwww.loom.com%2Fshare%2F9f871709cc5a4142bf9c11e54f9bb1bf&image=https%3A%2F%2Fcdn.loom.com%2Fsessions%2Fthumbnails%2F9f871709cc5a4142bf9c11e54f9bb1bf-1675232295266.gif&key=7788cb384c9f4d5dbbdbeffd9fe4b92f&type=text%2Fhtml&schema=loom\" width=\"1728\" height=\"500\" scrolling=\"no\" title=\"Loom embed\" frameborder=\"2\" allow=\"autoplay; fullscreen; encrypted-media; picture-in-picture;\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.loom.com/share/9f871709cc5a4142bf9c11e54f9bb1bf",
  "title": "Videos Everywhere - Period End Recon",
  "image": "https://cdn.loom.com/sessions/thumbnails/9f871709cc5a4142bf9c11e54f9bb1bf-1675232295266.gif",
  "provider": "loom.com",
  "href": "https://www.loom.com/share/9f871709cc5a4142bf9c11e54f9bb1bf",
  "typeOfEmbed": "youtube"
}
[/block]


<br />

## Introduction

The Period End Reconciliation worksheet is completed as part of the month end checklist. This process is used to verify that the categorized activity adjusted for realized and unrealized gain loss agrees with the fair value balance at period end.

> 📘 The Calculation:
> 
> **Prior Period Expected Register + Current Period Net Debit/Credits + Current Period Realized G/L +   Current Period Unrealized G/L = Period End Balance at FMV**

<br />

## How to Complete the Period End Reconciliation Worksheet

![](https://files.readme.io/d1df266-image.png)

**Step 1: How to run Balance Report:**

The Balance Report is ran to verify fair market value as of the period end for all activity (categorized & uncategorized)

**Step 2: How to run Journal Entry Report (Rolled up):**

The Journal Entry Report (Rolled up) is ran to verify the net debits and credits of categorized activity for the period.

Login > Report Center > Rolled up Journal entry report > Select the date range and accounting connection > Run the report > find the Debit/Credit figures from the bottom. 

**Step 3: How to run Cost Basis Roll Forward Report:**

The Cost Basis Roll Forward Report is ran to verify the realized and unrealized gain/loss for the period.

<br />

## How to Reclassify from One Digital Asset Account to Multiple Asset Accounts:

**Step 1: Go to inventory view Reports and select Reclass**

![](https://files.readme.io/e1f4cf2-image.png)

**Step 2: Filter to your specific From and To range.**

![](https://files.readme.io/501e36b-image.png)

**Step 3: Download Report and save to excel.**

![](https://files.readme.io/39d550e-image.png)

> 🚧 NOTE:
> 
> 1. These reclass amounts assume there has already been a realized gain/loss entry made to your Bitwave - Digital Asset account
> 2. These reclass amounts to not include a reclass to unrealized gain/loss
