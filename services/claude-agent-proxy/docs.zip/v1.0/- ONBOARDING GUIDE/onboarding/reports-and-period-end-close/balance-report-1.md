---
title: "Balance Report"
slug: "balance-report-1"
excerpt: ""
hidden: false
createdAt: "Wed Apr 17 2024 18:38:56 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 18 2024 04:59:31 GMT+0000 (Coordinated Universal Time)"
---
<p>This report allows you to query the balance and FMV of each digital asset at the end of any given date.</p>
<p><br /></p>
<p>1. Run the Balance Report by navigating on the left menu to <strong>Reports</strong>.</p>

![](https://files.readme.io/15f9184-40e13e0-image.png)

<p>a. Select the <strong>Balance Report</strong> which allows you to query the fair market value of each digital asset at the end of the day selected at 11:59 PM (based on the entity’s timezone).</p>

<p>For example, if you wish to know what your end of day balance of BTC was on 9/22/2021, you would run the balance report for this date.</p>

![](https://files.readme.io/b50ddab-116316b-image.png)

<p>2. Select the Balance as of the end of day either grouped by wallet or without grouping. All other fields are optional.</p>

![](https://files.readme.io/90050f1-b68203e-image.png)

<p>3. Transfer the total fiat value to the Period End Close Template in row 14.</p>

![](https://files.readme.io/1ba9131-13c99f3-image.png)

***

***

***

***
