---
title: "Cost Basis Rollforward (including Gain/Loss totals)"
slug: "cost-basis-rollforward-including-gainloss-totals"
excerpt: ""
hidden: true
createdAt: "Wed Apr 17 2024 18:38:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri May 17 2024 18:13:50 GMT+0000 (Coordinated Universal Time)"
---
There are many different reports that can be run to get insight into your digital asset holdings and activity, including:  
● Holdings token quantity  
● Cost basis  
● Carrying Value  
● Market Value  
● Unrealized gain/loss position  
● Realized gain/loss  
● Impairment Expense  
● Fair Value Adjustments

**Dashboard**  
The Inventory Views Dashboard reports the following information for each asset at any selected date (EOD):  
● Token holdings  
● Cost basis  
● Market value  
● Unrealized gain/loss position

![](https://files.readme.io/fa1575e-Picture1.png)

To get your data for any given date, select a date and click submit. The information can be viewed directly on-screen or downloaded as a CSV by clicking here:

![](https://files.readme.io/81ba105-Picture2.png)

**Actions**  
Our actions report shows the lot-by-lot level detail for all actions (acquisitions, disposals, impairment, fair value adjustments, etc.). This report also shows a lot-by-lot level breakdown of the realized gain/loss calculation for each disposal, impairment expense/reversal, and fair value  
adjustments. Additionally, the actions report can be used to identify categorization details such as category, contact, wallet, and inventory (when using multiple inventories).

![](https://files.readme.io/5fbe907-Picture3.png)

To get your data for any given date, select a date and click submit. The information can be viewed directly on-screen or downloaded as a CSV by clicking here:

![](https://files.readme.io/5820b35-Picture4.png)

**Lots**  
Whereas the Dashboard displays information on holding on a per asset basis, the Lots report provides the following information for each individual lot held as of the date selected (EOD):  
● Asset  
● Lot ID  
● Acquisition date  
● Token quantity  
● Cost Basis  
● Impairment  
● Carrying Value (cost basis minus impairment)

![](https://files.readme.io/33a633f-Picture5.png)

To get your data for any given date, select a date and click submit. The information can be viewed directly on-screen or downloaded as a CSV by clicking here:

![](https://files.readme.io/7e106ec-Picture6.png)

**Cost Basis Rollforward**  
Cost Basis Rollforward report is used to see the results of your transaction activity between any two selected dates. This report shows the realized gain/loss and impairment expense for any  
selected date range, as well as:  
● Starting date cost basis and token quantity  
● Acquisitions (token quantity and functional currency value)  
● Disposals (token quantity and functional currency value)  
● Impairment Expense during date range  
● Realized Gain/Loss during date range  
● Ending cost basis and token quantity

![](https://files.readme.io/930d52b-Picture7.png)

To get your data for any given date, select a date and click submit. The information can be viewed directly on-screen or downloaded as a CSV by clicking here:

![](https://files.readme.io/92205c3-Picture8.png)

***

***

***

***
