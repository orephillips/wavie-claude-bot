---
title: "Reports and Period-End Close"
slug: "reports-and-period-end-close"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 17:00:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Mon Jun 10 2024 22:20:53 GMT+0000 (Coordinated Universal Time)"
---
# \# 4: Reports and Period-End Close

***

> 📘 - Step 1: [Cost Basis Summary (from Inventory Views)](https://docs.bitwave.io/docs/cost-basis-summary-from-inventory-views)
> - Step 2: [Cost Basis Rollforward (including Gain/Loss totals)](https://docs.bitwave.io/docs/cost-basis-rollforward-including-gainloss-totals)
> - Step 3: [Actions Report (from Inventory Views)](https://docs.bitwave.io/docs/actions-report-from-inventory-views)
> - Step 4: [Balance Report](https://docs.bitwave.io/docs/balance-report-1)
> - Step 5: [Journal Entry Reports](https://docs.bitwave.io/docs/journal-entry-reports)
> - Step 6: [Period-End Checklist](https://docs.bitwave.io/docs/period-end-checklist)
> - Step 7: [Period-End Reconciliation ](https://docs.bitwave.io/docs/period-end-reconciliation)
