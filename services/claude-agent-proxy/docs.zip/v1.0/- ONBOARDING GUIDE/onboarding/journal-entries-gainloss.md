---
title: "Journal Entries & Gain/Loss"
slug: "journal-entries-gainloss"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 17:00:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:50:10 GMT+0000 (Coordinated Universal Time)"
---
# \# 3: Journal Entries & Gain/Loss

***

> 📑 - Step 1: [Push transactions (JE's) to General Ledger](https://docs.bitwave.io/docs/push-transactions-jes-to-general-ledger)
> - Step 2: [Manually record journal entry totals](https://docs.bitwave.io/docs/manually-record-journal-entry-totals)
> - Step 3: [Record Impairment and Mark-to-Market Adjustments](https://docs.bitwave.io/docs/record-impairment-and-mark-to-market-adjustments)
> - Step 4: [Record Realized Gain/Loss](https://docs.bitwave.io/docs/record-realized-gainloss)
