---
title: "Categorization"
slug: "categorization"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 16:59:18 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 25 2024 20:51:17 GMT+0000 (Coordinated Universal Time)"
---
<br>

# \# 2: Categorization

***

> 👍 - Step 1: [Viewing Transactions](https://docs.bitwave.io/docs/viewing-transactions)
> - Step 2: [Transaction Screen operations](https://docs.bitwave.io/docs/transaction-screen-operations)
> - Step 3: [Individual transaction categorization](https://docs.bitwave.io/docs/individual-transaction-categorization)
> - Step 4: [Check Pricing Data](https://docs.bitwave.io/docs/check-pricing-data)
> - Step 5: [Set Up Categorization Rules](https://docs.bitwave.io/docs/set-up-categorization-rules)
> - Step 6: [Set Up Contact-based Categorization Defaults (including "in-line" categorization)](https://docs.bitwave.io/docs/set-up-contact-based-categorization-defaults)
> - Step 7: [Bulk Categorization](https://docs.bitwave.io/docs/bulk-categorization-1)
> - Step 8: [System Jobs](https://docs.bitwave.io/docs/system-jobs-1)
