---
title: "Setup & Configuration"
slug: "setup-configuration"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 16:53:38 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Thu Apr 25 2024 20:52:29 GMT+0000 (Coordinated Universal Time)"
---
<br>

# \# 1: Setup & Configuration

***

> 🚧 - Step 1: [Complete your Config & Setup and Wallets & Accounts tabs in the Onboarding Workbook](https://docs.google.com/spreadsheets/d/1hFH2-xUelB2xNas4U203wwY1pJXde2su/edit?usp=sharing&ouid=109123821439840915737&rtpof=true&sd=true)
> - Step 2: Review Config/Setup and Wallets/Accounts information on kickoff call
> - Step 3: [Login to Bitwave](https://docs.bitwave.io/docs/login-to-bitwave)
> - Step 4: [Connect General Ledger Software](https://docs.bitwave.io/docs/connect-general-ledger-software)
> - Step 5: [Create Categories & Contacts in Bitwave](https://docs.bitwave.io/docs/create-categories-contacts)
> - Step 6: [Set Accounting Defaults for Gas Fees, AP, & AR](https://docs.bitwave.io/docs/set-accounting-defaults)
> - Step 7: [Add Wallets, Exchanges, Custodial & Manual Wallets](https://docs.bitwave.io/docs/add-wallets-exchanges-custodial)
> - Step 8: [Import Data into Manual Wallets](https://docs.bitwave.io/docs/import-data-into-manual-wallets)
> - Step 9: [Set Beginning Balances](https://docs.bitwave.io/docs/set-beginning-balances)
> - Step 10: [Check Wallet/Account Balances](https://docs.bitwave.io/docs/check-wallet-account-balances)
> - Step 11: [Set Up Inventory Views](https://docs.bitwave.io/docs/set-up-inventory-views)
