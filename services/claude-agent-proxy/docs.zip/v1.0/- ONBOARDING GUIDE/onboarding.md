---
title: "The Onboarding Journey"
slug: "onboarding"
excerpt: ""
hidden: false
createdAt: "Mon Apr 15 2024 16:52:16 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Jun 11 2024 21:49:59 GMT+0000 (Coordinated Universal Time)"
---
![](https://files.readme.io/d11796d-poilkoj.png)

# \# 1: Setup & Configuration

***

> 🚧 - Step 1: [Complete your Config & Setup and Wallets & Accounts tabs in the Onboarding Workbook](https://docs.google.com/spreadsheets/d/1hFH2-xUelB2xNas4U203wwY1pJXde2su/edit?usp=sharing&ouid=109123821439840915737&rtpof=true&sd=true)
> - Step 2: Review Config/Setup and Wallets/Accounts information on kickoff call
> - Step 3: [Login to Bitwave](https://docs.bitwave.io/docs/login-to-bitwave)
> - Step 4: [Connect General Ledger Software](https://docs.bitwave.io/docs/connect-general-ledger-software)
> - Step 5: [Create Categories & Contacts in Bitwave](https://docs.bitwave.io/docs/create-categories-contacts)
> - Step 6: [Set Accounting Defaults for Gas Fees, AP, & AR](https://docs.bitwave.io/docs/set-accounting-defaults)
> - Step 7: [Add Wallets, Exchanges, Custodial & Manual Wallets](https://docs.bitwave.io/docs/add-wallets-exchanges-custodial)
> - Step 8: [Import Data into Manual Wallets](https://docs.bitwave.io/docs/import-data-into-manual-wallets)
> - Step 9: [Set Beginning Balances](https://docs.bitwave.io/docs/set-beginning-balances)
> - Step 10: [Check Wallet/Account Balances](https://docs.bitwave.io/docs/check-wallet-account-balances)
> - Step 11: [Set Up Inventory Views](https://docs.bitwave.io/docs/set-up-inventory-views)

# \# 2: Categorization

***

> 👍 - Step 1: [Viewing Transactions](https://docs.bitwave.io/docs/viewing-transactions)
> - Step 2: [Transaction Screen operations](https://docs.bitwave.io/docs/transaction-screen-operations)
> - Step 3: [Individual transaction categorization](https://docs.bitwave.io/docs/individual-transaction-categorization)
> - Step 4: [Check Pricing Data](https://docs.bitwave.io/docs/check-pricing-data)
> - Step 5: [Set Up Categorization Rules](https://docs.bitwave.io/docs/set-up-categorization-rules)
> - Step 6: [Set Up Contact-based Categorization Defaults (including "in-line" categorization)](https://docs.bitwave.io/docs/set-up-contact-based-categorization-defaults)
> - Step 7: [Bulk Categorization](https://docs.bitwave.io/docs/bulk-categorization-1)
> - Step 8: [System Jobs](https://docs.bitwave.io/docs/system-jobs-1)

# \# 3: Journal Entries & Gain/Loss

***

> 📑 - Step 1: [Push transactions (JE's) to General Ledger](https://docs.bitwave.io/docs/push-transactions-jes-to-general-ledger)
> - Step 2: [Manually record journal entry totals](https://docs.bitwave.io/docs/manually-record-journal-entry-totals)
> - Step 3: [Record Impairment and Mark-to-Market Adjustments](https://docs.bitwave.io/docs/record-impairment-and-mark-to-market-adjustments)
> - Step 4: [Record Realized Gain/Loss](https://docs.bitwave.io/docs/record-realized-gainloss)

# \# 4: Reports and Period-End Close

***

> 📘 - Step 1: [Cost Basis Summary (from Inventory Views)](https://docs.bitwave.io/docs/cost-basis-summary-from-inventory-views)
> - Step 2: [Cost Basis Rollforward (including Gain/Loss totals)](https://docs.bitwave.io/docs/cost-basis-rollforward-including-gainloss-totals)
> - Step 3: [Actions Report (from Inventory Views)](https://docs.bitwave.io/docs/actions-report-from-inventory-views)
> - Step 4: [Balance Report](https://docs.bitwave.io/docs/balance-report-1)
> - Step 5: [Journal Entry Reports](https://docs.bitwave.io/docs/journal-entry-reports)
> - Step 6: [Period-End Checklist](https://docs.bitwave.io/docs/period-end-checklist)
> - Step 7: [Period-End Reconciliation ](https://docs.bitwave.io/docs/period-end-reconciliation)

# Getting Started With Your Onboarding Workbook

***

### :link: [Onboarding Workbook](https://docs.google.com/spreadsheets/d/1hFH2-xUelB2xNas4U203wwY1pJXde2su/edit?usp=sharing&ouid=109123821439840915737&rtpof=true&sd=true)

**Filling Out Your Onboarding Workbook**

As part of every new customer onboarding, we prioritize gathering essential information upfront to ensure that your Bitwave instance is configured to meet your needs.

***

**Completing Your Onboarding Workbook:**

We've created a document called the [Onboarding Workbook](https://docs.google.com/spreadsheets/d/1hFH2-xUelB2xNas4U203wwY1pJXde2su/edit?usp=sharing&ouid=109123821439840915737&rtpof=true&sd=true) to collect this vital information. While some questions may overlap with those asked during the sales process, we kindly request that you complete the workbook to align your preferences accurately.

***

**Configuration & Setup**

In this tab, we require responses to questions related to your digital assets. Please fill in the "Response" column to provide the necessary details.

![](https://files.readme.io/1978e30-Screenshot_2024-03-01_at_5.01.55_PM.png)

**Wallets & Accounts**

This tab is where we gather information about the wallets and accounts you'll be plugging into our software.

![](https://files.readme.io/5b6d4b0-Screenshot_2024-03-01_at_5.13.58_PM.png)

- **Entity Column**: Specify the entity for which you'd like to plug in the wallet, especially if you have multiple entities.
- **Data Source or Wallet Name**: Provide the name of the wallet and its data source, whether it's from a blockchain source, network, exchange, or custodian.
- **Wallet Addresses/Access Information**: Share the wallet addresses or access information required for integration.
- **Transaction Volume (Txn Volume)**: Indicate the transaction volume for the wallet per month to assist with proper tracking.
- **Other Notes**: Feel free to include any relevant notes or special instructions regarding the wallet.

> ❗️ **Taking Action:**
> 
> Please focus on completing these two tabs in your workbook:
> 
> - [ ] Configuration & Setup
> - [ ] Wallets & Accounts
> 
> Once you've completed these sections, reach out to your [Onboarding Specialist](mailto:support@bitwave.io), and we'll proceed with the next steps of your onboarding journey.
> 
> By completing your Onboarding Workbook thoroughly, you'll help us configure Bitwave to align seamlessly with your requirements, ensuring a smooth and efficient onboarding process!
