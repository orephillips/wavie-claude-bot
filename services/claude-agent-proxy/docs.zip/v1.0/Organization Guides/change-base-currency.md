---
title: "Change Base Currency"
slug: "change-base-currency"
excerpt: ""
hidden: true
createdAt: "Tue Oct 25 2022 12:34:32 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 22 2024 03:15:40 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Change the Settings  
Step 2: Missing Currency?

## Step 1: Change the Settings

1. Navigate over to **Organization** tab > **<<glossary:Org>> Settings** button
2. Select your correct currency from the **Base Currency** drop-down

![](https://files.readme.io/f5258a7-1.png "1.png")

## Step 2: Missing Currency?

If there is another base currency that is being used by your organization and it is not found in the drop-down, please reach out to our Solutions team and they will get that added for you.

<<glossary:Org>>
