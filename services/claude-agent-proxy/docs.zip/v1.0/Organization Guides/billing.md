---
title: "Billing"
slug: "billing"
excerpt: ""
hidden: true
createdAt: "Tue Oct 25 2022 14:06:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 22 2024 03:15:31 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Navigate to Billing  
Step 2: Special Circumstances

## Step 1: Navigate to Billing

1. Navigate over to the **Organization** tab > **Billing** section
2. Enter in the relevant billing information

![](https://files.readme.io/8a5ffa9-1.png "1.png")

## Step 2: Special Circumstances

1. Some organizations are billed through their accounting firm or have a special billing process in place (eg. paying with crypto). If this is the case, please reach out to your accounting firm or Bitwave at the email address below.
