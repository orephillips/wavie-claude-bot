---
title: "Get an API Key"
slug: "get-an-api-key-1"
excerpt: ""
hidden: true
createdAt: "Tue Oct 25 2022 14:03:42 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 22 2024 03:16:14 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Get API Keys  
Step 2: Save the Keys  
Step 3: Additional API Documentation

## Step 1: Get API Keys

1. To gain access to the Bitwave API, create an account on Bitwave
2. Navigate over to the **Organization** tab > **API** section
3. Select **Create API Key**
4. We will generate a _client_id_ and _secret_ for you.

![](https://files.readme.io/44d1c96-1.png "1.png")

## Step 2: Save the Keys

1. Please save the _secret_ as it will be inaccessible to you after you close the pop-up

## Step 3: Additional API Documentation

1. Additional API documentation can be found here
