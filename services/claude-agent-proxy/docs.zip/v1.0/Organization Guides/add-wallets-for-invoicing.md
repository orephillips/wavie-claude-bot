---
title: "Add Wallets for Invoicing"
slug: "add-wallets-for-invoicing"
excerpt: ""
hidden: true
createdAt: "Tue Oct 25 2022 14:10:27 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Mar 22 2024 03:16:22 GMT+0000 (Coordinated Universal Time)"
---
Step 1: Navigate to Invoicing  
Step 2: Verify the QR Code

## Step 1: Navigate to Invoicing

1. Navigate over to the **Organization** tab > **Invoicing** section
2. Fill in wallet addresses that will appear with QR codes on your invoices

![](https://files.readme.io/847cd80-1.png "1.png")

## Step 2: Verify the QR Code

1. Once you have entered in an address for your invoices, be sure to verify that the QR code is correct
2. Navigate to the **Customers** tab > **Invoices** table
3. We will import your Invoices from your ERP software
4. Select **View Invoice** to view your imported invoices and QR code generated to pay the invoice

![](https://files.readme.io/76af061-2.png "2.png")
