---
title: "Getting Started With Your API"
slug: "getting-started-with-your-api-1"
excerpt: "This page will help you get started with Manual APIU."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 03 2023 01:16:25 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 03 2023 01:16:25 GMT+0000 (Coordinated Universal Time)"
---
This is where you show your users how to set it up. You can use code samples, like this:

```javascript
$http.post('/someUrl', data).success(successCallback);

alert('test');
```

Try dragging a block from the right to see how easy it is to add more content!
