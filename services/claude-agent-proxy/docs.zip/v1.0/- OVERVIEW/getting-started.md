---
title: "Getting Started"
slug: "getting-started"
excerpt: ""
hidden: false
createdAt: "Mon Apr 22 2024 23:03:45 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Aug 07 2024 12:57:26 GMT+0000 (Coordinated Universal Time)"
---
### Let's explore the following guides

| Title                                                                     | What is in the Guide?                                                           |
| :------------------------------------------------------------------------ | :------------------------------------------------------------------------------ |
| **[Onboarding Guide](https://docs.bitwave.io/docs/onboarding)**           | Onboarding essentials to get started in Bitwave (🏁 start here!)                |
| **[Bitwave Wiki](https://docs.bitwave.io/docs/contents)**                 | Step-by-step tutorials and guides to help you navigate the platform             |
| **[FAQs](https://docs.bitwave.io/docs/1)**                                | A curated list of frequently asked questions and answers                        |
| **[Integrations](https://docs.bitwave.io/docs/exchanges)**                | A list of our integrations and capabilities                                     |
| **[Connection Guides](https://docs.bitwave.io/docs/adding-bitfinex-api)** | A list of guides for obtaining access information for different API connections |
| **[Change Logs](https://docs.bitwave.io/changelog/change-log-home)**      | Release notes on changes to our platform                                        |
