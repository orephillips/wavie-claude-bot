---
title: "Welcome to Bitwave!"
slug: "welcome"
excerpt: ""
hidden: false
metadata: 
  title: "Bitwave Documentation Hub"
  description: "Bitwave is the #1 Digital Asset Finance Platform For Enterprises. Bitwave combines audit-proven tax and accounting automation software with workflow and process expertise."
  image: 
    - "https://files.readme.io/5d85a4bb1795fd5844054594b7a22fdd21a28f60cd566f6b1810caefe1df970e-OPEN-GRAPH---BITWAVE.png"
  keywords: "Crypto tax calculator, Bitcoin tax, Cryptocurrency tax software, Cryptocurrency tax reporting, Crypto capital gains, IRS crypto tax, Crypto tax filing, Cryptocurrency tax laws, Crypto tax reporting tools, How to report crypto on taxes, CoinTracking, ZenLedger, Koinly, CryptoTrader.Tax, Accointing, TokenTax, Blox, Shrimpy, Delta, Altpocket, BitTaxer, BearTax, CoinTracker, Cointobear, Coinpanda, Binance Tracker, CoinStats, LibraTax, TaxBit, Ledgible, Cryptio"
  robots: "index"
createdAt: "Mon Apr 22 2024 20:57:35 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Fri Sep 27 2024 00:09:29 GMT+0000 (Coordinated Universal Time)"
---
### We’re glad you’re here! 👋

[Bitwave](https://www.bitwave.io/) is the #1 Digital Asset Finance Platform For Enterprises. Bitwave combines audit-proven tax and accounting automation software with workflow and process expertise.

### Our Story

***

The accounting world is faced with an unprecedented challenge.

Traditional enterprise companies and crypto-native startups are both learning the regulatory nuances and accounting complexities of a new class of assets.

Digital assets, like cryptocurrencies and NFTs, are an exciting revolution in the global ecosystem. But accounting for them on your financial books can be daunting – or even impossible – with current ERP solutions.

![](https://files.readme.io/df25fb1-image.png)

### Our Mission

***

Bitwave bridges this gap between blockchain-based technology systems and the traditional finance world.

Our mission is to transform unmanaged risk into a strategic business advantage for enterprise companies and allow them to seize the opportunities created by digital asset adoption.

Founded in 2018 by technology veteran entrepreneurs Pat White and Amy Kalnoki, today Bitwave is the #1 enterprise platform for digital assets.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eee4cb77b88ed88961ba7b8d76c9731d3fe4860e4d9fe1572837dfdf4a1b6403-qbo2glerp.png",
        null,
        ""
      ],
      "align": "center"
    }
  ]
}
[/block]
