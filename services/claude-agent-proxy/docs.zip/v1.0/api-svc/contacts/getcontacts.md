---
title: "/contacts/{orgId}"
slug: "getcontacts"
excerpt: "Returns all the contacts for an organization within Bitwave. Contacts can either be created manually within Bitwave or imported from your ERP software via Bitwave integration."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:48:35 GMT+0000 (Coordinated Universal Time)"
---
## Contacts.

The _/categories/{orgId}_ returns all the contacts for an organization within Bitwave. Contacts can either be created manually within Bitwave or imported from your ERP software via Bitwave integration.
