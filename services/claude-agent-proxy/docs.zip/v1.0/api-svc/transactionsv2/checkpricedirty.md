---
title: "/orgs/{orgId}/transactions/dirty"
slug: "checkpricedirty"
excerpt: "Checks price IDs for dirty prices"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
---
