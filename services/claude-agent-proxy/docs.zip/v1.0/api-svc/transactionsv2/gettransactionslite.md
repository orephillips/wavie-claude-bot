---
title: "/orgs/{orgId}/transactions"
slug: "gettransactionslite"
excerpt: "Returns a paginated list of all transactions for a Bitwave organization"
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
---
