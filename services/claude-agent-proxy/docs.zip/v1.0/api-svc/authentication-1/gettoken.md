---
title: "/v2/oauth/token"
slug: "gettoken"
excerpt: "Provides you with an authentication token to access the Bitwave API."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:49:21 GMT+0000 (Coordinated Universal Time)"
---
## Authentication Token

The _/oauth/token_ will provide you with an authentication token to access the Bitwave API.
