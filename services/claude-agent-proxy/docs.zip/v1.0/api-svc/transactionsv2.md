---
title: "TransactionsV2"
slug: "transactionsv2"
excerpt: "Revised Transaction APIs. Transaction related requests should use V2 when possible."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:30 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:40:02 GMT+0000 (Coordinated Universal Time)"
---
