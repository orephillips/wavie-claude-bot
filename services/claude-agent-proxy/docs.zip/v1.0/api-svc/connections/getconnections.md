---
title: "/orgs/{orgId}/connections"
slug: "getconnections"
excerpt: "Returns all connections associated with an organization."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 06:19:07 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:47:35 GMT+0000 (Coordinated Universal Time)"
---
## Organization Connections

The _/orgs/{orgId}/connections_ endpoint will retrieve all the connections associated with an organization.
