---
title: "/orgs/{orgId}/connections/{connectionId}"
slug: "getconnection"
excerpt: "Returns information regarding a particular connection for your Bitwave organization."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Aug 31 2021 06:19:07 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:47:35 GMT+0000 (Coordinated Universal Time)"
---
## Connection Details

The _/orgs/{orgId}/connections/{connectionId}_ endpoint returns information regarding a particular connection for your Bitwave organization.
