---
title: "/txns/{orgId}/{transactionId}"
slug: "delete"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:46:12 GMT+0000 (Coordinated Universal Time)"
---
