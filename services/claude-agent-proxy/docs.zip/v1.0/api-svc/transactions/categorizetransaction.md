---
title: "/txns/categorize/{orgId}/{transactionId}"
slug: "categorizetransaction"
excerpt: "Categorizes your transaction within Bitwave. Some of the categories within Bitwave include Simple, Account Transfer, Detailed, Invoice/Bill Payment, and DeFi."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:36:35 GMT+0000 (Coordinated Universal Time)"
---
## Categorize a Transaction

The _/txns/categorize/{orgId}/{transactionId}_ endpoint categorizes your transaction within Bitwave. Some of the categories within Bitwave include Simple, Account Transfer, Detailed, Invoice/Bill Payment, and DeFi.
