---
title: "/txns/{orgId}/{transactionId}/{sourceId}"
slug: "upserttransaction"
excerpt: "Enables you to create a transaction manually into Bitwave."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:36:35 GMT+0000 (Coordinated Universal Time)"
---
## Create a Transaction

The _/txns/{orgId}/{transactionId}/{sourceId}_ endpoint enables you to create a transaction manually into Bitwave.
