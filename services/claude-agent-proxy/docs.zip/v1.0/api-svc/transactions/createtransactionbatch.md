---
title: "/txns/orgs/{orgId}/transactions"
slug: "createtransactionbatch"
excerpt: "Create Transaction batch"
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 11 2023 00:11:14 GMT+0000 (Coordinated Universal Time)"
---
