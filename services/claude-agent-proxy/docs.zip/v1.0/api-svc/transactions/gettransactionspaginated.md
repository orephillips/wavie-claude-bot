---
title: "/txns/{orgId}"
slug: "gettransactionspaginated"
excerpt: "Returns all the transactions for your Bitwave organization."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:36:36 GMT+0000 (Coordinated Universal Time)"
---
## Transaction History

The _/txns/{orgId}_ endpoint returns all the transactions for your Bitwave organization.
