---
title: "/orgs/{orgId}/wallets/validate"
slug: "validatewallet"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:50:48 GMT+0000 (Coordinated Universal Time)"
---
