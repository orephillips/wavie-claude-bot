---
title: "/org/{orgId}/categories"
slug: "createcategory"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Nov 03 2021 12:17:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:45:38 GMT+0000 (Coordinated Universal Time)"
---
