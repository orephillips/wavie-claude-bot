---
title: "/orgs/{orgId}/customers/{customerId}/reports/gainLossReport"
slug: "generategainlossreport"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Wed Nov 03 2021 12:17:09 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:42:48 GMT+0000 (Coordinated Universal Time)"
---
