---
title: "/users/me"
slug: "me"
excerpt: "Returns current user's account information, such as their name, email, and role."
hidden: false
metadata: 
  image: []
  robots: "index"
createdAt: "Thu Aug 12 2021 18:00:39 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Wed Oct 11 2023 00:06:02 GMT+0000 (Coordinated Universal Time)"
---
## User Information

The _/users/me_ will retrieve all of a user's account information, such as their name, email, and role.
