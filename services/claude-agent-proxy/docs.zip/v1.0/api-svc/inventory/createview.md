---
title: "/orgs/{orgId}/inventory-views"
slug: "createview"
excerpt: ""
hidden: true
metadata: 
  image: []
  robots: "index"
createdAt: "Tue Oct 10 2023 23:36:33 GMT+0000 (Coordinated Universal Time)"
updatedAt: "Tue Oct 10 2023 23:43:08 GMT+0000 (Coordinated Universal Time)"
---
