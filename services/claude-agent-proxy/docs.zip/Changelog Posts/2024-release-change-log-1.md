---
title: "2024 Release Change Log"
slug: "2024-release-change-log-1"
type: "added"
createdAt: "Wed Aug 07 2024 12:24:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
metadata: 
  image: 
    - "https://files.readme.io/bc4d4cb66ded055fa3470363d7c47c369d5e7e45365db7ca2bc279f0447d9722-OPEN-GRAPH---BITWAVE.png"
  robots: "index"
---
#### January 31st, 2024

**Feature Title:** Register Report for Crypto and Fiat  
**Feature Description:**  
Users can now use the register report for both Crypto and Fiat, with a toggle feature to distinguish between similar tickers.  
**Feature Title:** In-App Announcements  
**Feature Description:**  
Replaced the old bitcoin price chart with a new in-app announcements page for sharing feature releases, events, blog posts, and more.  

***

<br />

#### April 5th, 2024

**Feature Title:** Self-Serve Model Enhancements  
**Feature Description:**  

- Exchange Connections: Users can update exchange API keys in-app.
- Accounting Connections: Users can update token credentials and fee account codes in NetSuite and Sage.
- Fee Handling Methodology: Introduced fee expensing option.
- Adding Blockchain Wallets: Improved consistency and reliability in the new wallet UI. 

***

<br />

#### April 19th, 2024

**Feature Title:** Product Updates  
**Feature Description:**  

- Included unrealized gain/loss in the Cost Basis Rollforward Report.
- Allowed booking to accounts other than 'Bank' in QBO.
- New rules UI for validating transactions.
- Internal improvements for admin panel and Stellar integration progress.

***

<br />

#### May 16th, 2024

**Feature Title:** Post Sprint Product Updates  
**Feature Description:**  

- Completed Stellar Chain Integration.
- Enabled SCIM name changes through SSO.
- Added metadata filtering and reporting enhancements for Ripple.
- Supported validator rewards for Celo chain.
- Launched enhanced bulk categorization for Babel orgs.

***

<br />

#### June 3rd, 2024

**Feature Title:** Recent Product Enhancements  
**Feature Description:**  

- Enforced whitespace restrictions on wallet addresses.
- Added CSV download button for full history on the pricing page.
- Improved admin panel search functionality by orgId and orgName.

***

<br />

#### June 17th, 2024

**Feature Title:** Sprint Changes  
**Feature Description:**  

- Added warning for zero pricing in bulk categorization.
- Introduced expandable side bar in Bitwave for Babel orgs.
- Displayed impairment reversal in Cost Basis Roll Forward summary.
- Rolled up wallets by involved accounts for ABBS networks.

***

<br />

#### June 27th, 2024

**Feature Title:** Post Sprint Product Changes  
**Feature Description:**  

- Launched Canton Network integration.
- Introduced Data Explore for dataset self-service.
- Launched P0 of Balance Delta Wallets.
- Enhanced metadata and rules for categorization.
- Introduced Recon for compliance-friendly tooling.
- Internal improvements for access-based permissions and Partner Wallet Manager beta.

***

<br />

#### August 12th, 2024

**Feature Title.** Multiple Feature Updates: Faster Categorization, Stronger API Validation, More  
**Feature Description.**

We're excited to share several key updates and enhancements designed to improve your experience and streamline your workflow and ensure more accurate and efficient operations.

⏺ Enhanced UI Responsiveness: Improved UI responsiveness for faster loading of tools and balances, specifically for larger organizations.

⏺ New Accounting Connections Page: Enjoy a sleeker and more consistent look with the newly launched Accounting Connections page, aligning with other recent updates for a cohesive user experience.

⏺ SoDA Report: New wallet roles have been added, allowing you to search by role name, add or delete roles, and share them with users more efficiently.

⏺ Foundry API Key Validation: To ensure accuracy, we've implemented validation for API keys, so only correct keys can be entered when adding connections.

⏺ Sage Top Level ERP Creation Enhancement: The entity-level launch now enables posting individual lines to different entities, enhancing flexibility in ERP management.

⏺ Metadata Fields Import CSV: Sage customers can now categorize metadata through imports, making it easier to organize and manage your data.

<br />

***

<br />

#### August 23rd, 2024

**Feature Title.** Latest Product Updates: Platform Optimization & Strategic Planning  
**Feature Description.**

As part of our ongoing Platform Optimization efforts, this sprint centered around key bug fixes and strategic preparations for future initiatives. Below are the highlights of our recent enhancements:  
Release Highlights:

⏺ Org Navigation Enhancements: You can now open multiple tabs for different organizations, with an alert system in place to warn users logging in with outdated or expired requests.

⏺ Partner Wallet Manager Integration: Partners can now seamlessly sync blockchain wallets created by clients directly into the organization.

⏺ Binance Smart Chain Upgrade: We’ve implemented a more efficient syncing method, improving performance and data integration for a smoother user experience.

Stay tuned as we continue to refine and enhance our platform through Platform Optimization and deliver Magical User Experiences in the upcoming releases!

<br />

***

<br />

#### September 10th, 2024.

**Feature Title.** Product Release: Key Enhancements for Improved User Experience  
**Feature Description.**

In our continued efforts to elevate Customer Experiences, we’re pleased to share the latest updates and improvements :

<br />

● Wallets UI Enhancements: Updated visuals on various pages, including the wallets page, now displaying dollar amounts in a clean, formatted view for improved readability.  
● Inline Categorization Updates: Users can now easily copy and paste the "to" and "from" addresses when using inline categorization, simplifying workflows and increasing efficiency.  
● Ethereum Chain Optimization: We've upgraded our Ethereum syncing process, delivering faster performance and more seamless data integration.  
● Anchorage Integration Upgrade: The Anchorage integration has been updated to allow shared hashes on UTXO-based transactions for newly added connections, enhancing transaction flexibility.

We’re committed to continually refining our platform to better serve your needs. Stay tuned for more updates!

***

<br />

#### September 23rd, 2024.

**Feature Title.** Product Release: Key Updates and Feature Enhancements  
**Feature Description.**

We’re excited to announce new updates designed to enhance your workflow and improve overall platform performance.

:baggage_claim: New Wallet UI Features:  
You can now search wallets by name using the newly added search functionality.  
⏺ Wallet descriptions are now displayed directly on the page once added.  
⏺ We've introduced validation checks for API keys in several integrations, including Coinbase Prime, Fireblocks, and ⏺ Foundry, ensuring only valid API keys are accepted.  
⏺ Metadata fields are now visible within wallet details for better data management.  
:white_check_mark: Foundry Enhancements: Sub-account names are now automatically displayed on the connections page, improving  
clarity for Foundry users.  
:soap: Organizations Page Redesign: The Organizations page has been revamped with a sleeker, more modern interface for a better user experience.  
:receipt: SoDA Report Updates: Users with access to the SoDA report can now view wallet roles directly on the wallets page, making it easier to manage roles.  
:page_with_curl: Import Template Navigation Improvements: We’ve enhanced import templates with an improved sorting method, offering more intuitive navigation for better usability.  
:heavy_dollar_sign: Payment Operations Enhancements:  
⏺ New filtering options allow users to easily sort and manage payments.  
⏺ Payments are now automatically named with the date and time for easier identification.  
⏺ Post-creation editing of payment names is now available for greater flexibility.  
⏺ Full payment addresses are now viewable when opening payment transactions for improved detail visibility.  
⏺ A loading indicator has been added to the settings page to provide real-time feedback on background processes.

We’re committed to continuous improvement and look forward to bringing you more exciting updates in the future!

***

#### October 4th, 2024

**Feature Title :** Multiple Feature Updates: Enhanced UI, Streamlined Reporting, and Stronger API Validation  
**Feature Description:**

We’re pleased to announce the latest updates and improvements aimed at enhancing your overall experience and optimizing your workflows.

<br />

:receipt: Accounting Connections Upgrade :  
I⏺ ntroduced a cleaner, more intuitive UI, now accessible through a settings dropdown.  
⏺ Users can assign or edit connection names upon adding them, with connection names now displayed at the transaction level for easier identification, especially when managing multiple ERP systems.  
:currency_exchange: Coinbase Pro Update :  
⏺ With the deprecation of Coinbase Pro, new connections now display “Exchange” as the only option, simplifying the connection process without ties to the Pro product.  
:wrench: UI Reporting Launch :  
⏺ Launched an enhanced reports center with a modern, streamlined design.  
⏺ Users can now link directly to specific reports in a single click, improving efficiency in accessing data.  
:money_with_wings: Payments Enhancements  
⏺ Added a link to the vendor page from the contact view for quicker access.  
⏺ Users can send whitelist request emails, triggering an approval notification for recipients to take action.  
⏺ Default payments can now be set for wallets, and auto-reconciliation is enabled for payment transactions.  
:currency_exchange: Bitgo Improvements :  
⏺ Updated transaction display to include “to” and “from” addresses when available from the custodian.  
⏺ Implemented upfront API key validation for new connections to ensure accuracy during the setup process.

***

<br />

#### October 23rd, 2024

**Feature Title :** Multiple Feature Updates : Key Updates in Payments, Exchange Connections, and Inventory Views  
**Feature Description:**

We’re excited to announce the latest improvement, bringing enhanced functionality and usability to support your experience.

<br />

:credit_card: Payments :  
⏺ Enhanced Error Messaging: Improved clarity in error messaging for payments and penny testing.  
⏺ LINK Token for Penny Testing: Added LINK token support for more comprehensive Penny Test functionality.  
⏺ Optional Know Your Transaction Check: Flexibility added with optional Know Your Transaction checks for certain payment processes.  
:currency_exchange: Exchange Connections :  
⏺ Improved API Key Security: Duplicate API keys are now prevented, ensuring unique and secure connections.  
:receipt: Inventory Views :  
⏺ New Cancel Button: A Cancel button has been added to inventory views for easier management and adjustments.

We’re committed to continuous improvements that simplify your experience. Thank you for being a valued part of our journey!

***

#### November 6th, 2024

**Feature Title :** Multiple Feature Updates : Enhanced Accounting, Payment Security, and Updated Wallet UI  
**Feature Description:**

We’re excited to introduce the latest updates, packed with features designed to boost usability, security, and efficiency.

:receipt: Accounting Connections **:**  
⏺ Metadata Mappers for Payments: Easily map metadata from NetSuite fields directly into payments for better alignment and data consistency.  
:yen: Payments **:**  
⏺ Address Verification & Whitelisting: Enhanced security with address verification and whitelisting now on the Bills page.  
⏺ KYT Checks Toggle: Added flexibility to toggle Know Your Transaction (KYT) checks on or off as needed for payments.  
:lock: Inventory Views **:**  
⏺ Lock Period Feature: Now live, enabling secure lock periods within inventory views for added control.  
:currency_exchange: Exchange Connections Enhancements  
⏺ Bitfinex: API key validation for new keys, complete with recent transaction and balance snapshots.  
⏺ Fireblocks: User-friendly key format examples added for a smoother key entry experience.  
⏺ Bitgo: UTXO chain handling is now supported, with synchronized transactions showing “to” and “from” addresses.  
:new: Old Wallet UI Sunsetting **:**  
⏺ Upgraded Wallets UI Now Live: The old Wallet UI has been sunset, with all users now on the enhanced Wallets UI. This updated UI offers a sleek design with improved navigation and search functionality.

<br />

Thank you for being part of our journey as we continue to enhance and refine your user experience!

***

<br />

#### November 21st, 2024

**Feature Title :** Multiple Feature Updates : Enhanced Accounting, Payment Security, and Updated Wallet UI  
**Feature Description:**

We’re thrilled to unveil the latest updates, designed to streamline workflows and enhance user experience.

:currency_exchange: Upgraded Connections  
Enhanced UI for Adding Exchanges: Enjoy a sleeker and more intuitive interface when setting up exchange connections.  
:receipt: Canton Blockchain  
Balance Support Added: Now supporting balances for the Canton blockchain network, broadening our capabilities.  
:compass: UI Navigation  
New Chrome Experience (Phase 1): The first phase of our upgraded navigation system is live, featuring a sleek arrangement for improved usability.  
:money_with_wings: Enterprise Payments  
Pricing Default Methods by Asset: Default pricing methods can now be set by asset for simplified payment configurations.  
All Supported Currencies Displayed: Payments now display all supported currencies for better visibility.  
KYT Configuration for Wallets: Added KYT settings for wallet configurations, improving security.  
:lock: Inventory Views  
Custom Controls Added: Enhanced flexibility with features to freeze inventory views and retain prior data, even when new wallets are added.  
:ballot_box_with_check: User Experience  
Improved Transaction Validations (Phase 1): The first phase of enhancements to validations and categorizations is now live in the new transactions view.

We’re committed to delivering updates that enhance functionality and provide a better user experience.

<br />

***

#### December 11th, 2024

**Feature Title :** Enhanced Accounting and Payment Updates  
**Feature Description:**

We’re excited to introduce our newest updates, designed to improve functionality, streamline workflows, and enhance the payment experience.

:receipt: Accounting ConnectionsNetSuite Integration: Added the "Class" field to settings for better classification and reporting in NetSuite.  
:yen: Payments  
⏺ Default Pricing Method: Introduced the T1D+Close pricing method for increased flexibility in payment processing.  
⏺ Payment Status Notifications: Users now receive email updates on payment statuses, ensuring better tracking and transparency.

Thank you for your continued support and dedication! 🚀

<br />

***

#### December 18th, 2024

**Feature Title :** Enhanced Transactions UI, Payments, and Reallocation Features  
**Feature Description:**

We’re excited to announce the newest updates, designed to improve usability, streamline workflows, and enhance financial tracking.

:bar_chart: New Transactions UI  
⏺ Enhanced Filtering: Select specific wallets, tickers, types, and more, with the ability to unselect all filters.  
⏺ Clear Filters: Easily reset filters by clicking the "X."  
⏺ Proper Sizing Expansion: Transactions now expand to the correct size when opened.  
⏺ Old Layout Option: Switch back to the old layout under settings if preferred.  
⏺ Screen Rollout: The new screen layout is being gradually rolled out to users.  
⏺ Toggle Setting: Users with access to the new Transactions page can toggle back to the old Transactions page as needed.

:yen: Payments  
⏺ Vendors List Sidebar: A dedicated Vendors list is now available on the sidebar for quick access.  
⏺ Vendor Audit Log: Track vendor-related changes with the new audit log feature.

:moneybag: Payments UI  
⏺ Quick Payment Summary: Payments now display a brief summary for easier tracking.  
⏺ Sidebar Preview: Clicking a payment opens a preview on the sidebar for a quick overview.

:recycle: Reallocation  
⏺  What Is It?:  
Due to new regulations, token inventories can no longer be accounted for on a token basis but must be reallocated across wallets.

1. Global Inventory View: View tokens across wallets in a global inventory screen.
2. Reallocation Process:  
   i. Select the global inventory view, wallet balance view, and an end date.  
   ii. Choose how to apply balances to wallets and see where reallocation occurs.

We’re committed to continually refining our platform to better serve your needs. Stay tuned for more updates!