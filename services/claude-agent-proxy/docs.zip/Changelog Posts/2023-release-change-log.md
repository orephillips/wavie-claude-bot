---
title: "2023 Release Change Log"
slug: "2023-release-change-log"
type: "improved"
createdAt: "Wed Aug 07 2024 12:22:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
metadata: 
  image: 
    - "https://files.readme.io/fd98f557147bacae30b59e64430307b570f88206d8c1fd2d6010765ca2987e05-OPEN-GRAPH---BITWAVE.png"
  robots: "index"
---
#### February 23rd, 2023

**Feature Title:** Auto Mapping of Address to Contact  
**Feature Description:**  

- Users can now map an address to a “contact,” which will automatically pre-populate the “contact” in the detailed categorization screen.
- **Scope:**
  - Applies to assets in the “Accounting -> Contacts -> Manage Addresses” dropdown.
  - Applies only to simple Send & Receive Transactions.
- **Not in Scope:**
  - Trade, Contract Execution transactions, Internal Transfers, and “Fee only” transactions.
  - Complex transactions with multiple “to” and “from” addresses.

#### February 23rd, 2023

**Feature Title:** Language Selection  
**Feature Description:**  

- Users can now select their preferred language for Bitwave.
- **Supported Languages:**
  - English
  - Français
  - Español
- **Access:** Available via “Account -> User Profile -> Locale.”

#### February 23rd, 2023

**Feature Title:** Backend Load Time Improvement  
**Feature Description:**  

- 90% of calls to load the New Transactions UI now complete in 6.5 seconds, a >95% reduction in load time.

#### March 6th, 2023

**Feature Title:** Terms of Service Acceptance  
**Feature Description:**  

- Users are required to accept the Terms of Service and Privacy Policy at login.
- Users need to accept it only once unless there are new changes.

#### March 9th, 2023

**Feature Title:** Split Categorization Rule  
**Feature Description:**  

- Users can create a rule to automatically split a transaction by percentage and categorize each split to a different Chart of Accounts (CoA).

#### March 13th, 2023

**Feature Title:** Bulk Categorization  
**Feature Description:**  

- Enables users to select multiple transactions and categorize them all at once.
- Aims to reduce the number of clicks by >50% for users dealing with hundreds of transactions per day.

#### March 14th, 2023

**Feature Title:** Improved Import Error Handling  
**Feature Description:**  

- Enhanced error handling for the "import" function to upload .CSVs, reducing support issues.

#### March 14th, 2023

**Feature Title:** MINA Blockchain Integration  
**Feature Description:**  

- Supports MINA token, Send/Receive Transactions, Coinbase Staking Rewards, and Fee Staking Rewards.
- **Not Supported:**
  - Asset types other than MINA
  - Other transaction types not listed.

#### March 9th, 2023

**Feature Title:** Polygon Validator Staking Reward Rollups  
**Feature Description:**  

- Aggregates Polygon Validator Rewards by the hour for new wallets added to Bitwave, reducing transaction volume by >90%.

#### March 20th, 2023

**Feature Title:** Transactions Export V2  
**Feature Description:**  

- Exports transactions using the Data Warehouse, offering faster export and categorized status.
- **Known Limitations:**
  - Data Warehouse may be ~12 hours delayed.
  - Does not export CATEGORY or CONTACT.

#### March 21st, 2023

**Feature Title:** Searchable Dropdowns  
**Feature Description:**  

- Users can now search and filter within the ORGANIZATION and WALLET dropdowns, improving UX for sorting through large lists.

<br />

#### March 28th, 2023

**Feature Title:** Aptos Blockchain Support  
**Feature Description:**  

- Official support for the Aptos Blockchain.
- Supported features include:
  - Aptos - APT (Native Asset of the Aptos Blockchain)
  - Sending and Receiving Transactions
  - Gas Fees
  - Wallet Addresses (e.g., 0x6d4cb054ad2a383b46e05ae0387ae1950c1a8b576645c99d1b32e7d6ad8f937)
- Limited Support:
  - Staking support (only picks up deposit and withdrawal events, no block-by-block accruals).

<br />

[View Supported Blockchains](https://docs.bitwave.io/docs/blockchains)

#### April 5th, 2023

**Feature Title:** New Transaction UI  
**Feature Description:**  

- Migration from Legacy Transaction UI to New Transaction UI on April 11.
- Features of the New UI:
  - Faster Data Results (90% faster).
  - Multi-Wallet Select + Filter.
  - Bulk Categorization Capability.
  - Add/Remove Gridlines & More Rows.

<br />

#### April 6th, 2023

**Feature Title:** Transaction Lock Capability  
**Feature Description:**  

- Enables clients to lock and freeze their transaction history within a defined period.
- Features:
  - Lock transaction history within a selected time period.
  - Locked periods cannot be modified.
  - Audit trail created for changes to locked periods.
- Importance:
  - Ensures transaction history integrity post-locking.
  - Useful for period-end close processes.
- Available under Accounting > Period End Close Page.

<br />

#### April 10th, 2023

**Feature Title:** Multi-Currency Bill & Invoice Feature  
**Feature Description:**  

- Supports categorization of bills/invoices in currencies different from the organization's functional currency.
- Available for Quickbooks and Netsuite.
- Bitwave is the only digital asset sub-ledger supporting this feature.

<br />

**Feature Title:** Journal Entry Report Enhancements  
**Feature Description:**  

- New Journal Entry Report that:
  - Runs in the background.
  - Includes TOKENS, token quantities, internal categories, and contact IDs.
  - Saves runs in BigQuery.

<br />

#### April 17th, 2023

**Feature Title:** Hedera and XRP Blockchain Integrations  
**Feature Description:**  

- Supported Features:
  - Native Token Support (HBAR & XRP)
  - In and Outbound Transactions (Send/Receive)
  - Gas Fees
  - Transaction Aggregation via Rollups

**Sales Notes:**

- Confident support for Hedera blockchain.
- Functional integration demonstrated for potential partnership announcements.

<br />

#### May 8th, 2023

**Feature Title:** Imports V2 (Beta Release)  
**Feature Description:**  

- Improvements include:
  - Capable of importing >5k transactions at once.
  - Preview raw and validated data before import.
  - Robust validation with download options for invalid transactions.
  - Enhanced user experience and reliability.
- Available by request.

<br />

#### June 20th, 2023

**Feature Title:** In-line Categorization  
**Feature Description:**  

- Perform in-line categorization directly on the All Transactions Page.
- Features:
  - Assign addresses to Contacts.
  - Assign Categories to amounts.
  - Preview effect of rules before confirming categorization.
- Benefits:
  - Intuitive rule creation.
  - Significant reduction in categorization time and clicks.
- Available under feature flag, undergoing internal and power user testing.

<br />

#### July 26th, 2023

**Feature Title:** New Authentication Service  
**Feature Description:**  

- Implemented new authentication service.
- Added login via IDP initiated SSO (e.g., OKTA).
- Enabled session sharing between applications (e.g., Bitwave CORE & Ops/Enterprise Payments).
- Fixed 'Double-logout' bug.
- Improved UI/UX for a better user experience.  
  This feature will be rolled out over the next several weeks to early users.

#### August 3rd, 2023

**Feature Title:** Detailed Rule Enhancements  
**Feature Description:**  

- Enhanced rules to handle the unique categorization of multiple unique assets within a transaction.
- Allows categorization based on asset type.  
  Requires Multi Token to be enabled and direction to be set to all.#### August 23rd, 2023

**Feature Title:** Balance Check Report  
**Feature Description:**  

- Introduced Balance Check Report to compare Bitwave balances with third-party data.  
  Example Use Case: Compare Anchorage balances without using any explorer.

#### August 23rd, 2023

**Feature Title:** DeFi Categorization Rules Based on Method ID  
**Feature Description:**  

- Enabled advanced DeFi categorization rules using rules based on the contract's Method ID.  
  Example Use Case: Auto-reverse some DeFi activities while leaving others 'as is'.

#### August 24th, 2023

**Feature Title:** Import Advanced Feature  
**Feature Description:**  

- Added the ability to upload raw file types (e.g., stake.tax, OKX exchange) into Bitwave.
- Automatically converts raw files into transactions.  
  Example Use Case: Upload CSVs from websites like stake.tax and OKX directly to Bitwave for conversion into transactions.

#### September 12th, 2023

**Feature Title:** UI Enhancements for Transactions Page  
**Feature Description:**  

- Improved readability with alternating row colors (off-white & light green).
- Enhanced UI with grey-text and larger padding.

#### October 12th, 2023

**Feature Title:** Wallet Exchange Visibility  
**Feature Description:**  

- Displaying Exchange Name at the wallet level.  
  Helps users and internal staff identify wallets associated with exchanges.

#### October 19th, 2023

**Feature Title:** Solana Staking Support  
**Feature Description:**  

- Added support for Solana staking "Epoch Rewards" (Inflation Rewards).
- Syncs rewards and displays them as normal deposit transactions.  
  How to enable: Automatically enabled for new wallets, request required for existing wallets.

#### November 20th, 2023

**Feature Title:** Edit Manual Transactions  
**Feature Description:**  

- Enabled editing of manual and imported transactions.
- Access via the transactions page by selecting “Edit Transaction”.

#### November 21st, 2023

**Feature Title:** Fantom Blockchain Support  
**Feature Description:**  

- Added support for the Fantom blockchain.
- Supports all transaction types and tokens (ERC20s, ERC721/1155s).

#### November 27th, 2023

**Feature Title:** Improved Pricing Source Selection  
**Feature Description:**  

- Added feature forcing users to add a backup pricing source or acknowledge implications of using only one source.  
  Helps prevent issues with transaction pricing.

<br />

#### November 29th, 2023

**Feature Title:** Ethereum Staking Support  
**Feature Description:**  
Enabled Ethereum staking support, including:

- Consensus Layer Staking Rewards (Beacon Chain staking rewards, Block Rewards, Inflation rewards)
- Execution Layer Staking Rewards (MEV, TIPS, staking rewards on ETH1/Mainnet)
- Deposits and withdrawals between ETH1 and Beacon Chain  
  Users can now add their validator public key or ETH address to Bitwave to automatically sync rewards and transactions.

#### December 6th, 2023

**Feature Title:** Enhanced Actions Report  
**Feature Description:**  
Included Contact, Category, Department, Class, Location, and Addresses into the actions report, addressing a long-