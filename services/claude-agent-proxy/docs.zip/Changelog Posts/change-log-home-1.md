---
title: "Change Log Home"
slug: "change-log-home-1"
type: "added"
createdAt: "Thu Jan 30 2025 19:36:19 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
[2025 Release Change Log](https://docs.bitwave.io/changelog/2025-release-change-log)

[2024 Release Change Log](https://docs.bitwave.io/changelog/2024-release-change-log-1)

[2023 Release Change Log](https://docs.bitwave.io/changelog/2023-release-change-log)

[2022 Release Change Log](https://docs.bitwave.io/changelog/2022-feature-releases)