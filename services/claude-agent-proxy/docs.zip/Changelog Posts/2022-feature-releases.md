---
title: "2022 Releases Change Log"
slug: "2022-feature-releases"
type: "improved"
createdAt: "Sun Jan 21 2024 05:07:00 GMT+0000 (Coordinated Universal Time)"
hidden: false
metadata: 
  image: 
    - "https://files.readme.io/06deb4a9717d9c80ec26789301aea88c123e724a51ea0e50e1431e049ca98d81-OPEN-GRAPH---BITWAVE.png"
  robots: "index"
---
***



## **Cross Platform**

- New and Improved UI across the Platform

## **Wallets**

- New and Improved Wallet Dashboards
- Wallet Grouping Capability

## **Transactions **

- Advanced Imports: Importing Trades, Metadata, Grouping Transactions
- Advanced Rules: Multi Token Rules Categorizations
- Advanced Transaction Processing: Custom Aggregations and Processing

## **Pricing**

- Advanced Pricing Engine:  (different pricing source by coin, by time), (pricing fall backs to different sources) 
- Pricing Direct from Binance Exchange
- Pricing Direct from Coinbase Exchange
- Pricing History
- Pricing API: Obtain Pricing from Various Source

## **ERP Integrations**

- QBO/Bitwave: AR/AP Integration
- Netsuite/Bitwave: AR/AP Integration
- Netsuite/Bitwave Custom Fields Integration

## **Accounting and Tax**

- Impairment
- Gain and Loss Detailed Reporting Extracts

## **Reporting**

- Datawarehouse Based Advanced Balance Reporting
- Datawarehouse Based Register UI

## **Bitwave Ops**

- Automated Bulk Payments on Polygon and Ethereum

## **Data Source Integrations**

**New and Updated Exchanges **

- PrimeTrust
- Coinbase Prime
- SFox
- Nydig
- Anchorage
- FTX Sub Accounts

**New and Updated Blockchains **

- AVAX
- BSC
- CELO
- Polygon
- Mina
- HECO
- Solana
- Terra
- Filecoin 
- Klaytn

**New and Updated Defi Protocols**  
_Avax-c:_

- Aave
- CRV
- Pangolin
- Sushi
- Trader Joe
- Wonderland 

_Eth:_

- 0x
- Aave
- Balancer
- Basis
- Compound
- CRV
- DODO
- Harvest
- Idle
- Integral
- mStable
- 1Inch
- Opyn
- Pickle
- Rari
- Sushi
- Uniswap
- Vesper
- Yearn
- Maker

_Polygon:_

- CRV
- AAVE

***



We're excited to announce our Fall 2022 release which includes industry defining features to power the day to day activities of our accounting and finance users. In putting together this release we focused on 3 major areas:

1. Data: Rollups & Scaling With Our Clients and Partners
2. Enterprise: Advanced Finance Features
3. Focus on Users: Quality and Under-the-Hood Performance Upgrades

Below are the details of our release:

**NEW CAPABILITIES**  
NFT Spam Filter, automatically filters out incoming NFT spam transactions - saving users hours of effort when dealing with spam.

Transaction Register, like a bank register, is a side-by-side view of a user's balance and transactions. Users typically use this feature to view, audit, and troubleshoot balance reporting issues.

Pricing History, a record of asset pricing used for balance reporting, transactions, and other reports in Bitwave. Users typically use this tool for generating pricing reports for auditing and troubleshooting purposes.

Pricing Rules, the ability to set custom pricing for assets over a defined time period, very useful for users looking to automate their custom pricing process.

Run Rules feature, before users had to wait a while for a newly created rule to start running, with this new update users can now run a rule immediately after creating it!

**NEW AND UPDATED BLOCKCHAINS**  
(In Beta)  
NEAR  
Loopring  
ImmutableX  
Solana Rollups

**NEW AND UPDATED EXCHANGES**  
Anchorage

**NEW AND UPDATED DEFI PROTOCOLS**  
Squeeth Crab V2  
Squeeth oSQTH vaults  
Compound Finance COMP accruals  
Convex Finance

**UNDER-THE-HOOD UPGRADES**  
Ability for users to view Bitwave’s operational status on <https://status.bitwave.io/>  
Upgrading backend to improve application responsiveness  
Squashed frustrating and intermittent UI bugs

***



We're excited to announce our Winter 2022 release which includes industry defining features to power the day to day activities of our accounting and finance users. In putting together this release we focused on 3 major areas:

1. Use Cases: Advanced Accounting
2. Focus on Users: Improvements to UI/UX
3. Focus on Users: Quality and Under-the-Hood Performance Upgrades

See the details of our release below!

**Inventory Views**  
“Inventory View” was born out of Bitwave’s engagement with clients involved in some of the most complex and high volume digital asset use cases in which we consistently observed the need to “view” digital asset outcomes from multiple different lenses.

Users can now, at a glance, access important balance, lot, and roll-forward information for their digital asset inventory (e.g. cost basis acquired, cost basis disposed, impairment, carrying value, FMV, unrealized G/L, and more…) through an “Inventory View”. Users will also notice right away that all of the data tables are highly responsive and performant which will be a breath of fresh air for our users ranging from hundreds of thousands to millions of transactions a year.

The real beauty of inventory views comes from the fact that, with the advanced account module, you can create and save multiple views. Does your organizations need to use different inventory treatments for Tax and Accounting? Just setup multiple inventory views, and you’ll find maintaining bifurcated books an absolute breeze! These capabilities are complimented by a series of new reports we’re building, starting with an industry first “Quantity and Cost Basis Roll Forward” report.

**Bitwave OPs (operations) V2**

- Ability to send bulk payments via Ethereum and Polygon
- Automatic Categorization
- Ability to segregate payment roles & responsibilities (eg. approval and payment)

**Advanced DeFi Categorization**

- Creation of the DeFi wallet
- Ability to categorize any type of DeFi protocol transaction

**New Transaction UI**

- New Transaction UI  
  -- REFRESHED Transactions UI  
  -- FASTER load times - up to 30% faster!  
  -- VIEW up to 250 transactions  
  -- QUICK filters: Needs Categorization, To Be Reconciled, All

**Blockchains & Integrations**

- Aptos
- Solana Rollups Enhacements
- ImmutableX Marketplaces & Standard Wallets
- Bitcoin Cash
- NyDig Enhacements
- Anchorage Enhacemens

**Partner Marketplace**  
We are excited to announce the launch of Bitwave Marketplace, a new feature for users to learn more about Bitwave’s robust partner ecosystems, including blockchains, exchanges, custodians, and more! 

To access Bitwave Marketplace, simply navigate to the tab labeled ‘Marketplace’ on the Bitwave dashboard. From there, users can see partner names, logos, a brief description, their category, and a "learn more" function that takes the user to the partner's website.

In the long term, we plan to add more features to the marketplace, such as user reviews and preferred pricing for partner services.