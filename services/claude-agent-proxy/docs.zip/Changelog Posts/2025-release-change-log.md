---
title: "2025 Release Change Log"
slug: "2025-release-change-log"
type: "added"
createdAt: "Thu Jan 30 2025 17:48:54 GMT+0000 (Coordinated Universal Time)"
hidden: false
---
#### January 29th, 2025

**Feature Title:** Wallets Page Enhancements – Improved Balance Tracking & Network Visibility  
**Feature Description:**

We’re excited to introduce new updates to the Wallets Page, enhancing visibility, usability, and internal efficiency.

:film_projector: Wallets Page  
⏺ Balance Timestamps: Wallet balances now display timestamps from the last sync for better tracking.  
⏺ Blockchain Networks Displayed: The respective blockchain networks are now shown for each wallet, providing clearer insights.

Thank you for your continued support and dedication! :rocket:

***

#### January 29th, 2025

**Feature Title: ** Product Release Notes – Wallet Management & User Invite Enhancements

We’re excited to introduce the latest updates, designed to enhance user control, streamline workflows, and improve the overall experience.

:no_entry: Disable Wallet Feature  
⏺ Users now have the ability to disable wallets they no longer want to sync themselves, providing greater control over wallet management.  
:email: User Invites  
⏺ Users within an organization can now revoke and resend invites on their own, making it easier to manage team access efficiently.

Thank you for your continued support and dedication! :rocket:

***

#### January 29th, 2025

**Feature Title**: Multiple Feature Updates – Enhanced Transactions, Security, and UI Enhancements  
**Feature Description:**

We’re excited to introduce the latest updates, packed with features designed to improve usability, security, and efficiency.

:money_with_wings: Transactions V2 Repricing  
⏺ Users can now reprice individual transactions in the UI when pricing fails.  
⏺ Bulk repricing is supported via a new system job.  
:chains: Aptos Chain Enhancements  
⏺ Support added for To and From Addresses on Aptos.  
⏺ Fees are now segregated to allow for better rule categorization.  
:lock: BYOK (Bring Your Own Key) Security Upgrade  
⏺ Users can now bring their own key to encrypt another key, ensuring enhanced security.  
⏺ This allows users to be project owners while granting restricted access to Bitwave.  
:bar_chart: Transactions V2 ERP Dimensions Display  
⏺ Expanded row view for dimension fields.  
⏺ Fields are editable on hover with a new edit mode for text boxes.  
:building_construction: Subsidiary Inventory View Filtering  
⏺ A new checkbox in the dashboard enables subsidiary-specific filtering in inventory reports.  
:eyes: Transactions V2 – New Status for Review  
⏺ “Needs Review” status added to flag transactions requiring user verification.  
⏺ Example: If a transaction was categorized, then a new wallet was added, users can now review changes easily.  
:moneybag: Enterprise Payments Enhancements  
⏺ Bitcoin penny test RBF workflow is optimized for faster transactions and better gas estimation.  
⏺ Stellar penny tests & Coinbase Prime payments are now supported.  
⏺ Users can now manually validate addresses for additional security.  
:art: Additional UI Updates  
⏺ Vendors page redesigned for a sleeker look and improved usability.  
⏺ Enhanced error messaging for better user guidance.