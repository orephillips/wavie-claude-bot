---
title: "Change Log Home"
slug: "change-log-home"
type: "added"
createdAt: "Wed Aug 07 2024 12:46:00 GMT+0000 (Coordinated Universal Time)"
hidden: true
metadata: 
  image: 
    - "https://files.readme.io/0f850c4557580e69cb36f30116e5832b0ec76244a15b313625ce7c7d955885f2-OPEN-GRAPH---BITWAVE.png"
  robots: "index"
---
[2024 Release Change Log](https://docs.bitwave.io/changelog/2024-release-change-log-1)

[2023 Release Change Log](https://docs.bitwave.io/changelog/2023-release-change-log)

[2022 Release Change Log](https://docs.bitwave.io/changelog/2022-feature-releases)